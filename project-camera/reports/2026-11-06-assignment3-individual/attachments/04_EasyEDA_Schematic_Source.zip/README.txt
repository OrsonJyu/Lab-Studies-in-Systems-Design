EasyEDA (Standard edition 6.5.61) schematic: SD5531 Team 02 camera recording module, wiring and power (as built, 2026-11-05). Drawn by ZHU Kecheng.
Open: https://easyeda.com/editor  ->  File > Open > EasyEDA Source...  and choose SD5531_T02_Camera_Wiring_Power.json
The *_compressed.json file is the same sheet in EasyEDA's compressed source format; the .svg is a vector export.
