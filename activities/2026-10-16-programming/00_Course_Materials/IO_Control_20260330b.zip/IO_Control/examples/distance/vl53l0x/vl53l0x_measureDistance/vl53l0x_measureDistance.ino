//
//  for demonstrating playback of one sequence on two LEDs
//    circuit:
//      IO19 - DIN of WS2812 strip (with at least 2 LEDs)
//      5V - 5V of WS2812 strip
//      GND - GND of WS2812 strip
//

#define USE_VL53L0XControl
#include <IO_Control.h>

I2CMasterControl i2cCtrl;

VL53L0XControl vl53l0xCtrl;

BinOutControl binOutCtrl;

DeclareHandler(vl53l0xHandler, _ctrl, VL53L0XControl, {
  Serial.println(_ctrl.measureDistance());
  if(_ctrl.measureDistance() < 200) {
    binOutCtrl.write(HIGH);
  } else {
    binOutCtrl.write(LOW);
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  pinMode(12, OUTPUT);

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = i2cCtrl.init(0, 10, 6);  //  use i2cNum=0, SCL=10, SDA=6
  if (err) {
    Serial.print("Fail to initialize i2cCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  err = vl53l0xCtrl.init(i2cCtrl);
  if (err) {
    Serial.print("Fail to initialize addrledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  binOutCtrl.init(12,LOW);


  vl53l0xCtrl.enableScheduler(0, 10, vl53l0xHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
