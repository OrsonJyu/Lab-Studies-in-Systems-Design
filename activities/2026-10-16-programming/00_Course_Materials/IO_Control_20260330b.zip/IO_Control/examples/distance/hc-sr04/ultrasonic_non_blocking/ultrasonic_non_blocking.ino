#define USE_UltraSonicControl
#include <IO_Control.h>

UltraSonicControl ultraSonicCtrl;

DeclareHandler(ultraSonicCtrlHandler, _ioCtrl, UltraSonicControl, {
  Serial.print("distance = ");
  Serial.print(_ioCtrl.getDistance());
  Serial.println(" cm");
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = ultraSonicCtrl.init(1, 0);
  if (err) {
    Serial.print("Fail to initialize ultraSonicCtrl. Error code = ");
    Serial.println(err);
    return;
  }
  ultraSonicCtrl.startMeasure();
  ultraSonicCtrl.enableScheduler(0, 100, ultraSonicCtrlHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
