#define USE_MPR121Control
#define USE_SH1106Control
#define USE_SSD1306Control
#define USE_AddrLEDControl
#include <IO_Control.h>

#define NUMFLAKES 10
#define XPOS 0
#define YPOS 1
#define DELTAY 2


#define LOGO16_GLCD_HEIGHT 16
#define LOGO16_GLCD_WIDTH 16
static const unsigned char PROGMEM logo16_glcd_bmp[] = { B00000000, B11000000,
                                                         B00000001, B11000000,
                                                         B00000001, B11000000,
                                                         B00000011, B11100000,
                                                         B11110011, B11100000,
                                                         B11111110, B11111000,
                                                         B01111110, B11111111,
                                                         B00110011, B10011111,
                                                         B00011111, B11111100,
                                                         B00001101, B01110000,
                                                         B00011011, B10100000,
                                                         B00111111, B11100000,
                                                         B00111111, B11110000,
                                                         B01111100, B11110000,
                                                         B01110000, B01110000,
                                                         B00000000, B00110000 };

uint8_t icons[NUMFLAKES][3];

I2CMasterControl i2cCtrl;

MPR121Control mpr121Ctrl;

SH1106Control sh1106Ctrl;

SSD1306Control ssd1306Ctrl;

AddrLEDControl addrLedCtrl;

ServoControl servoCtrl[6];

uint8_t noOfActiveServo = 0;

ToneControl toneCtrl;

ADCControl adcCtrl;

BinInControl binInCtrl;

BinOutControl binOutCtrl;

PWMControl pwmCtrl[6];

uint8_t noOfActivePWM = 0;

int currentChoice = 0;

DeclareHandler(mpr121CtrlEventHandler, _ctrl, MPR121Control, {
  if (_ctrl.status & MPR121ControlEventHandler_TouchReleaseEvent) {

    for (uint8_t i = 0; i < 12; i++) {
      if (mpr121Ctrl.touchedTimeMS[i] != 0) {
        //implement touch event here.
        Serial.print("touched i=");
        Serial.print(i);
        Serial.print(" at time=");
        Serial.println(mpr121Ctrl.touchedTimeMS[i]);
      }

      if (mpr121Ctrl.releasedTimeMS[i] != 0) {
        //implement release event here
        Serial.print("released i=");
        Serial.print(i);
        Serial.print(" at time=");
        Serial.println(mpr121Ctrl.releasedTimeMS[i]);
      }
    }
  }
});


DeclareHandler(handler, _ctrl, IOControl, {
  if (_ctrl.isSchedulerTimeEvent()) {
    if (Serial.available() > 0) {
      String input = Serial.readStringUntil('\n');
      //==================
      input.replace(" ", "");
      Serial.println(input);
      if (currentChoice == 0) {
        if (input != "\n") {
          Serial.print("You entered: ");
          Serial.println(input);
          bool isChoiceValid = true;

          int choice = input.toInt();

          switch (choice) {
            case 1:
              {
                testcase_mpr121();
                break;
              }
            case 2:
              {
                Serial.println("Enter the width of SH1106:");
                uint16_t width = getUserInput().toInt();
                Serial.println("Enter the height of SH1106:");
                uint16_t height = getUserInput().toInt();
                Serial.println("Enter I2C address of SH1106:");
                //int i2cAddr = getUserInput().toInt();
                unsigned int i2cAddr = (unsigned int)strtol(getUserInput().c_str(), NULL, 16);
                testcase_sh1106(width, height, i2cAddr);
                break;
              }
            case 3:
              {
                Serial.println("Enter the width of SSD1306:");
                uint16_t width = getUserInput().toInt();
                Serial.println("Enter the height of SSD1306:");
                uint16_t height = getUserInput().toInt();
                Serial.println("Enter I2C address of SSD1306:");
                //int i2cAddr = getUserInput().toInt();
                unsigned int i2cAddr = (unsigned int)strtol(getUserInput().c_str(), NULL, 16);
                testcase_ssd1306(width, height, i2cAddr);
                break;
              }
            case 4:
              {
                Serial.println("Enter the pin number of AddrLED:");
                uint16_t pinNum = getUserInput().toInt();
                Serial.println("Enter the number of LEDs of AddrLED:");
                uint16_t noOfLed = getUserInput().toInt();
                testcase_neopixel(pinNum, noOfLed);
                break;
              }
            case 5:
              {
                Serial.println("Enter the pin number(s) of Servo (up to 6 pins, with comma separation):");
                String pinNums = getUserInput();
                testcase_servo(pinNums);
                break;
              }
            case 6:
              {
                Serial.println("Enter the pin number of Tone:");
                uint16_t pinNum = getUserInput().toInt();
                testcase_tone(pinNum);
                break;
              }
            case 7:
              {
                Serial.println("Enter the pin number(s) of PWM (up to 6 pins, with comma separation):");
                String pinNums = getUserInput();
                testcase_pwm(pinNums);
                break;
              }
            case 8:
              {
                Serial.println("Enter the pin number of ADC:");
                uint16_t pinNum = getUserInput().toInt();
                testcase_adc(pinNum);
                break;
              }
            case 9:
              {
                Serial.println("Enter the pin number and mode(optional) for GPIO In (mode: 0 for INPUT, 1 for INPUT_PULLUP, default is INPUT, e.g. '9,1'):");
                String pinNum = getUserInput();
                testcase_gpioIn(pinNum);
                break;
              }
            case 10:
              {
                Serial.println("Enter the pin Number and initial state(optional) for GPIO Out (initial state: 0 for LOW, 1 for HIGH, default is LOW, e.g. '12,1'):");
                String pinNum = getUserInput();
                testcase_gpioOut(pinNum);
                break;
              }
            default:
              {
                Serial.println("Invalid choice. Please try again.");
                isChoiceValid = false;
              }
          }

          if (isChoiceValid) {
            currentChoice = choice;
          }
        }
      } else if (currentChoice == 1) {  //mpr121
        handleInput_mpr121(input);
      } else if (currentChoice == 2) {  //sh1106
        handleInput_sh1106(input);
      } else if (currentChoice == 3) {  //ssd1306
        handleInput_ssd1306(input);
      } else if (currentChoice == 4) {  //addrLed
        handleInput_addrLed(input);
      } else if (currentChoice == 5) {
        handleInput_servo(input);
      } else if (currentChoice == 6) {
        handleInput_tone(input);
      } else if (currentChoice == 7) {
        handleInput_pwm(input);
      } else if (currentChoice == 8) {
        handleInput_adc(input);
      } else if (currentChoice == 9) {
        handleInput_gpioIn(input);
      } else if (currentChoice == 10) {
        handleInput_gpioOut(input);
      }
      //==================
    }

    if (currentChoice == 2) {
      drawBitMap_sh1106();
    } else if (currentChoice == 3) {
      drawBitMap_ssd1306();
    }
  }
});

DeclareHandler(adcHandler, _ctrl, ADCControl, {
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  int val0 = _ctrl.read();
  Serial.print("time=");
  Serial.print(_ctrl.handlerCurrentMillis);
  Serial.print(" adc0=");
  Serial.println(val0);
});

DeclareHandler(binInHandler, _ctrl, BinInControl, {
  if (_ctrl.isBinInTriggered()) {
    Serial.print("event time=");
    Serial.print(_ctrl.getInterruptTime());
    if (_ctrl.getInterruptState())
      Serial.println(" from LOW to HIGH");
    else
      Serial.println(" from HIGH to LOW");
  }
});

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  displayMenu();  // Display menu initially

  IO_Control.enableScheduler(0, 10, handler);
}

void loop() {
  IO_Control.execute();
}

void displayMenu() {
  Serial.println();
  Serial.println("Menu:");
  Serial.println("1: MPR121");
  Serial.println("2: SH1106");
  Serial.println("3: SSD1306");
  Serial.println("4: Neo Pixel");
  Serial.println("5: Servo");
  Serial.println("6: Tone");
  Serial.println("7: PWM");
  Serial.println("8: ADC");
  Serial.println("9: GPIO IN");
  Serial.println("10: GPIO OUT");
  Serial.println("Enter your choice:");
}

void displayMenu_addrLed() {
  Serial.println();
  Serial.println("Menu:");
  Serial.println("1: setRGB");
  Serial.println("2: setHSV");
  Serial.println("x: leave AddrLEDControl Menu");
  Serial.println("Enter your choice:");
}

void displayMenu_servo() {
  Serial.println();
  Serial.println("Menu:");
  Serial.print("Enter angle for # of servo=");
  Serial.print(noOfActiveServo);
  Serial.println(" OR enter 'x' to go back main menu");
}

void displayMenu_tone() {
  Serial.println();
  Serial.println("Menu:");
  Serial.print("Enter frequecy & duty (max=");
  Serial.print(toneCtrl.getMaxDuty());
  Serial.println(") & duration (in ms) OR enter 'x' to go back main menu");
}

void displayMenu_pwm() {
  Serial.println();
  Serial.println("Menu:");
  Serial.print("Enter PWM value (max=");
  Serial.print(pwmCtrl[0].getMaxDuty());
  Serial.print(") and for # of pins=");
  Serial.print(noOfActivePWM);
  Serial.println(" OR enter 'x' to go back main menu");
}

void displayMenu_adc() {
  Serial.println();
  Serial.println("Showing value of ADC. Enter 'x' to leave and go back main menu");
}

void displayMenu_gpioIn() {
  Serial.println();
  Serial.println("The value of selected pin will be shown when input is received. Enter 'x' to leave and go back main menu");
}

void displayMenu_gpioOut() {
  Serial.println();
  Serial.println("Menu:");
  Serial.println("Enter value (0 or 1) OR enter 'x' to go back main menu");
}

void displayMenu_mpr121() {
  Serial.println();
  Serial.println("Touch and Release MPR121 to see the result. Enter 'x' to leave MPR121 testing");
}

void testcase_mpr121() {
  // Implement Test Case 1 logic here
  Serial.println("\nRunning testcase_mpr121...");
  err_t err;

  //err = i2cCtrl.init(0, 6, 10);
  err = i2cCtrl.init(0, 10, 6);

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize I2CMasterControl. Reason is: ");
    switch (err) {
      case I2CMasterControl_InvalidI2CIndex:
        Serial.println("I2C index is invalid. Only 0 is allowed");
        break;
      case I2CMasterControl_InvalidSCL:
        Serial.println("SCL pin is invalid");
        break;
      case I2CMasterControl_InvalidSDA:
        Serial.println("SDA pin is invalid");
        break;
      case I2CMasterControl_InvalidClkFreq:
        Serial.println("Clock Frequency is invalid");
        break;
    }
  } else {
    Serial.println("I2CMasterControl is initialized successfully");
  }

  err = mpr121Ctrl.init(i2cCtrl, 0x5A, 7, 1000, 10, mpr121CtrlEventHandler);

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize MPR121Control. Reason is: ");
    switch (err) {
      case MPR121Control_I2CNotActive:
        Serial.println("I2CMasterControl is not active");
        break;
      case Control_NullEventHandler:
        Serial.println("MPR121Control Event Handler is null");
        break;
      case MPR121Control_I2CAddrError:
        Serial.println("I2C address is invalid for MPR121Control");
        break;
      case MPR121Control_IRQInvalid:
        Serial.println("IRQ pin is invalid for MPR121Control");
        break;
    }
  } else {
    Serial.println("MPR121Control is initialized successfully");
    displayMenu_mpr121();
  }
}

void testcase_sh1106(uint16_t width, uint16_t height, int i2cAddr) {
  // Implement Test Case 2 logic here
  Serial.println("\nRunning testcase_sh1106...");

  err_t err;

  err = i2cCtrl.init(0, 10, 6);

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize I2CMasterControl. Reason is: ");
    switch (err) {
      case I2CMasterControl_InvalidI2CIndex:
        Serial.println("I2C index is invalid. Only 0 is allowed");
        break;
      case I2CMasterControl_InvalidSCL:
        Serial.println("SCL pin is invalid");
        break;
      case I2CMasterControl_InvalidSDA:
        Serial.println("SDA pin is invalid");
        break;
      case I2CMasterControl_InvalidClkFreq:
        Serial.println("Clock Frequency is invalid");
        break;
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("I2CMasterControl is initialized successfully");
  }


  err = sh1106Ctrl.init(i2cCtrl, i2cAddr, width, height, -1);

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize SH1106Control. Reason is: ");
    switch (err) {
      case SH1106Control_I2CNotActive:
        Serial.println("I2CMasterControl is not active");
        break;
      case SH1106Control_I2CAddrError:
        Serial.println("I2C address is invalid for SH1106Control");
        break;
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("Successfully request sh1106Ctrl");
    sh1106Ctrl.getDisplay().display();
    sh1106Ctrl.getDisplay().clearDisplay();
    sh1106Ctrl.getDisplay().setTextSize(1);
    sh1106Ctrl.getDisplay().setTextColor(SH110X_WHITE);
    sh1106Ctrl.getDisplay().setTextWrap(true);
    sh1106Ctrl.getDisplay().setCursor(0, 0);
    sh1106Ctrl.getDisplay().println("Successfully request sh1106Ctrl");
    sh1106Ctrl.getDisplay().display();
    sh1106Ctrl.getDisplay().clearDisplay();
    initTestdrawbitmap_sh1106(logo16_glcd_bmp, LOGO16_GLCD_HEIGHT, LOGO16_GLCD_WIDTH);

    Serial.println("Enter 'x' to go back to Menu");
    return;
  }
}


void testcase_ssd1306(uint16_t width, uint16_t height, int i2cAddr) {
  // Implement Test Case 2 logic here
  Serial.println("\nRunning testcase_ssd1306...");

  err_t err;

  err = i2cCtrl.init(0, 10, 6);

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize I2CMasterControl. Reason is: ");
    switch (err) {
      case I2CMasterControl_InvalidI2CIndex:
        Serial.println("I2C index is invalid. Only 0 is allowed");
        break;
      case I2CMasterControl_InvalidSCL:
        Serial.println("SCL pin is invalid");
        break;
      case I2CMasterControl_InvalidSDA:
        Serial.println("SDA pin is invalid");
        break;
      case I2CMasterControl_InvalidClkFreq:
        Serial.println("Clock Frequency is invalid");
        break;
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("I2CMasterControl is initialized successfully");
  }

  err = ssd1306Ctrl.init(i2cCtrl, i2cAddr, width, height, -1);

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize SSD1306Control. Reason is: ");
    switch (err) {
      case SSD1306Control_I2CNotActive:
        Serial.println("I2CMasterControl is not active");
        break;
      case SSD1306Control_I2CAddrError:
        Serial.println("I2C address is invalid for SSD1306Control");
        break;
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("Successfully request ssd1306Ctrl");
    ssd1306Ctrl.getDisplay().display();
    ssd1306Ctrl.getDisplay().clearDisplay();
    ssd1306Ctrl.getDisplay().setTextSize(1);
    ssd1306Ctrl.getDisplay().setTextColor(SH110X_WHITE);
    ssd1306Ctrl.getDisplay().setTextWrap(true);
    ssd1306Ctrl.getDisplay().setCursor(0, 0);
    ssd1306Ctrl.getDisplay().println("Successfully request ssd1306Ctrl");
    ssd1306Ctrl.getDisplay().display();
    ssd1306Ctrl.getDisplay().clearDisplay();
    initTestdrawbitmap_ssd1306(logo16_glcd_bmp, LOGO16_GLCD_HEIGHT, LOGO16_GLCD_WIDTH);

    Serial.println("Enter 'x' to go back to Menu");
    return;
  }
}


void testcase_neopixel(int pinNum, int noOfLed) {
  // Implement Test Case 3 logic here
  err_t err;
  Serial.println("\nRunning testcase_neopixel...");
  err = addrLedCtrl.init(pinNum, noOfLed, false);  //just need to test whether it can light up. Do not need sequence function.

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize AddrLEDControl. Reason is: ");
    switch (err) {
      case AddrLEDControl_InvalidPinIndex:
        Serial.println("Pin is invalid");
        break;
    }

    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("AddrLEDControl is requested successfully");
    std::vector<int> targets;
    for (uint8_t i = 0; i < noOfLed; i++) {
      targets.push_back(i);
    }
    displayMenu_addrLed();

    Serial.println("Enter 'x' to go back to Menu");
    return;
  }
}


void testcase_servo(String _pinNums) {
  int pinNums[6];
  int numOfInput = extractValues_int(_pinNums, ',', pinNums, 6);
  bool isAllServoInitSuccessful = true;

  for (int i = 0; i < numOfInput; i++) {
    err_t err;
    Serial.println("Running testcase_servo...");
    err = servoCtrl[i].init(pinNums[i], false);
    if (err != Control_OK) {
      isAllServoInitSuccessful = false;
      Serial.print("Error: Fail to initialize ServoControl. Reason is: ");
      switch (err) {
        case ServoControl_InvalidPinIndex:
          Serial.println("Pin is invalid");
          break;
      }
    }
  }

  if (isAllServoInitSuccessful) {
    noOfActiveServo = numOfInput;
    Serial.print("ServoControl is requested successfully (no of servo=");
    Serial.println(numOfInput);
    displayMenu_servo();
  } else {
    Serial.println("Enter 'x' to go back to Menu");
    return;
  }
}

void testcase_tone(int pinNum) {
  err_t err;
  Serial.println("\nRunning testcase_tone...");
  err = toneCtrl.init(pinNum, false);
  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize ToneControl. Reason is: ");
    switch (err) {
      case ToneControl_InvalidPinIndex:
        Serial.println("Pin is invalid");
        break;
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("ToneControl is requested successfully");
    displayMenu_tone();
  }
}

void testcase_pwm(String _pinNums) {
  int pinNums[6];
  int numOfInput = extractValues_int(_pinNums, ',', pinNums, 6);
  bool isAllPWMInitSuccessful = true;

  for (int i = 0; i < numOfInput; i++) {
    err_t err;
    Serial.println("Running testcase_pwm...");
    err = pwmCtrl[i].init(pinNums[i], false);
    if (err != Control_OK) {
      isAllPWMInitSuccessful = false;
      Serial.print("Error: Fail to initialize PWMControl. Reason is: ");
      switch (err) {
        case PWMControl_InvalidPinIndex:
          Serial.println("Pin is invalid");
          break;
      }
    }
  }

  if (isAllPWMInitSuccessful) {
    noOfActivePWM = numOfInput;
    Serial.println("PWMControl is requested successfully");
    displayMenu_pwm();
  }
}

void testcase_adc(int pinNum) {
  err_t err;
  Serial.println("\nRunning testcase_adc...");
  err = adcCtrl.init(1, pinNum, true);
  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize ADCControl. Reason is: ");
    switch (err) {
      case ADCControl_InvalidADC:
        Serial.println("Pin is invalid");
        break;
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("ADCControl is requested successfully");
    adcCtrl.enableScheduler(0, 500, adcHandler);
    displayMenu_adc();
  }
}

void testcase_gpioIn(String _inputs) {
  int inputs[2];
  int numOfInput = extractValues_int(_inputs, ',', inputs, 2);
  err_t err = -40;
  Serial.println("\nRunning testcase_gpioIn...");
  if (numOfInput == 1) {
    err = binInCtrl.init(inputs[0], INPUT);
  } else if (numOfInput == 2) {
    if (inputs[1] == 0) {
      err = binInCtrl.init(inputs[0], INPUT);
    } else if (inputs[1] == 1) {
      err = binInCtrl.init(inputs[0], INPUT_PULLUP);
    }
  }
  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize BinInControl. Reason is: ");
    switch (err) {
      case BinInControl_InvalidPinMode:
        Serial.println("Pin Mode is invalid");
        break;
      case BinInControl_InvalidPinIndex:
        Serial.println("Pin Index is invalid");
        break;
      case BinInControl_InterruptNotEnabled:
        Serial.println("Interrupt is not enabled");
        break;
      default:
        Serial.println("Invalid input");
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("BinInControl is requested successfully");
    binInCtrl.enableScheduler(0, 200, binInHandler);
    binInCtrl.enableInterrupt(CHANGE);
    displayMenu_gpioIn();
  }
}

void testcase_gpioOut(String _inputs) {
  int inputs[2];
  int numOfInput = extractValues_int(_inputs, ',', inputs, 2);
  err_t err = -40;
  Serial.println("\nRunning testcase_gpioOut...");
  if (numOfInput == 1) {
    err = binOutCtrl.init(inputs[0], LOW);
  } else if(numOfInput == 2) {
    if(inputs[1] == 0) {
      err = binOutCtrl.init(inputs[0], LOW);
    } else if(inputs[1] == 1) {
      err = binOutCtrl.init(inputs[0], HIGH);
    }
  }

  if (err != Control_OK) {
    Serial.print("Error: Fail to initialize BinOutControl. Reason is: ");
    switch (err) {
      case BinOutControl_InvalidPinIndex:
        Serial.println("Pin Index is invalid");
        break;
      default:
        Serial.println("Invalid input");
    }
    Serial.println("Enter 'x' to go back to Menu");
    return;
  } else {
    Serial.println("BinOutControl is requested successfully");
    displayMenu_gpioOut();
  }
}

String getUserInput() {
  while (!Serial.available()) {
    // Wait for user input
    yield();
  }
  return Serial.readStringUntil('\n');
}

void handleInput_mpr121(String input) {
  if (input == "x") {
    currentChoice = 0;
    mpr121Ctrl.release();
    i2cCtrl.release();
    displayMenu();
  }
}

void handleInput_sh1106(String input) {
  if (input == "x") {
    currentChoice = 0;
    sh1106Ctrl.getDisplay().clearDisplay();
    sh1106Ctrl.getDisplay().display();
    sh1106Ctrl.release();
    i2cCtrl.release();
    displayMenu();
  }
}

void handleInput_ssd1306(String input) {
  if (input == "x") {
    currentChoice = 0;
    ssd1306Ctrl.getDisplay().clearDisplay();
    ssd1306Ctrl.getDisplay().display();
    ssd1306Ctrl.release();
    i2cCtrl.release();
    displayMenu();
  }
}

void handleInput_addrLed(String input) {
  Serial.println("handleInput_addrLed is called");
  if (input == "x") {
    currentChoice = 0;
    addrLedCtrl.release();
    displayMenu();
    return;
  } else if (input == "1") {  //setRGB
    Serial.println("Enter parameters (index,r,g,b OR start_index,end_index,r,g,b): ");
    String userInput = getUserInput();
    int inputs[5];
    int numOfInput = extractValues_int(userInput, ',', inputs, 5);
    std::vector<int> targets;
    if (numOfInput == 4) {
      targets.push_back(inputs[0]);
      addrLedCtrl.setRGB(targets, inputs[1], inputs[2], inputs[3]);
    } else if (numOfInput == 5) {
      for (uint8_t i = inputs[0]; i <= inputs[1]; i++) {
        targets.push_back(i);
      }
      addrLedCtrl.setRGB(targets, inputs[2], inputs[3], inputs[4]);
    } else {
      Serial.println("Invalid input");
    }
  } else if (input == "2") {  //setHSV
    Serial.println("Enter parameters (index,h,s,v OR start_index,end_index,h,s,v): ");
    String userInput = getUserInput();
    int inputs[5];
    int numOfInput = extractValues_int(userInput, ',', inputs, 5);
    std::vector<int> targets;
    if (numOfInput == 4) {
      targets.push_back(inputs[0]);
      addrLedCtrl.setHSV(targets, inputs[1], inputs[2], inputs[3]);
    } else if (numOfInput == 5) {
      for (uint8_t i = inputs[0]; i <= inputs[1]; i++) {
        targets.push_back(i);
      }
      addrLedCtrl.setHSV(targets, inputs[2], inputs[3], inputs[4]);
    } else {
      Serial.println("Invalid input");
    }
  } else {
    Serial.println("Invalid input");
  }
  displayMenu_addrLed();
}

void handleInput_servo(String input) {
  if (input == "x") {
    currentChoice = 0;
    for (uint8_t i = 0; i < noOfActiveServo; i++) {
      servoCtrl[i].release();
    }
    noOfActiveServo = 0;
    displayMenu();
    return;
  } else {
    double angles[noOfActiveServo];
    int numOfInput = extractValues_double(input, ',', angles, noOfActiveServo);
    for (uint8_t i = 0; i < numOfInput; i++) {
      servoCtrl[i].setAngle(angles[i]);
    }
  }
  displayMenu_servo();
}

void handleInput_tone(String input) {
  if (input == "x") {
    currentChoice = 0;
    toneCtrl.release();
    displayMenu();
    return;
  } else {
    uint32_t inputs[3];
    int numOfInput = extractValues_ulong(input, ',', inputs, 3);
    if (numOfInput < 3) {
      Serial.println("Invalid Input");
    } else {
      toneCtrl.setTone(inputs[0], inputs[1]);
      delay(inputs[2]);
      toneCtrl.setDuty(0);
    }
  }
  displayMenu_tone();
}

void handleInput_pwm(String input) {
  if (input == "x") {
    currentChoice = 0;
    for (uint8_t i = 0; i < noOfActivePWM; i++) {
      pwmCtrl[i].release();
    }
    noOfActivePWM = 0;
    displayMenu();
    return;
  } else {
    int values[noOfActivePWM];
    int numOfInput = extractValues_int(input, ',', values, noOfActivePWM);
    for (uint8_t i = 0; i < numOfInput; i++) {
      pwmCtrl[i].setDuty(values[i]);
    }
  }
  displayMenu_pwm();
}

void handleInput_adc(String input) {
  if (input == "x") {
    currentChoice = 0;
    adcCtrl.release();
    displayMenu();
  }
}

void handleInput_gpioIn(String input) {
  if (input == "x") {
    currentChoice = 0;
    binInCtrl.release();
    displayMenu();
  }
}

void handleInput_gpioOut(String input) {
  if (input == "x") {
    currentChoice = 0;
    binOutCtrl.release();
    displayMenu();
    return;
  } else {
    if (input.toInt() == 0 || input.toInt() == 1) {
      binOutCtrl.write(input.toInt());
    } else {
      Serial.println("Input can only be 0 OR 1 OR 'x' for going back main menu");
    }
  }
  displayMenu_gpioOut();
}

void initTestdrawbitmap_sh1106(const uint8_t* bitmap, uint8_t w, uint8_t h) {
  for (uint8_t f = 0; f < NUMFLAKES; f++) {
    icons[f][XPOS] = random(sh1106Ctrl.getDisplay().width());
    icons[f][YPOS] = 0;
    icons[f][DELTAY] = random(5) + 1;
  }
}

void initTestdrawbitmap_ssd1306(const uint8_t* bitmap, uint8_t w, uint8_t h) {
  for (uint8_t f = 0; f < NUMFLAKES; f++) {
    icons[f][XPOS] = random(ssd1306Ctrl.getDisplay().width());
    icons[f][YPOS] = 0;
    icons[f][DELTAY] = random(5) + 1;
  }
}

void drawBitMap_sh1106() {
  // draw each icon
  for (uint8_t f = 0; f < NUMFLAKES; f++) {
    sh1106Ctrl.getDisplay().drawBitmap(icons[f][XPOS], icons[f][YPOS], logo16_glcd_bmp, LOGO16_GLCD_WIDTH, LOGO16_GLCD_HEIGHT, SH110X_WHITE);
  }
  sh1106Ctrl.getDisplay().display();
  delay(200);

  // then erase it + move it
  for (uint8_t f = 0; f < NUMFLAKES; f++) {
    sh1106Ctrl.getDisplay().drawBitmap(icons[f][XPOS], icons[f][YPOS], logo16_glcd_bmp, LOGO16_GLCD_WIDTH, LOGO16_GLCD_HEIGHT, SH110X_BLACK);
    // move it
    icons[f][YPOS] += icons[f][DELTAY];
    // if its gone, reinit
    if (icons[f][YPOS] > sh1106Ctrl.getDisplay().height()) {
      icons[f][XPOS] = random(sh1106Ctrl.getDisplay().width());
      icons[f][YPOS] = 0;
      icons[f][DELTAY] = random(5) + 1;
    }
  }
}

void drawBitMap_ssd1306() {
  // draw each icon
  for (uint8_t f = 0; f < NUMFLAKES; f++) {
    ssd1306Ctrl.getDisplay().drawBitmap(icons[f][XPOS], icons[f][YPOS], logo16_glcd_bmp, LOGO16_GLCD_WIDTH, LOGO16_GLCD_HEIGHT, SH110X_WHITE);
  }
  ssd1306Ctrl.getDisplay().display();
  delay(200);

  // then erase it + move it
  for (uint8_t f = 0; f < NUMFLAKES; f++) {
    ssd1306Ctrl.getDisplay().drawBitmap(icons[f][XPOS], icons[f][YPOS], logo16_glcd_bmp, LOGO16_GLCD_WIDTH, LOGO16_GLCD_HEIGHT, SH110X_BLACK);
    // move it
    icons[f][YPOS] += icons[f][DELTAY];
    // if its gone, reinit
    if (icons[f][YPOS] > ssd1306Ctrl.getDisplay().height()) {
      icons[f][XPOS] = random(ssd1306Ctrl.getDisplay().width());
      icons[f][YPOS] = 0;
      icons[f][DELTAY] = random(5) + 1;
    }
  }
}

int extractValues_int(String input, char delimiter, int* values, uint8_t expectedNumberOfInput) {
  int startPos = 0;
  int endPos = 0;
  int index = 0;

  while ((endPos = input.indexOf(delimiter, startPos)) != -1) {
    // Extract the value between startPos and endPos
    String value = input.substring(startPos, endPos);

    // Remove any unnecessary spaces from the extracted value
    value.trim();

    // Store the extracted value into the array
    values[index++] = value.toInt();

    // Update startPos to the position after the delimiter
    startPos = endPos + 1;

    // Break if the maximum number of values is reached
    if (index >= expectedNumberOfInput) {
      break;
    }
  }

  // Extract the last value after the last delimiter
  String value = input.substring(startPos);
  value.trim();

  // Store the last extracted value into the array if there's space
  if (index < expectedNumberOfInput) {
    values[index++] = value.toInt();
  }

  // Return the number of values extracted
  return index;
}

int extractValues_double(String input, char delimiter, double* values, uint8_t expectedNumberOfInput) {
  int startPos = 0;
  int endPos = 0;
  int index = 0;

  while ((endPos = input.indexOf(delimiter, startPos)) != -1) {
    // Extract the value between startPos and endPos
    String value = input.substring(startPos, endPos);

    // Remove any unnecessary spaces from the extracted value
    value.trim();

    // Store the extracted value into the array
    values[index++] = value.toDouble();

    // Update startPos to the position after the delimiter
    startPos = endPos + 1;

    // Break if the maximum number of values is reached
    if (index >= expectedNumberOfInput) {
      break;
    }
  }

  // Extract the last value after the last delimiter
  String value = input.substring(startPos);
  value.trim();

  // Store the last extracted value into the array if there's space
  if (index < expectedNumberOfInput) {
    values[index++] = value.toDouble();
  }

  // Return the number of values extracted
  return index;
}

int extractValues_ulong(String input, char delimiter, uint32_t* values, uint8_t expectedNumberOfInput) {
  int startPos = 0;
  int endPos = 0;
  int index = 0;

  while ((endPos = input.indexOf(delimiter, startPos)) != -1) {
    // Extract the value between startPos and endPos
    String value = input.substring(startPos, endPos);

    // Remove any unnecessary spaces from the extracted value
    value.trim();

    // Store the extracted value into the array
    values[index++] = value.toDouble();

    // Update startPos to the position after the delimiter
    startPos = endPos + 1;

    // Break if the maximum number of values is reached
    if (index >= expectedNumberOfInput) {
      break;
    }
  }

  // Extract the last value after the last delimiter
  String value = input.substring(startPos);
  value.trim();

  // Store the last extracted value into the array if there's space
  if (index < expectedNumberOfInput) {
    values[index++] = value.toDouble();
  }

  // Return the number of values extracted
  return index;
}