#define USE_AddrLEDControl
#define USE_DFPlayerMP3Control
#include <IO_Control.h>
#include "userDefSeq.h"

void setup() {
  IO_Control.begin();

  Serial.begin(115200);

  err_t err = initCtrlObjs();

  if (err) {
    releaseCtrlObjs();
    Serial.print("Error occurs when initializing control objects: ");
    Serial.println(err);
    return;
  }

  err = setupSequences();

  if (err) {
    Serial.print("Error occurs when initializing control objects: ");
    Serial.println(err);
    return;
  }

  Serial.println("Enter index of sequence set to be played");
}

void loop() {
  IO_Control.execute();

  if (Serial.available()) {

    String a = Serial.readStringUntil('\n');

    Serial.print("You entered: ");

    Serial.println(a);

    handleInput(a);
  }
}

void handleInput(String userInput) {
  int i = userInput.toInt();
  if (isAllFinish()) {
    playSetSequence(i);
  }
}
