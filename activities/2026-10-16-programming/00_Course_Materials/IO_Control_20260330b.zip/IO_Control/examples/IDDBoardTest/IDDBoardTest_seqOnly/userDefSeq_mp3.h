DFPlayerMP3Control mp3Ctrl_0;

DFPlayerSequence mp3Seq_0;
DFPlayerSequence mp3Seq_1;

/*
  commands:
  addCommand(index, volume, duration_ms, loop_after_end, fade_in_time, fade_out_time)
  - index - index of the MP3 file in micro SD card; 0 for no audio, 1 refers to the first file, 2 for second, and so on
  - volume - from 0 to 30 (30 is maximum volume)
  - duration_ms - in milliseconds
  - loop_after_end - true if loop after end, false if not
  - fade_in_time - time in milliseconds for fade-in
  - fade_out_time - time in milliseconds for fade-out
  
  addPause(duration_ms);
  - duration_ms - in milliseconds
*/


err_t initMp3CtrlObjs() {
  err_t err;

  //  MP3 player is associated with IO19, IO18 and IO08
  err = mp3Ctrl_0.init(19, 18, 8);
  if (err) {
    return err;
  }
  mp3Ctrl_0.enableScheduler(0, 100, nullptr);

  return Control_OK;
}

err_t clearMp3CtrlObjs() {

  mp3Seq_0.clearCommand();
  mp3Seq_1.clearCommand();

  mp3Ctrl_0.release();

  return Control_OK;
}

bool isAllFinish_mp3() {
  if (!mp3Ctrl_0.isInit()) {
    return false;
  }

  if (mp3Ctrl_0.isPlaying()) {
    return false;
  }
  return true;
}

err_t setMp3Sequences() {
  err_t err;

  //  define mp3Seq_0
  err = mp3Seq_0.addCommand(1, 30, 3000, true);
  if (err) {
    return err;
  }
  err = mp3Seq_0.addPause(1000);  //equivalent to addCommand(0 ,0, 1000)
  if (err) {
    return err;
  }
  err = mp3Seq_0.addCommand(2, 20, 6000, false, 1000, 1000);
  if (err) {
    return err;
  }

  //  define mp3Seq_1
  err = mp3Seq_1.addCommand(2, 15, 3000, true);
  if (err) {
    return err;
  }
  err = mp3Seq_1.addPause(1000);  //equivalent to addCommand(0 ,0, 1000)
  if (err) {
    return err;
  }
  err = mp3Seq_1.addCommand(1, 20, 6000, false, 0, 1000);
  if (err) {
    return err;
  }

  return Control_OK;
}