struct ServoCtrlSeqPair {
  ServoControl* servoCtrl;
  ServoSequence servoSeq;
};

//  each ServoControl object corresponds to one servo motor
ServoControl servoCtrl_0;
ServoControl servoCtrl_1;

//  one ServoSequence object corresponds to angle of a servo motor at specific time
ServoSequence servoSeq_0;
ServoSequence servoSeq_1;
ServoSequence servoSeq_2;
ServoSequence servoSeq_3;

/*
  commands:
  
  addSetAngle(duration_ms, angle, ctrl)
  - duration_ms - in milliseconds
  - angle - in degree
  addMoveFromToAngle(duration_ms, start_angle, end_angle, ctrl)
  - duration_ms - in milliseconds
  - start_angle - starting angle, in degree
  - end_angle - ending angle, in degree
*/

err_t initServoCtrlObjs() {
  err_t err;
  //  associate servoCtrl_0 with IO12
  err = servoCtrl_0.init(12, true);
  if (err) {
    return err;
  }
  servoCtrl_0.enableScheduler(0, 100, nullptr);

  //  associate servoCtrl_1 with IO13
  err = servoCtrl_1.init(13, true);
  if (err) {
    return err;
  }
  servoCtrl_1.enableScheduler(0, 100, nullptr);
  
  //  Note that servoCtrl_0 and servoCtrl_1 are having the same angle range

  return Control_OK;
}

err_t clearServoCtrlObjs() {

  //  clear all ServoSequence objects
  servoSeq_0.clearCommand();
  servoSeq_1.clearCommand();
  servoSeq_2.clearCommand();
  servoSeq_3.clearCommand();
  
  //  release all ServoControl objects
  servoCtrl_0.release();
  servoCtrl_1.release();

  return Control_OK;
}

bool isAllFinish_servo() {

  if (servoCtrl_0.isPlaying()) {
    return false;
  }
  if (servoCtrl_1.isPlaying()) {
    return false;
  }

  return true;
}

err_t setServoSequences() {
  err_t err;
  
  //
  //  define servoSeq_0
  //  - start at 20, (repeat twice) slow from 20 to 160, fast from 160 to 20
  //  - duration: 5400ms
  //
  err = servoSeq_0.addSetAngle(400,20,servoCtrl_0);    
    //  as angular speed of SG90 = 0.12/60deg without load. 400ms should be sufficient for servo to move to 20deg as maximum angular travel = 160-20 = 140deg
  if (err) {
    return err;
  }
  err = servoSeq_0.addMoveFromToAngle(2000, 20, 160, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_0.addMoveFromToAngle(500, 160, 20, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_0.addMoveFromToAngle(2000, 20, 160, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_0.addMoveFromToAngle(500, 160, 20, servoCtrl_0);
  if (err) {
    return err;
  }

  //
  //  define servoSeq_1
  //  - start at 160, (repeat twice) slow from 160 to 20, fast from 20 to 160
  //  - duration: 5400ms
  //
  err = servoSeq_1.addSetAngle(400,160,servoCtrl_0);
    //  as angular speed of SG90 = 0.12/60deg without load. 400ms should be sufficient for servo to move to 160deg as maximum angular travel = 160-20 = 140deg
  if (err) {
    return err;
  }
  err = servoSeq_1.addMoveFromToAngle(2000, 160, 20, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_1.addMoveFromToAngle(500, 20, 160, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_1.addMoveFromToAngle(2000, 160, 20, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_1.addMoveFromToAngle(500, 20, 160, servoCtrl_0);
  if (err) {
    return err;
  }
  
  //
  //  define servoSeq_2
  //  - start at 90, fast from 90 to 160, slow from 160 to 100, slow from 100 to 50, fast from 50 to 20
  //  - duration: 5400ms

  err = servoSeq_2.addSetAngle(200,90,servoCtrl_0);
    //  as angular speed of SG90 = 0.12/60deg without load. 200ms should be sufficient for servo to 90deg as maximum angular travel = max(160-90,90-20) = 70deg
  if (err) {
    return err;
  }
  err = servoSeq_2.addMoveFromToAngle(500, 90, 160, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_2.addMoveFromToAngle(2100, 160, 100, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_2.addMoveFromToAngle(2100, 100, 50, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_2.addMoveFromToAngle(500, 50, 20, servoCtrl_0);
  if (err) {
    return err;
  }
  
  //
  //  define servoSeq_3
  //  - start at 80,  - slow from 80 to 120, slow from 120 to 80
  //  - duration: 4300ms
  //
  err = servoSeq_3.addSetAngle(300,80,servoCtrl_0);
    //  as angular speed of SG90 = 0.12/60deg without load. 300ms should be sufficient for servo to 90deg as maximum angular travel = max(160-80,80-20) = 80deg
  if (err) {
    return err;
  }
  err = servoSeq_3.addMoveFromToAngle(2000, 80, 120, servoCtrl_0);
  if (err) {
    return err;
  }
  err = servoSeq_3.addMoveFromToAngle(2000, 120, 80, servoCtrl_0);
  if (err) {
    return err;
  }  

  return Control_OK;
}