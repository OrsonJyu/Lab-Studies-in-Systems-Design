//
//  for demonstrating display of current time since reset on an OLED display, 
//  either a SH1106 or SSD1306 OLED display
//    circuit:
//      3.3V - VCC of OLED display
//      GND  - GND of OLED display
//      IO10 - SCL
//      IO06 - SDA
//
#define USE_SH1106Control
#define USE_SSD1306Control
#define USE_WiFiControl
#include <IO_Control.h>
#include <TimeLib.h>

#define SH1106
//#define SSD1306

WiFiControl wifiCtrl;
I2CMasterControl i2cCtrl;
#ifdef SH1106
SH1106Control oledCtrl;
#endif
#ifdef SSD1306
SSD1306Control oledCtrl;
#endif

time_t getTime() {
  return millis() / 1000;
}

#ifdef SH1106
DeclareHandler(oledHandler, _ctrl, SH1106Control,
#endif
#ifdef SSD1306
  DeclareHandler(oledHandler, _ctrl, SSD1306Control,
#endif
{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("MPR121Control - SchedulerTimerEvent");

  _ctrl.getDisplay().display();
  _ctrl.getDisplay().clearDisplay();
  _ctrl.getDisplay().setTextSize(2);
  _ctrl.getDisplay().setTextColor(SH110X_WHITE);
  _ctrl.getDisplay().setTextWrap(true);
  _ctrl.getDisplay().setCursor(0, 0);
  _ctrl.getDisplay().println(addLeadingZero(String(hour()), 2) + ":" + addLeadingZero(String(minute()), 2) + ":" + addLeadingZero(String(second()), 2));
  _ctrl.getDisplay().display();
  // _ctrl.getDisplay().setTextSize(1);
  // _ctrl.getDisplay().setTextColor(SH110X_WHITE);
  // _ctrl.getDisplay().setTextWrap(true);
  // _ctrl.getDisplay().setCursor(0, 0);
  // Serial.println(timeClient.getFormattedTime());
  // Serial.println(timeClient.getEpochTime());
});

String addLeadingZero(String _str, int _len) {  //  add "0" in front of _str to make the whole string to length _len
  if (_str.length() >= _len)
    //  do nothing when length of _str >= _len
    return _str;

  for (int i = 0; i < _len - _str.length(); i++) {
    _str = "0" + _str;
  }
  return _str;
}

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  setSyncProvider(getTime);

  err_t err;

  err = i2cCtrl.init(0, 10, 6);  //  use i2cNum=0, SCL=6, SDA=10
  if (err) {
    Serial.print("Fail to initialize i2cCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  err = oledCtrl.init(i2cCtrl, 0x3c, 128, 64, -1);
  if (err) {
    Serial.print("Fail to initialize oledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  oledCtrl.enableScheduler(0, 1000, oledHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
