//
//  for demonstrating use of NTP client to get current time and display on an OLED display, 
//  either a SH1106 or SSD1306 OLED display
//    board: Luatos ESP32C3 board
//    circuit:
//      3.3V - VCC of OLED display
//      GND  - GND of OLED display
//      IO10 - SCL
//      IO06 - SDA
//
//  modified from oled_display_time in examples of IO_Control 
//  

#define USE_SH1106Control
#define USE_SSD1306Control
#define USE_WiFiControl
#include <IO_Control.h>
#include <WiFiUdp.h>
#include <NTPClient.h>

#define SH1106
//#define SSD1306

WiFiControl wifiCtrl;
I2CMasterControl i2cCtrl;
#ifdef SH1106
SH1106Control oledCtrl;
#endif
#ifdef SSD1306
SSD1306Control oledCtrl;
#endif

const char* ssid = "LAPTOP-AF6GVOH4";

const char* password = "jFRww8jM0v2JQnAAGFu0";

WiFiUDP ntpUDP;

NTPClient timeClient(ntpUDP);

#ifdef SH1106
DeclareHandler(oledHandler, _ctrl, SH1106Control,
#endif
#ifdef SSD1306
  DeclareHandler(oledHandler, _ctrl, SSD1306Control,
#endif
{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("MPR121Control - SchedulerTimerEvent");

  _ctrl.getDisplay().display();
  _ctrl.getDisplay().clearDisplay();
  _ctrl.getDisplay().setTextSize(2);
  _ctrl.getDisplay().setTextColor(SH110X_WHITE);
  _ctrl.getDisplay().setTextWrap(true);
  _ctrl.getDisplay().setCursor(0, 0);
  _ctrl.getDisplay().println(timeClient.getFormattedTime());
  _ctrl.getDisplay().display();
  // _ctrl.getDisplay().setTextSize(1);
  // _ctrl.getDisplay().setTextColor(SH110X_WHITE);
  // _ctrl.getDisplay().setTextWrap(true);
  // _ctrl.getDisplay().setCursor(0, 0);
  // Serial.println(timeClient.getFormattedTime());
  // Serial.println(timeClient.getEpochTime());
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err;

  err = wifiCtrl.init(2);

  if (err != Control_OK) {
    Serial.print("Failed to init WiFiControl. Reason is: ");
    switch (err) {
      case WiFiControl_ConnectionFailed:
        {
          Serial.println("Failed to connect specified WiFi");
          break;
        }
    }
  } else {
    wifiCtrl.connectRouter(ssid, password);
  }

  err = i2cCtrl.init(0, 10, 6);  //  use i2cNum=0, SCL=10, SDA=6
  if (err) {
    Serial.print("Fail to initialize i2cCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  err = oledCtrl.init(i2cCtrl, 0x3c, 128, 64, -1);
  if (err) {
    Serial.print("Fail to initialize oledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  oledCtrl.enableScheduler(0, 1000, oledHandler);

  timeClient.setTimeOffset(28800);

  timeClient.begin();
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();

  timeClient.update();
}
