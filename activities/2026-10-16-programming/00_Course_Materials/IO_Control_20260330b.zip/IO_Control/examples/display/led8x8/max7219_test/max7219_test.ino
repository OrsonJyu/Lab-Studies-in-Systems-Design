#define USE_MAX7219Control
#include "IO_Control.h"

MAX7219Control max7219Ctrl;

MAX7219BitMap bitMap1;

MAX7219BitMap bitMap2;

MAX7219Sequence max7219Sequence;

int timeCount = 0;

DeclareHandler(max7219CtrlHandler, _ctrl, MAX7219Control, {
  //Serial.println("max7219CtrlHandler is called");
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = max7219Ctrl.init(3, 2, 5, 4, 0);
  if (err) {
    Serial.print("Fail to initialize max7219Ctrl. Error code = ");
    Serial.println(err);
    return;
  }


  char textToPrint[16] = "TEST";

  //max7219Ctrl.printText(0, 3, textToPrint, 1);

  //max7219Ctrl.scrollText("Hello this is a test", 1, 100, true);

  bitMap1.bitMap[0] = B10000000;
  bitMap1.bitMap[1] = B01000000;
  bitMap1.bitMap[2] = B00100000;
  bitMap1.bitMap[3] = B00010000;
  bitMap1.bitMap[4] = B00001000;
  bitMap1.bitMap[5] = B00000100;
  bitMap1.bitMap[6] = B00000010;
  bitMap1.bitMap[7] = B00000001;

  bitMap2.bitMap[0] = B00000001;
  bitMap2.bitMap[1] = B00000010;
  bitMap2.bitMap[2] = B00000100;
  bitMap2.bitMap[3] = B00001000;
  bitMap2.bitMap[4] = B00010000;
  bitMap2.bitMap[5] = B00100000;
  bitMap2.bitMap[6] = B01000000;
  bitMap2.bitMap[7] = B10000000;

  // max7219Ctrl.setBitMap(bitMap1, 0);
  // max7219Ctrl.setBitMap(bitMap2, 1);
  // max7219Ctrl.setBitMap(bitMap2, 2);
  // max7219Ctrl.setBitMap(bitMap1, 3);

  // max7219Ctrl.showBitMap();

  max7219Sequence.addShowBitMap(2000, bitMap1);

  max7219Sequence.addShowBitMap(2000, bitMap2);

  max7219Ctrl.enableScheduler(0, 1, max7219CtrlHandler);

  max7219Ctrl.playRelTime(0, max7219Sequence, 0, -1);

  max7219Ctrl.playRelTime(3, max7219Sequence, 0, -1);

  max7219Ctrl.playRelTime(1, max7219Sequence, 2000, -1);

  max7219Ctrl.playRelTime(2, max7219Sequence, 2000, -1);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
