//
//  for demonstrating use of AsyncWebServerControl for a simple web server and a websocket server
//  installation:
//  - use ESP32 file uploader to update the data file ("index.html")
//  behaviours:
//  - connect to SSID according to wifi_ssid and wifi_password, and start a webserver with websocket support
//  - web server URL: http:<ip>/index
//      serving the "index.html" in data folder
//      provide a web page for user to enter a text, send to websocket server, and print out the reply from websocket server
//  - websocket server URL: http:<ip>/ws
//      an echo server, which sends back text message sent to it from individual client
//
//  board: Luatos ESP32C3 board
//    circuit: none
//

#define USE_AsyncWebServerControl

#include <Arduino.h>
#include <WiFi.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include "IO_Control.h"

WiFiControl wifiCtrl;

AsyncWebServerControl awsCtrl;

const char* wifi_ssid = "LAPTOP1234";
const char* wifi_password = "12345678";


// ====================== Setup & Loop ======================
void setup() {
  Serial.begin(115200);

  IO_Control.begin();

  wifiCtrl.init(WiFiControlWiFiModeAPSTA);

  wifiCtrl.connect(wifi_ssid, wifi_password);

  Serial.printf("Connecting to router %s", wifi_ssid);

  while (!wifiCtrl.isConnected()) {
    Serial.print(".");
    delay(500);
  }
  Serial.println();
  Serial.print("IP Address is: ");
  Serial.println(wifiCtrl.localIP());

  // --- Mount LittleFS ---
  if (!LittleFS.begin()) {
    Serial.println("LittleFS mount failed");
    return;
  }
  Serial.println("LittleFS mounted");

  if (!LittleFS.exists("/index.html")) {
    Serial.println("/index.html missing! Upload it to data/ folder");
  }

  awsCtrl.onHTTP("/", HTTPMethod_GET, redirectIndex);

  awsCtrl.serveStaticFile("/index", LittleFS, "/index.html");

  awsCtrl.onHTTPNotFound(notFound);

  awsCtrl.beginWithWS("/ws", wsHandler);

  Serial.println("HTTP server started");
}

void loop() {
  IO_Control.execute();
}

void notFound(AsyncWebServerRequest* _request) {
  AsyncWebServerRequest& req = *_request;
  req.send(404, "text/plain", "Not found");
}


void redirectIndex(AsyncWebServerRequest* _request) {
   _request->redirect("/index");
}

//
//  for ws server
//
void wsHandler(AsyncWebSocket* server,
               AsyncWebSocketClient* client,
               AwsEventType type,
               void* arg, uint8_t* data, size_t len) {
  (void)len;

  if (type == WS_EVT_CONNECT) {
    awsCtrl.broadcastWS("new client connected");
    Serial.println("ws connect");

    // wsClient = client;
    client->setCloseClientOnQueueFull(false);
    client->ping();

    return;
  }

  if (type == WS_EVT_DISCONNECT) {
    awsCtrl.broadcastWS("client disconnected");
    Serial.println("ws disconnect");

    // wsClient = 0;
    return;
  }

  if (type == WS_EVT_ERROR) {
    Serial.println("ws error");
    return;
  }

  if (type == WS_EVT_PONG) {
    Serial.println("ws pong");
    return;
  }

  if (type == WS_EVT_DATA) {
    wsDataEvtHandler(server, client, type, arg, data, len);
    return;
  }
}

void wsDataEvtHandler(AsyncWebSocket* server, AsyncWebSocketClient* client, AwsEventType type, void* arg, uint8_t* data, size_t len) {
  data[len] = 0;
  String message = (char*)data;
  Serial.printf("Received: %s\n", message.c_str());

  client->text("Echo: " + message);

  Serial.println("message is: " + message);
}