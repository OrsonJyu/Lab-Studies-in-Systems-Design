#define USE_MotorControl
#define USE_EncoderControl

#include <IO_Control.h>

MotorControl motorCtrl;

EncoderControl encoderCtrl;

int8_t direction = 0;


DeclareHandler(motorCtrlHandler, _ctrl, MotorControl, {
  if (direction == 1) {
    _ctrl.move_pwm(16383, -1);
    direction = -1;
  } else {
    _ctrl.move_pwm(16383, 1);
    direction = 1;
  }
});


DeclareHandler(encoderCtrlHandler, _ctrl, EncoderControl, {
  Serial.print("Current Count is: ");
  Serial.println(_ctrl.getCurrentCount());
});

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  IO_Control.begin();

  err_t err;

  err = motorCtrl.init(1, 0);

  if (err) {
    Serial.print("Error happened when init motorCtrl: ");
    Serial.println(err);
  }

  err = encoderCtrl.init(5, 2);

  if (err) {
    Serial.println("Error happened when init encoderCtrl");
    Serial.println(err);
  }

  Serial.println("chip started");

  motorCtrl.move_pwm(16383, 1);

  direction = 1;

  motorCtrl.enableScheduler(0, 3000, motorCtrlHandler);

  encoderCtrl.enableScheduler(0, 100, encoderCtrlHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
