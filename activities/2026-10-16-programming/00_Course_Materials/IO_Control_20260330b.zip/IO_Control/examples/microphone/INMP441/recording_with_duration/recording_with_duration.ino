// Wiring of INMP441 and ESP32C3:
// SCK -> 2
// WS -> 3
// SD -> 4
// VDD -> 3.3V
// L/R -> GND
// GND -> GND

// Wiring of I2S DAC and ESP32:
// BCLK -> 0
// LRC -> 1
// DIN -> 12

// Behaviour: 
// When the ESP32C3 boots up, it will start recording audio for 5000 milliseconds. After 5000 milliseconds, you can play the recorded audio by pressing the boot button (pin 9).


#define USE_INMP441Control
#include <IO_Control.h>
#include "AudioFileSourceLittleFS.h"
#include "AudioGeneratorWAV.h"
#include "AudioOutputI2S.h"

INMP441Control inmp441Ctrl;

AudioGeneratorWAV *wav = nullptr;
AudioFileSourceLittleFS *file;
AudioOutputI2S *out;

BinInControl binInCtrl0;

DeclareHandler(binInHandler, _ctrl, BinInControl, {
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isBinInTriggered()) {
    Serial.print("event time=");
    Serial.print(_ctrl.getInterruptTime());
    if (_ctrl.getInterruptState()) {
      Serial.println(" from LOW to HIGH");
    } else {
      File _file = LittleFS.open("/audio.wav", "r");
      if(!_file) {
        Serial.println("audio.wav dose not exist");
      } else {
        Serial.println("audio.wav exists");
        _file.close();
      }
      Serial.println(" from HIGH to LOW");
      i2s_driver_uninstall(I2S_NUM_0);
      file = new AudioFileSourceLittleFS("/audio.wav");
      out = new AudioOutputI2S();
      out->SetPinout(0, 1, 12);
      wav = new AudioGeneratorWAV();
      wav->begin(file, out);
    }
  }
});

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  Serial.println("chip started");

  binInCtrl0.init(9, INPUT);

  binInCtrl0.enableScheduler(0, 10, binInHandler);
  binInCtrl0.enableInterrupt(CHANGE);

  err_t err = inmp441Ctrl.init(2, 3, 4);
  if (err != Control_OK) {
    Serial.print("Failed to init inmp441Ctrl. Error code is: ");
    Serial.println(err);
  } else {
    inmp441Ctrl.startRecording("audio", 5000);
  }
}

void loop() {
  IO_Control.execute();

  if (wav != nullptr) {
    if (wav->isRunning()) {
      // Serial.println("is playing wav");
      if (!wav->loop()) wav->stop();
    }
  }
}