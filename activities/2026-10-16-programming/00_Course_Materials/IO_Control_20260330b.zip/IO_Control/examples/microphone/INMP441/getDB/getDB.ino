// Wiring of INMP441 and ESP32C3:
// SCK -> 2
// WS -> 3
// SD -> 4
// VDD -> 3.3V
// L/R -> GND
// GND -> GND

// Behaviour: 
// When the ESP32C3 boots up, it will start recording audio for 5000 milliseconds. After 5000 milliseconds, you can play the recorded audio by pressing the boot button (pin 9).


#define USE_INMP441Control
#include "IO_Control.h"

INMP441Control inmp441Ctrl;

DeclareHandler(hdlr,_ctrl,IOControl,{
  Serial.println(inmp441Ctrl.getDB());
});

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = inmp441Ctrl.init(2, 3, 4);
  if (err != Control_OK) {
    Serial.print("Failed to init inmp441Ctrl. Error code is: ");
    Serial.println(err);
  } else {
    IO_Control.enableScheduler(0, 100, hdlr);
  }
}

void loop() {
  IO_Control.execute();
}