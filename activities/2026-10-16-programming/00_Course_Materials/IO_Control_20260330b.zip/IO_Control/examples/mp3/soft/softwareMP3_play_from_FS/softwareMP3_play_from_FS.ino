#define USE_WiFiControl
#define USE_SoftWarePlayerMP3Control
#define TXD1 3
#define RXD1 4
#include <IO_Control.h>

WiFiControl wifiCtrl;
SoftwarePlayerMP3Control swMp3Ctrl;

const char* ssid = "_IOT Roaming";
const char* password = "iot213213213";
HardwareSerial mySerial(1);

DeclareHandler(iocontrolHandler, _ioCtrl, IOControl, {
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("IOControl - SchedulerTimerEvent");
  Serial.print("current time=");
  Serial.print(_ioCtrl.handlerCurrentMillis);
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  mySerial.begin(9600, SERIAL_8N1, RXD1, TXD1);
  Serial.println("chip started");

  err_t err = swMp3Ctrl.init(18, 19, 13);
  if (err) {
    Serial.print("Fail to initialize swMp3Ctrl. Error code = ");
    Serial.println(err);
    return;
  }

  swMp3Ctrl.playFromFS("/JingleBells.mp3");
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
    if (mySerial.available()) {
    Serial.print("Received: ");
    // Read and display all available bytes
    while (mySerial.available()) {
      byte incomingByte = mySerial.read();
      Serial.print(incomingByte, HEX);
      Serial.print(" ");
    }
    Serial.println();
  }
}
