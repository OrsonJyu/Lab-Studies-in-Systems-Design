#define USE_SoftWarePlayerMP3Control
#include <IO_Control.h>

SoftwarePlayerMP3Control swMp3Ctrl;

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);

  Serial.println("chip started");

  err_t err = swMp3Ctrl.init(1, 0, 12);
  if (err) {
    Serial.print("Fail to initialize swMp3Ctrl. Error code = ");
    Serial.println(err);
    return;
  }

  swMp3Ctrl.playFromSD("/Jingle Bells with Lyrics  Christmas Songs HD  Christmas Songs and Carols.mp3");
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
