#define USE_WiFiControl
#define USE_SoftWarePlayerMP3Control
#include <IO_Control.h>

WiFiControl wifiCtrl;
SoftwarePlayerMP3Control swMp3Ctrl;

const char* ssid = "_IOT Roaming";
const char* password = "iot213213213";
const char* url = "http://192.168.89.104:3000/stream";

DeclareHandler(iocontrolHandler, _ioCtrl, IOControl, {
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("IOControl - SchedulerTimerEvent");
  Serial.print("current time=");
  Serial.print(_ioCtrl.handlerCurrentMillis);
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = wifiCtrl.init(2);
  if (err) {
    Serial.print("Fail to initialize wifiCtrl. Error code = ");
    Serial.println(err);
    return;
  } else {
    wifiCtrl.connectRouter(ssid, password);
  }

  err = swMp3Ctrl.init(0, 1, 12);
  if (err) {
    Serial.print("Fail to initialize swMp3Ctrl. Error code = ");
    Serial.println(err);
    return;
  }

  err = swMp3Ctrl.stream(url, 8192, wifiCtrl);
  if (err) {
    Serial.print("Fail to stream mp3. Error code = ");
    Serial.println(err);
    return;
  }
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
