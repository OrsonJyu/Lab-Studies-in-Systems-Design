//
//  for demonstrating use of DFPlayer Mini MP3 player
//  circuit:
//    connect to a DFPlayer Mini MP3 player
//      IO00 - TX on DFPlayer Mini MP3 player
//      IO01 - RX on DFPlayer Mini MP3 player
//      5V   - VCC
//      GND  - GND
//

#define USE_DFPlayerMP3Control
#include <IO_Control.h>

DFPlayerMP3Control mp3Ctrl;

DFPlayerSequence mp3Seq;

UARTControl hwUartCtrl;

bool playOrPause = true;

uint32_t previousMillis = 0;


DeclareHandler(mp3Handler, _ctrl, DFPlayerMP3Control, {
  uint8_t info[4];
  while (_ctrl.eventInfoAvailable()) {
    err_t err = _ctrl.readMP3EventInfo(info);
    uint8_t cmd = info[0];
    int8_t lastCmdCaller = info[1];
    uint8_t type = info[2];
    uint8_t value = info[3];
    Serial.printf("lastCmd: %d, lastCmdCaller: %d, type: %d, value: %d\n", cmd, lastCmdCaller, type, value);
    if (lastCmdCaller == 1) {
      Serial.println("This is a status returned from sequence playing:");
      // return;
    }
    printDetail(type, value);
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);

  Serial.println("chip started");

  err_t err = hwUartCtrl.init(1, 19, 18, -1, -1, 9600, UART_8N1);
  //  IO01 - hw_rx
  //  IO00 - hw_tx

  if (err != Control_OK) {
    Serial.print("Failed to init UARTControl (HW). Reason is: ");
    switch (err) {
      case Control_ActiveAlready:
        {
          Serial.println("UARTControl is active already");
          break;
        }
    }
  }

  err = mp3Ctrl.init(hwUartCtrl, 8);

  if (err != Control_OK) {
    Serial.print("Failed to init MP3Control. Reason is: ");
    switch (err) {
      case Control_ActiveAlready:
        {
          Serial.println("MP3Control is active already");
          break;
        }
    }
    return;
  }

  //addCommand(uint8_t _index, uint8_t _volume, uint32_t _duration, bool _loopAfterEnd, uint32_t _fadeInTime, uint32_t _fadeOutTime)
  mp3Seq.addCommand(1, 30, 15000, false, 2000, 2000);
  mp3Seq.addCommand(2, 30, 20000, false);

  // mp3Ctrl.playNext();
  // mp3Ctrl.play(1);
  mp3Ctrl.enableScheduler(0, 100, mp3Handler);

  mp3Ctrl.playRelTime(mp3Seq, 3000, 1);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}


void printDetail(uint8_t type, int value) {
  switch (type) {
    case TimeOut:
      Serial.println(F("Time Out!"));
      break;
    case WrongStack:
      Serial.println(F("Stack Wrong!"));
      break;
    case DFPlayerCardInserted:
      Serial.println(F("Card Inserted!"));
      break;
    case DFPlayerCardRemoved:
      Serial.println(F("Card Removed!"));
      break;
    case DFPlayerCardOnline:
      Serial.println(F("Card Online!"));
      break;
    case DFPlayerUSBInserted:
      Serial.println("USB Inserted!");
      break;
    case DFPlayerUSBRemoved:
      Serial.println("USB Removed!");
      break;
    case DFPlayerPlayFinished:
      Serial.print(F("Number:"));
      Serial.print(value);
      Serial.println(F(" Play Finished!"));
      break;
    case DFPlayerError:
      Serial.print(F("DFPlayerError:"));
      switch (value) {
        case Busy:
          Serial.println(F("Card not found"));
          break;
        case Sleeping:
          Serial.println(F("Sleeping"));
          break;
        case SerialWrongStack:
          Serial.println(F("Get Wrong Stack"));
          break;
        case CheckSumNotMatch:
          Serial.println(F("Check Sum Not Match"));
          break;
        case FileIndexOut:
          Serial.println(F("File Index Out of Bound"));
          break;
        case FileMismatch:
          Serial.println(F("Cannot Find File"));
          break;
        case Advertise:
          Serial.println(F("In Advertise"));
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }
}