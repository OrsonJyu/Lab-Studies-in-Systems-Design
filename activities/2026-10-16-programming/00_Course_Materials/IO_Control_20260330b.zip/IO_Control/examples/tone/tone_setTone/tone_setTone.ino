//
//  for demonstrating setting of tone (frequency/note+octave and duty) for a speaker
//    circuit:
//      a servo motor with the following connections:
//      IO13 - +ve input of piezo speaker
//      GND  - GND input of piezo speaker
//
#include <IO_Control.h>

ToneControl toneCtrl0;
int counter=0;
uint32_t freq1=1000;
uint32_t duty1=100;
NoteBaseType notebase2 = NoteBaseC;
uint8_t octave2 = 4;
uint32_t duty2 = 200;


DeclareHandler(iocontrolHandler,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("IOControl - SchedulerTimerEvent"); 
  if (_ctrl.isSchedulerTimeEvent())
  { Serial.print("current time=");
    Serial.print(_ctrl.handlerCurrentMillis);

    switch (counter)
    { case 0:
        toneCtrl0.setTone(freq1,duty1);
        counter=1;
        break;
      case 1:
        toneCtrl0.setNote(notebase2,octave2,duty2);
        counter=2;
        break;
      default:
        toneCtrl0.setTone(0,0);
        break;
    }
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err=toneCtrl0.init(13);
  if (err)
  { Serial.print("Fail to initialize toneCtrl0. Error code = ");
    Serial.println(err);
    return;
  }

  Serial.print("tone max duty=");
  Serial.println(toneCtrl0.getMaxDuty());

  IO_Control.enableScheduler(1000, 250, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
