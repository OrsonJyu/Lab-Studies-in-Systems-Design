//
//  for demonstrating playback of a sequence of tone (frequency/note+octave and duty) for a speaker
//    circuit:
//      a servo motor with the following connections:
//      IO13 - +ve input of piezo speaker
//      GND  - GND input of piezo speaker
//
#include <IO_Control.h>

ToneControl toneCtrl0;
ToneSequence toneSeq0;

DeclareHandler(toneHandler,_ctrl,ToneControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("ToneControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
    Serial.println("ToneControl - AllSeqStarted");
  if (_ctrl.isAllSeqEnded())
    Serial.println("ToneControl - AllSeqEnded");
  if (_ctrl.isOneSeqStarted())
    Serial.println("ToneControl - OneSeqStarted");
  if (_ctrl.isOneSeqNewCmdStarted())
    Serial.println("ToneControl - OneSeqNewCmdStarted");
  if (_ctrl.isOneSeqPaused())
    Serial.println("ToneControl - OneSeqPaused");
  if (_ctrl.isOneSeqEnded())
    Serial.println("ToneControl - OneSeqEnded");  
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err=toneCtrl0.init(13);
  if (err)
  { Serial.print("Fail to initialize toneCtrl0. Error code = ");
    Serial.println(err);
    return;
  }

  uint32_t duty=50;
  double pauseFactor=1.3;
  ulong_t oneNoteTime=200;
  toneSeq0.addSetNote(oneNoteTime,NoteBaseC,4,duty);
  toneSeq0.addSetTone(oneNoteTime*pauseFactor,0,0);
  toneSeq0.addSetNote(oneNoteTime/2,NoteBaseG,3,duty);
  toneSeq0.addSetTone(oneNoteTime/2*pauseFactor,0,0);
  toneSeq0.addSetNote(oneNoteTime/2,NoteBaseG,3,duty);
  toneSeq0.addSetTone(oneNoteTime/2*pauseFactor,0,0);
  toneSeq0.addSetNote(oneNoteTime,NoteBaseA,3,duty);
  toneSeq0.addSetTone(oneNoteTime*pauseFactor,0,0);
  toneSeq0.addSetNote(oneNoteTime,NoteBaseG,3,duty);
  toneSeq0.addSetTone(oneNoteTime*pauseFactor,0,0);
  toneSeq0.addSetTone(oneNoteTime*(1+pauseFactor),0,0);
  toneSeq0.addSetNote(oneNoteTime,NoteBaseB,3,duty);
  toneSeq0.addSetTone(oneNoteTime*pauseFactor,0,0);

  uint32_t freq=toneCtrl0.getNoteFreq(NoteBaseC,4);
  toneSeq0.addInterpolateTone(oneNoteTime*3,freq,freq,duty,0);

  toneCtrl0.enableScheduler(0, 10, toneHandler);
  toneCtrl0.playRelTime(toneSeq0,2000,1);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
