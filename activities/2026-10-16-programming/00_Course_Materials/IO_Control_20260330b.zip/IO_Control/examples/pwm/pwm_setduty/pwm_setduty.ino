//
//  for demonstrating setting of PWM values on a GPIO output
//    circuit: LED at IO12, on Luatos ESP32C3 board
//

#include <IO_Control.h>

PWMControl pwmCtrl0;
uint16_t duty=0;
uint16_t dutyInc=100;

DeclareHandler(iocontrolHandler,_ioCtrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("IOControl - SchedulerTimerEvent");  
  Serial.print("current time=");
  Serial.print(_ioCtrl.handlerCurrentMillis);
  duty+=dutyInc;
  if (duty>pwmCtrl0.getMaxDuty())
    duty=0;
  err_t err=pwmCtrl0.setDuty(duty);
  if (err)
  { 
    Serial.println("error in setDuty");
  }

  Serial.print(" duty=");
  Serial.println(duty);
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err=pwmCtrl0.init(12);
  if (err)
  { Serial.print("Fail to initialize pwmCtrl0. Error code = ");
    Serial.println(err);
    return;
  }

  Serial.print("pwm frequency=");
  Serial.println(pwmCtrl0.getFreq());
  Serial.print("pwm max duty=");
  Serial.println(pwmCtrl0.getMaxDuty());

  IO_Control.enableScheduler(0, 50, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
