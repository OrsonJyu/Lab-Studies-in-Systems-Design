//
//  for demonstrating playback of sequence of PWM values on a GPIO output
//    circuit: LED at IO12, on Luatos ESP32C3 board
//

#include <IO_Control.h>

PWMControl pwmCtrl0;
PWMSequence pwmSeq0;

DeclareHandler(pwmHandler,_ctrl,PWMControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
    Serial.println("PWMControl - AllSeqStarted");
  if (_ctrl.isAllSeqEnded())
    Serial.println("PWMControl - AllSeqEnded");
  if (_ctrl.isOneSeqStarted())
    Serial.println("PWMControl - OneSeqStarted");
  if (_ctrl.isOneSeqNewCmdStarted())
    Serial.println("PWMControl - OneSeqNewCmdStarted");
  if (_ctrl.isOneSeqPaused())
    Serial.println("PWMControl - OneSeqPaused");
  if (_ctrl.isOneSeqEnded())
    Serial.println("PWMControl - OneSeqEnded");
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err=pwmCtrl0.init(12);
  if (err)
  { Serial.print("Fail to initialize pwmCtrl0. Error code = ");
    Serial.println(err);
    return;
  }

  Serial.print("pwm frequency=");
  Serial.println(pwmCtrl0.getFreq());
  Serial.print("pwm max duty=");
  Serial.println(pwmCtrl0.getMaxDuty());

  pwmSeq0.addSetDuty(1000,0);
  pwmSeq0.addFade(1000,0,pwmCtrl0.getMaxDuty()/2);
  pwmSeq0.addFade(500,pwmCtrl0.getMaxDuty()/2,pwmCtrl0.getMaxDuty());
  pwmSeq0.addFade(500,pwmCtrl0.getMaxDuty(),pwmCtrl0.getMaxDuty()/2);
  pwmSeq0.addFade(1000,pwmCtrl0.getMaxDuty()/2,0);

  pwmCtrl0.enableScheduler(0, 50, pwmHandler);
  pwmCtrl0.playRelTime(pwmSeq0, 2000, 2);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
