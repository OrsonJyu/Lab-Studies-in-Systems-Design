//
//  to demonstrate how to start and stop an AP, and handling of associated WiFi events received
//
//  available commands thru Serial Monitor:
//  s/S - start an AP with default ssid and pwd
//  s/S,<ssid>,<pwd> start an AP with <ssid> and <pwd>
//  t/T - stop an AP
//  h   - help on commands
//
//  Note:
//    1. WiFiControl.disconnect_AP(true) to turn off AP. if using WiFiControl.disconnect_AP(false), an AP (not "ESP32C3_AP") will still remain
//    2. WiFiControl_EVENT_WIFI_AP_START and WiFiControl_EVENT_WIFI_AP_STOP events will be generated more than once when an AP is created and stopped. Refer to https://github.com/espressif/arduino-esp32/discussions/11113 on why
//
//

#define USE_WiFiControl
#include <IO_Control.h>       // Include the Wi-Fi library

const String default_ssid = "ESP_AP";    // The default SSID name of the AP to be created 
const String default_pwd = "12345678";   // The default password to connect to this AP

WiFiControl wifictrl;
int currentStationNum = 0;

String SSID2String(uint8_t ssid[32],uint8_t ssid_len=0)
{ char str[33];
  if (ssid_len==0)
  { memcpy(str,ssid,32);
    str[32]=0;
  }
  else
  { memcpy(str,ssid,ssid_len);
    str[ssid_len]=0;
  }
  return String(str);
}

String PWD2String(uint8_t pwd[64])
{ char str[65];
  memcpy(str,pwd,64);
  str[64]=0;
  return String(str);
}

String MAC2String(uint8_t mac[6])
{ char str[20];

  char* ptr = str;
  for (int i=0;i<6;i++)
    if (i!=5)
      ptr+=sprintf(ptr,"%02x:",mac[i]);
    else
      ptr+=sprintf(ptr,"%02x",mac[i]);
  *ptr=0;
  return String(str);
}

DeclareHandler(ioControlHdr,_ctrl,IOControl,
{
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("IOControl - SchedulerTimerEvent");     
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    if (input.equals("h"))
    { //  help on commands
      Serial.println("h - help");
      Serial.println("s/S - start an AP with default ssid and pwd");
      Serial.println("s/S,<ssid>,<pwd> - start an AP with <ssid> and <pwd>");
      Serial.println("t/T - stop an AP");
      return;
    }

    if ((input.charAt(0)=='S') || (input.charAt(0)=='s'))
    { //  start an AP
      //  s/S OR s/S,<ssid>,<pwd>
      Serial.println("Starting an AP");

      err_t err;
      String ssid,pwd;
      int i0=input.indexOf(',');
      if (i0==-1)
      { //  start with default ssid and password
        
        ssid=default_ssid;
        pwd=default_pwd;
        Serial.print("use default setting, ssid=");
        Serial.print(ssid);
        Serial.print(",pwd=");
        Serial.println(pwd);

      } else
      { int i1=input.indexOf(",",i0+1);
        if (i1==-1)
        { Serial.print("Error: should have <ssid> and <pwd> - command:");
          Serial.println(input);
          return;
        }
        ssid=input.substring(i0+1,i1);
        pwd=input.substring(i1+1);
        Serial.print("use user-provided setting, ssid=");
        Serial.print(ssid);
        Serial.print(",pwd=");
        Serial.println(pwd);
      }

      err=wifictrl.createAP(ssid,pwd);
      if (err != Control_OK) {
        Serial.print("Failed to start AP. Error code is: ");
        Serial.println(err);

        wifictrl.disconnect_AP(true); //  if fail to create, just disconnect it
      } else
      { IPAddress ip=wifictrl.localIP_AP();
        Serial.print("AP created. SSID=");
        Serial.print(ssid);
        Serial.print(" PWD=");
        Serial.print(pwd);
        Serial.print(" IP address=");
        Serial.println(ip);
      }

      return;
    }

    if (input.equals("T") || input.equals("t"))
    { //  disconnect an AP
      Serial.println("Stopping an AP");

      err_t err;
      err=wifictrl.disconnect_AP(true); //  if pass "false", AP with name "ESP32C3_AP" will not be running, but another one will be started (of name "ESP_XXXXXX")
      if (err != Control_OK) {
        Serial.print("Failed to stop AP. Error code is: ");
        Serial.println(err);
        return;
      } 
      //  wait for WiFiEvent on AP stopped

      return;
    }

    //  else, unknown command, and hence ignore
    Serial.print("Unknown command:");
    Serial.println(input);
  }
})

DeclareHandler(hdr,_ctrl,WiFiControl,{

  //  show no of connected stations when changed
  int stationNum=wifictrl.getStationNum_AP();
  if (stationNum != currentStationNum)
  { Serial.print("no of connected stations=");
    Serial.println(stationNum);
    currentStationNum=stationNum;
  }

  //  get WiFi events and associated data
  uint8_t data[sizeof(arduino_event_info_t)];
  uint8_t dataLen;
  WiFiContolEvent_t wifiEvt;
  while ((wifiEvt=_ctrl.getWiFiEvent(data,dataLen))!=WiFiControl_EVENT_NONE)
  { switch (wifiEvt)
    { case WiFiControl_EVENT_WIFI_AP_START:
        Serial.println("WiFi Event: AP started");
        break;
      case WiFiControl_EVENT_WIFI_AP_STOP:
        Serial.println("WiFi Event: AP stopped");
        break;
      case WiFiControl_EVENT_WIFI_AP_STACONNECTED:
        { Serial.println("WiFi Event: STA connected");
          wifi_event_ap_staconnected_t& info = *((wifi_event_ap_staconnected_t*)data);
          Serial.print("MAC=");
          Serial.print(MAC2String(info.mac));
          Serial.print(" aid=");
          Serial.println(info.aid);
          break;
        }
      case WiFiControl_EVENT_WIFI_AP_STADISCONNECTED:
        { Serial.println("WiFi Event: STA disconnected");
          wifi_event_ap_stadisconnected_t& info = *((wifi_event_ap_stadisconnected_t*)data);
          Serial.print("MAC=");
          Serial.print(MAC2String(info.mac));
          Serial.print(" aid=");
          Serial.println(info.aid);
          break;
        }
      case WiFiControl_EVENT_WIFI_AP_STAIPASSIGNED:
        { Serial.println("WiFi Event: STA IP Assigned");
          ip_event_ap_staipassigned_t& info = *((ip_event_ap_staipassigned_t*)data);
          Serial.print("IP=");
          Serial.print(IPAddress(info.ip.addr).toString());
          Serial.print(" MAC=");
          Serial.println(MAC2String(info.mac));
          break;
        }
      case WiFiControl_EVENT_WIFI_AP_PROBEREQRECVED:
        { Serial.println("WiFi Event: Probe request received");
          wifi_event_ap_probe_req_rx_t& info = *((wifi_event_ap_probe_req_rx_t*)data);
          Serial.print("rssi=");
          Serial.print(info.rssi);
          Serial.print(" MAC=");
          Serial.print(MAC2String(info.mac));
          break;
        }
      case WiFiControl_EVENT_WIFI_AP_GOT_IP6:
        { Serial.println("WiFi Event: AP got IP6");
          break;
        }
    }
  }
})

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  Serial.println("chip started");
  Serial.println("ap_mode");

  //  initialize the WiFiControl object
  err_t err = wifictrl.init(WiFiControlWiFiModeAP);
  if (err != Control_OK) {
    Serial.print("Failed to init wifictrl. Error code is: ");
    Serial.println(err);
    return;
  }

  //  subscribe a number of WiFiEvents which are relevant to AP mode 
  wifictrl.subscribeEvent(WiFiControl_EVENT_WIFI_AP_START);
  wifictrl.subscribeEvent(WiFiControl_EVENT_WIFI_AP_STOP);
  wifictrl.subscribeEvent(WiFiControl_EVENT_WIFI_AP_STACONNECTED);
  wifictrl.subscribeEvent(WiFiControl_EVENT_WIFI_AP_STADISCONNECTED);
  wifictrl.subscribeEvent(WiFiControl_EVENT_WIFI_AP_STAIPASSIGNED);
  wifictrl.subscribeEvent(WiFiControl_EVENT_WIFI_AP_PROBEREQRECVED);
  wifictrl.subscribeEvent(WiFiControl_EVENT_WIFI_AP_GOT_IP6);

  IO_Control.enableScheduler(0,10,ioControlHdr);  //  for handling user input from Serial interface
  wifictrl.enableScheduler(0,10,hdr);
}

void loop() {   
  IO_Control.execute();
}
