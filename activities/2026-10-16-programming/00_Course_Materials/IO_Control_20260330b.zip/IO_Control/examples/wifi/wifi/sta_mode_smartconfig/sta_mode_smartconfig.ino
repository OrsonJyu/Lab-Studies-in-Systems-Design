//
//  to demonstrate STA mode with the following features:
//  1.  connect directly to an AP (with given ssid and password)
//  2.  start SmartConfig with one cycle of full scan of available WiFi channels, using type ESPTOUCH and ESPTOUCH V2
// 
//  available commands thru Serial Monitor:
//  c/C,<ssid>,<pwd>  - connect to an AP with <ssid> and <pwd>
//  d                 - disconnect from an AP
//  e1                - start SmartConfig, using ESPTouch
//  e2,<16-byte crypt key>  - start SmartConfig, using ESPTouchV2
//  es                - stop SmartConfig
//

#define USE_WiFiControl
#include <IO_Control.h>       // Include the Wi-Fi library

WiFiControl wifiCtrl;
enum
{ IDLE,
  CONNECTING,
  CONNECTED,
  CONNECTED_WITH_IP,
  CONNECTED_WITHOUT_IP,
  DISCONNECTING,
  DISCONNECTED,
  SCSCANNING
}
wifiCtrlState=IDLE; //  different state of the wifiCtrl object

bool last_scstatus=false;

String SSID2String(uint8_t ssid[32],uint8_t ssid_len=0)
{ char str[33];
  if (ssid_len==0)
  { memcpy(str,ssid,32);
    str[32]=0;
  }
  else
  { memcpy(str,ssid,ssid_len);
    str[ssid_len]=0;
  }
  return String(str);
}

String PWD2String(uint8_t pwd[64])
{ char str[65];
  memcpy(str,pwd,64);
  str[64]=0;
  return String(str);
}

String MAC2String(uint8_t mac[6])
{ char str[20];

  char* ptr = str;
  for (int i=0;i<6;i++)
    if (i!=5)
      ptr+=sprintf(ptr,"%02x:",mac[i]);
    else
      ptr+=sprintf(ptr,"%02x",mac[i]);
  *ptr=0;
  return String(str);
}

DeclareHandler(hdr,_ctrl,WiFiControl,{
  //  get WiFi events and associated data
  uint8_t data[sizeof(arduino_event_info_t)];
  uint8_t dataLen;
  WiFiContolEvent_t wifiEvt;
  while ((wifiEvt=_ctrl.getWiFiEvent(data,dataLen))!=WiFiControl_EVENT_NONE)
  { switch(wifiEvt){
    case WiFiControl_EVENT_WIFI_STA_START:
      Serial.println("STA start");
      break;
    case WiFiControl_EVENT_WIFI_STA_STOP:
      Serial.println("STA stop");
      break;
    case WiFiControl_EVENT_WIFI_STA_CONNECTED:
      { Serial.println("STA connected");
        wifi_event_sta_connected_t& info=*((wifi_event_sta_connected_t*)data);
        Serial.print("ssid:");
        Serial.print(SSID2String(info.ssid,info.ssid_len));
        Serial.print(" bssid");
        Serial.print(MAC2String(info.bssid));
        Serial.print(" authmode:");
        Serial.println(info.authmode);

        wifiCtrlState=CONNECTED;
        break;
      }   
    case WiFiControl_EVENT_WIFI_STA_DISCONNECTED:
      { Serial.println("STA disconnected");
        wifi_event_sta_disconnected_t& info=*((wifi_event_sta_disconnected_t*)data);
        Serial.print("ssid:");
        Serial.print(SSID2String(info.ssid,info.ssid_len));
        Serial.print(" bssid");
        Serial.print(MAC2String(info.bssid));
        Serial.print(" reason:");
        Serial.println(info.reason);
        
        wifiCtrlState=DISCONNECTED;
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_AUTHMODE_CHANGE:
      { Serial.println("Authentication mode changed");
        wifi_event_sta_authmode_change_t& info =*((wifi_event_sta_authmode_change_t*)data);

        Serial.print("change mode=");
        Serial.print(info.old_mode);
        Serial.print(" to ");
        Serial.println(info.new_mode);
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_GOT_IP:
      { Serial.println("STA got IP");
        ip_event_got_ip_t& info = *((ip_event_got_ip_t*)data);

        Serial.print("IP=");
        Serial.print(IPAddress(info.ip_info.ip.addr).toString());
        Serial.print(" netmask=");
        Serial.print(IPAddress(info.ip_info.netmask.addr).toString());
        Serial.print(" gateway=");
        Serial.println(IPAddress(info.ip_info.gw.addr).toString());

        wifiCtrlState=CONNECTED_WITH_IP;
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_GOT_IP6:
      { Serial.println("STA got IPV6");
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_LOST_IP:
      { Serial.println("STA lost IP");
        wifiCtrlState=CONNECTED;
        break;
      }
    case WiFiControl_EVENT_SC_SCAN_DONE:
      { Serial.println("SC scan done");

/*
        err_t err= wifiCtrl.stopSmartConfig();
        if (err==Control_OK)
          Serial.printf("Stopped SmartConfig");
        else
          Serial.printf("Stopped SmartConfig with error");
        if (wifiCtrlState == SCSCANNING)
          wifiCtrlState = IDLE;
*/
        break;
      }
    case WiFiControl_EVENT_SC_FOUND_CHANNEL:
      { Serial.println("SC channel found");
        break;
      }
    case WiFiControl_EVENT_SC_GOT_SSID_PSWD:
      { Serial.println("SC got ssid and pwd");
        smartconfig_event_got_ssid_pswd_t& info = *((smartconfig_event_got_ssid_pswd_t*)data);

        Serial.print("ssid=");
        Serial.print(SSID2String(info.ssid));
        Serial.print(", pwd=");
        Serial.println(PWD2String(info.password));

        if (info.type == SC_TYPE_ESPTOUCH_V2)
        {  // read custom data sent from the mobile app
          uint8_t rvd_data[33] = { 0 }; // Buffer to store the received custom data
           esp_err_t err = esp_smartconfig_get_rvd_data(rvd_data, sizeof(rvd_data));
          Serial.print("custom data=");
          Serial.println(String((char*) rvd_data));
        }

        err_t err= wifiCtrl.stopSmartConfig();
        if (err==Control_OK)
          Serial.printf("Stopped SmartConfig");
        else
          Serial.printf("Stopped SmartConfig with error");

        wifiCtrlState=CONNECTED_WITH_IP;
        break;
      }
    case WiFiControl_EVENT_SC_SEND_ACK_DONE:
      { Serial.println("SC ack done");
        break;
      }
    }
  }

  bool curr_status = _ctrl.smartConfigDone();
  if (curr_status != last_scstatus)
  { Serial.printf("sc done: status=%d\n",curr_status);
    last_scstatus=curr_status;
  }
})

DeclareHandler(ioControlHdr,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("IOControl - SchedulerTimerEvent");     
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');  
    if ((input.charAt(0)=='c') || (input.charAt(0)=='C'))
    { //  connect to SSID
      //  command: c,<ssid>,<passwd>
      Serial.print("Connect command received: ");
      Serial.println(input);
      
      if ((wifiCtrlState!=IDLE) && (wifiCtrlState!=DISCONNECTED))
      { Serial.println("Currently connected to an AP. Disconnect first");
        return;
      }

      //  get ssid and password from commmand
      int i0 = input.indexOf(",");
      int i1 = input.indexOf(",",i0+1);
      if ((i0==-1) || (i1==-1))
      { Serial.println("invalid format: C,<ssid>,<passwd>");
        return;
      }
      String ssid = input.substring(i0+1,i1);
      String pwd = input.substring(i1+1);
      Serial.print("connecting to ssid=");
      Serial.print(ssid);
      Serial.print(" pwd=");
      Serial.println(pwd);

      //  connect to the AP
      err_t err;
      err=wifiCtrl.connect(ssid, pwd);
      if (err != Control_OK) {
        Serial.print("Failed to connect to AP. Error code is: ");
         Serial.println(err);
         return;
      } 

      wifiCtrlState=CONNECTING;
      //  then wait for connection
      return;
    }
    if (input.equals("D") || input.equals("d"))
    { //  disconnect from SSID
      Serial.println("Disconnect command received");

      err_t err;
      err=wifiCtrl.disconnect();
      if (err != Control_OK)
      { Serial.print("Failed to disconnect from AP. Error code is: ");
        Serial.println(err);

        wifiCtrlState = IDLE;
        return;
      } else
      { //  then wait for disconnection
        Serial.println("Disconnecting from AP");
        wifiCtrlState=DISCONNECTING;
      }
      return;
    }

    if (input.equals("E1") || input.equals("e1"))
    { //  SmartConfig, type=ESPTOUCH
      Serial.printf("ESPTouch command received: %s\n",input.c_str());

      err_t err=wifiCtrl.beginSmartConfig(SC_TYPE_ESPTOUCH);
      if (err != Control_OK)
      { Serial.print("Failed to begin SmartConfig (ESPTOUCH). Error code is: ");
        Serial.println(err);

        wifiCtrlState = IDLE;
        return;
      } else
      { Serial.println("SmartConfig started");
        wifiCtrlState = SCSCANNING;
      }
      
      return;
    }

    if (input.substring(0,2).equals("E2") || input.substring(0,2).equals("e2"))
    { //  SmartConfig, type=ESPTOUCH_V2
      //  command: E2,<crypt_key-16 char> 
      Serial.printf("ESPTouchV2 command received: %s\n",input.c_str());
      
      //  extract encryption key
      int i0=input.indexOf(",");
      if (i0==-1)
      { Serial.println("invalid format: E2,<16 char crypt key>");
        return;
      }
      String cryptkey = input.substring(i0+1);

      err_t err;
      // err= wifiCtrl.stopSmartConfig();
      // Serial.printf("stopSmartConfig=%d\n",err);

      err=wifiCtrl.beginSmartConfig(SC_TYPE_ESPTOUCH_V2,cryptkey.c_str());
      if (err != Control_OK)
      { Serial.print("Failed to begin SmartConfig (SC_TYPE_ESPTOUCH_V2). Error code is: ");
        Serial.println(err);
        wifiCtrlState = IDLE;
        return;
      } else
      { //  started scanning
        Serial.println("SmartConfig started");
        wifiCtrlState = SCSCANNING;
      }
      return;
    }

    if (input.equals("es"))
    { //  stop scanning

      err_t err;
      err= wifiCtrl.stopSmartConfig();
      if (err==Control_OK)
        Serial.print("SmartConfig stopped");
      else
        Serial.printf("SmartConfig stopped with error");
      return;
    }
  }
});

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  Serial.println("chip started");
  Serial.println("sta_mode_smartconfig");

  err_t err = wifiCtrl.init(WiFiControlWiFiModeSTA);
  if (err != Control_OK) {
    Serial.print("Failed to init wifiCtrl. Error code is: ");
    Serial.println(err);
  }

  wifiCtrl.setAutoReconnect(false); //  set this to true to allow for auto-reconnection

  //  WiFi events for STA
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_START);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_STOP);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_CONNECTED);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_DISCONNECTED);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_AUTHMODE_CHANGE);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_GOT_IP);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_GOT_IP6);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_LOST_IP);

  //  WiFi events for SmartConfig
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_SC_SCAN_DONE);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_SC_FOUND_CHANNEL);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_SC_GOT_SSID_PSWD);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_SC_SEND_ACK_DONE);
  
  IO_Control.enableScheduler(0,10,ioControlHdr);
  wifiCtrl.enableScheduler(0,10,hdr);
}

void loop() { 
  IO_Control.execute();
}
