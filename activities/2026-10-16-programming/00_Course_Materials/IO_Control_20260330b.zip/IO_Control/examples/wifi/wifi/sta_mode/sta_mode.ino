#define USE_WiFiControl
#include <IO_Control.h>       // Include the Wi-Fi library

const char* ssid     = "LAPTOP1234";         // The SSID (name) of the Wi-Fi network you want to connect to
const char* password = "12345678";     // The password of the Wi-Fi network

WiFiControl wifiCtrl;
enum
{ IDLE,
  CONNECTING,
  CONNECTED,
  DISCONNECTING,
  DISCONNECTED
}
wifiCtrlState=IDLE;

DeclareHandler(hdr,_ctrl,WiFiControl,{
  //  get WiFi events and associated data
  uint8_t data[sizeof(arduino_event_info_t)];
  uint8_t dataLen;
  WiFiContolEvent_t wifiEvt;
  while ((wifiEvt=_ctrl.getWiFiEvent(data,dataLen))!=WiFiControl_EVENT_NONE)
  { switch(wifiEvt){
    case WiFiControl_EVENT_WIFI_STA_START:
      Serial.println("STA start");
      break;
    case WiFiControl_EVENT_WIFI_STA_STOP:
      Serial.println("STA stop");
      break;
    case WiFiControl_EVENT_WIFI_STA_CONNECTED:
      { Serial.println("STA connected");
        wifi_event_sta_connected_t* info=(wifi_event_sta_connected_t*)data;
        Serial.printf("ssid:%s ",info->ssid);
        Serial.printf("bssid=");
          for (int i=0;i<6;i++)
            if (i!=5)
              Serial.printf("%02x:",info->bssid[i]);
            else
              Serial.printf("%02x ",info->bssid[i]);
        Serial.printf("authmode:%d\n",info->authmode);

        wifiCtrlState=CONNECTED;
        break;
      }   
    case WiFiControl_EVENT_WIFI_STA_DISCONNECTED:
      { Serial.println("STA disconnected");
        wifi_event_sta_disconnected_t* info=(wifi_event_sta_disconnected_t*)data;
        Serial.printf("ssid:%s ",info->ssid);
        Serial.printf("bssid=");
          for (int i=0;i<6;i++)
            if (i!=5)
              Serial.printf("%02x:",info->bssid[i]);
            else
              Serial.printf("%02x ",info->bssid[i]);
        Serial.printf("reason:%d\n",info->reason);

        wifiCtrlState=DISCONNECTED;
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_AUTHMODE_CHANGE:
      { Serial.println("Authentication mode changed");
        wifi_event_sta_authmode_change_t* info =(wifi_event_sta_authmode_change_t*)data;

        Serial.printf("change mode=%d to mode=%d\n",info->old_mode,info->new_mode);
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_GOT_IP:
      { Serial.println("STA got IP");
        ip_event_got_ip_t* info = (ip_event_got_ip_t*)data;

        Serial.printf("IP=%s ",IPAddress(info->ip_info.ip.addr).toString().c_str());
        Serial.printf("netmask=%s ",IPAddress(info->ip_info.netmask.addr).toString().c_str());
        Serial.printf("gateway=%s\n",IPAddress(info->ip_info.gw.addr).toString().c_str());
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_GOT_IP6:
      { Serial.println("STA got IPV6");
        break;
      }
    case WiFiControl_EVENT_WIFI_STA_LOST_IP:
      { Serial.println("STA lost IP");
        break;
      }
    }
  }
})

DeclareHandler(ioControlHdr,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("IOControl - SchedulerTimerEvent");     
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');  
    if ((input.charAt(0)=='c') || (input.charAt(0)=='C'))
    { //  connect to SSID
      //  command: c,<ssid>,<passwd>
      
      if ((wifiCtrlState!=IDLE) && (wifiCtrlState!=IDLE))
      { Serial.println("Currently connected to an AP. Disconnect first");
        return;
      }

      //  get ssid and password
      int i0 = input.indexOf(",");
      int i1 = input.indexOf(",",i0+1);
      if ((i0==-1) || (i1==-1))
      { Serial.println("invalid format: C,<ssid>,<passwd>");
        return;
      }
      String ssid = input.substring(i0+1,i1);
      String pwd = input.substring(i1+1);
      Serial.print("connecting to ssid=");
      Serial.print(ssid);
      Serial.print(" pwd=");
      Serial.println(pwd);

      err_t err;
      err=wifiCtrl.connect(ssid, pwd);
      if (err != Control_OK) {
        Serial.print("Failed to connect to AP. Error code is: ");
         Serial.println(err);
         return;
      } 

      wifiCtrlState=CONNECTING;
      //  then wait for connection
      return;
    }
    if (input.equals("D") || input.equals("d"))
    { //  disconnect from SSID
      err_t err;
      err=wifiCtrl.disconnect();
      if (err != Control_OK)
      { Serial.print("Failed to disconnect from AP. Error code is: ");
        Serial.println(err);
        return;
      }

      wifiCtrlState=DISCONNECTING;
      //  then wait for disconnection
      return;
    }
  }
});

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = wifiCtrl.init(WiFiControlWiFiModeSTA);
  if (err != Control_OK) {
    Serial.print("Failed to init wifiCtrl. Error code is: ");
    Serial.println(err);
  }

  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_START);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_STOP);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_CONNECTED);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_DISCONNECTED);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_AUTHMODE_CHANGE);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_GOT_IP);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_GOT_IP6);
  wifiCtrl.subscribeEvent(WiFiControl_EVENT_WIFI_STA_LOST_IP);

  IO_Control.enableScheduler(0,10,ioControlHdr);
  wifiCtrl.enableScheduler(0,10,hdr);
}

void loop() { 
  IO_Control.execute();
}
