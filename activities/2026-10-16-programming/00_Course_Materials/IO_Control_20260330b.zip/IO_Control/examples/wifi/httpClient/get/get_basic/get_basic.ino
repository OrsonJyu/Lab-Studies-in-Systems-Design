//
//  for demonstrating how to send an HTTP GET request to a given URL, and receive the reply
//
//  board:
//    Luatos ESP32C3 board
//    ESP32S3 Dev Module
//

#define USE_WiFiControl
#define USE_HTTPClientControl
#include <IO_Control.h>

const char* ssid = "LAPTOP1234";
const char* pass = "12345678";

const String httpserver1="data.etabus.gov.hk";
const int httpport1 = 443;
const String httppath1="/v1/transport/kmb/route/";

const String httpserver2="data.weather.gov.hk";
const int httpport2 = 443;
const String httppath2="/weatherAPI/opendata/weather.php?dataType=flw&lang=en";

WiFiControl wifiCtrl;
HTTPClientControl httpClientCtrl;     //  for https

int FSMstate=0;
  //  a state variable for FSM
  //  0: prompt user for inputs
  //  1: wait for user inputs, and issue HTTP request
  //  2: issue HTTPS request
  //  3: reading headers
  //  4: reading last headers
  //  5: all body received, and connection ended

/*
bool httpRequestIsRunning = false;
bool hasGotHeader = false;  //  indicating whether header of HTTP response has been received
bool hasGotBody = false;
*/

HTTPClientControl_HTTPState_t lastState;

DeclareHandler(hdlr, _ctrl, HTTPClientControl, {
  if (lastState !=_ctrl.getState() )
  { switch (_ctrl.getState())
    { case HTTPClientControl_HTTPState_t::RequestSending:
        Serial.println("http request: sending request");
        break;
      case HTTPClientControl_HTTPState_t::RequestSent:
        Serial.println("http request: all requests sent");
        break;
      case HTTPClientControl_HTTPState_t::ResponseReceiving:
        Serial.println("http request: receiving response");
        break;
      case HTTPClientControl_HTTPState_t::ResponseReceived:
        Serial.println("http request: all responses received");
        break;
    }
    lastState =_ctrl.getState();
  }
  
  switch (FSMstate)
  { case 2:
    case 3:
        while (_ctrl.isHeaderAvailable() || _ctrl.isHeaderIncomplete())
        {    
          String headerName = _ctrl.getHeaderName();
          if (headerName.equals("<b>"))
          { //  need to wait for more data on headers to arrive
            break;
          }
          if (headerName.equals("<c>"))
          { //  current header is too large and is skipped, and hence will have to continue
            continue;
          }
          if (headerName.equals("<e>"))
          { //  no more header left behind
            FSMstate=4;
            break;
          }
          if (headerName.equals("<k>"))
          { //  not a header and is skipped; will have to continue
            continue;
          }
          String headerValue = _ctrl.getHeaderValue();
          Serial.print("[");
          Serial.print(headerName);
          Serial.print("]=");
          Serial.println(headerValue);
        }
        break;
    case 4:
      if (_ctrl.isBodyIncomplete()) {
        Serial.print("Body (incomplete) is: ");
        Serial.println(_ctrl.getBody());
      }

      if (_ctrl.isBodyAvailable()) {
        Serial.print("Body (last part) is: ");
        Serial.println(_ctrl.getBody());
        _ctrl.end();
        FSMstate=5;
      }
      break;
  }
});

DeclareHandler(iocontrolHdr,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");  
  switch (FSMstate)
  { case 0:
    case 5:
      //  print out prompt for user to input
      Serial.print("press 1 for ");
      Serial.print(httpserver1);
      Serial.println(httppath1);
      Serial.print("press 2 for ");
      Serial.print(httpserver2);
      Serial.println(httppath2);
      FSMstate = 1;
      break;
    case 1:
      if (Serial.available() > 0) {
        String input = Serial.readStringUntil('\n');
        Serial.println(input);
        if (input == "1")
        { bool status=sendHTTPRequest(httpserver1,httpport1,httppath1);
          if (status)
          { Serial.print("success in sending http request to ");
            Serial.print(httpserver1);
            Serial.print(httppath1);
            FSMstate = 2;
          } else
          { Serial.print("failed in sending http request to ");
            Serial.print(httpserver1);
            Serial.print(httppath1);
            FSMstate = 0;
          }
        }
        if (input == "2")
        { bool status=sendHTTPRequest(httpserver2,httpport2,httppath2);
          if (status)
          { Serial.print("success in sending http request to ");
            Serial.print(httpserver2);
            Serial.print(httppath2);
            FSMstate = 2;
          } else
          { Serial.print("failed in sending http request to ");
            Serial.print(httpserver2);
            Serial.print(httppath2);
            FSMstate = 0;
          }
        }
      }
      break;
    default:
      break;
  }
});

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  Serial.println("chip started");

  //  initialize WiFiCtrl
  err_t err = wifiCtrl.init(WiFiControlWiFiModeAPSTA);
  if (err != Control_OK) {
    Serial.print("Failed to init wifiCtrl. Error code is: ");
    Serial.println(err);
    return;
  }
  
  //  connect to a WiFi router
  wifiCtrl.connect(ssid, pass);
  Serial.print("connecting to ");
  Serial.print(ssid);
  while (!wifiCtrl.isConnected()) {
      delay(1000);
      Serial.print(".");
  }
  Serial.println();
  Serial.print("Connected to ");
  Serial.print(ssid);
	Serial.println(" successfully");

  //  initialize the httpClientCtrl
  err = httpClientCtrl.init(wifiCtrl, true, 1024);
    //  wifiCtrl: WiFiControl object
    //  true: use secure connection (ie. for https)
    //  1024: size of buffer for receiving HTTP responses
  if (err) {
    Serial.println("httpClientCtrl failed to init");
    return;
  }

  IO_Control.enableScheduler(0,100,iocontrolHdr);
  httpClientCtrl.enableScheduler(0, 10, hdlr);
}

bool sendHTTPRequest(String _server, int _port, String _path)
{ err_t err;

  //  connect to https server
  httpClientCtrl.setInsecure();
  err = httpClientCtrl.connect(_server, _port);
  //err = httpClientCtrl.connect("data.weather.gov.hk", 443);
  if (err) {
    Serial.println("httpClientCtrl failed to connect to server");
    Serial.print("httpClientCtrl.isConnected: ");
    Serial.println(err);
    return false;
  }
  
  //  issue a GET request
  //err = httpClientCtrl.get("/weatherAPI/opendata/weather.php?dataType=flw&lang=en");
  //err = httpClientCtrl.get("/v1/transport/kmb/route/");
    //err = httpClientCtrl.get("/v1/transport/kmb/stop/A3ADFCDF8487ADB9");
  err = httpClientCtrl.get(_path);
  if (err) {
    Serial.println("httpClientCtrl failed to send GET request");
    return false;
  }
  err = httpClientCtrl.setReqHeaderConnClose();
  if (err) {
    Serial.println("httpClientCtrl failed to set connection close header");
    return false;
  }
  err = httpClientCtrl.sendRequest();
  if (err) {
    Serial.println("httpClientCtrl failed to send request");
    return false;
  }

  return true;
}

void loop() {
  IO_Control.execute();
}