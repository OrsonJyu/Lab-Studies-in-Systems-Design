#define USE_WiFiControl
#define USE_HTTPClientControl
#include <IO_Control.h>

const char* ssid = "_IOT Roaming Mesh 2";
const char* pass = "iot213213213";

WiFiControl wifiCtrl;

HTTPClientControl httpClientCtrl;

bool hasGotHeader = false;

DeclareHandler(hdlr, _ctrl, HTTPClientControl, {
  if (_ctrl.isHeaderAvailable()) {
    String headerName = _ctrl.getHeaderName();
    if (headerName == "Content-Type") {
      Serial.print("value of Content-Type is: ");
      Serial.println(_ctrl.getHeaderValue());
      hasGotHeader = true;
    }
  }

  if (_ctrl.isBodyAvailable() && hasGotHeader) {
    Serial.print("Body is: ");
    Serial.println(_ctrl.getBody());
    _ctrl.end();
  }
});

void setup() {
  IO_Control.begin();
  Serial.begin(115200);
  Serial.println("chip started");

  LittleFS.begin();

  err_t err = wifiCtrl.init(WiFiControlWiFiModeAPSTA);
  if (err != Control_OK) {
    Serial.print("Failed to init wifiCtrl. Error code is: ");
    Serial.println(err);
  } else {
    wifiCtrl.connect(ssid, pass);
    while (!wifiCtrl.isConnected()) {
      delay(1000);
      Serial.print(".");
    }
    Serial.println();
    Serial.print("Connected to ");
    Serial.print(ssid);
    Serial.println(" successfully");
    err_t err;
    err = httpClientCtrl.init(wifiCtrl, false, 1024);
    if (err) {
      Serial.println("httpClientCtrl failed to init");
      return;
    }
    err = httpClientCtrl.connect("192.168.50.110", 3000, HTTP1_1);
    if (err) {
      Serial.println("httpClientCtrl failed to connect to server");
      Serial.print("httpClientCtrl.isConnected: ");
      Serial.println(httpClientCtrl.isConnected());
      return;
    }

    err = httpClientCtrl.post("/post-data-endpoint-json", "application/json", "{\"data\":\"this is the data\"}");
    if (err) {
      Serial.println("httpClientCtrl failed to send POST request");
      return;
    }
    err = httpClientCtrl.setReqHeaderConnClose();
    if (err) {
      Serial.println("httpClientCtrl failed to set connection close header");
      return;
    }
    err = httpClientCtrl.sendRequest();
    if (err) {
      Serial.println("httpClientCtrl failed to send request");
      return;
    }

    httpClientCtrl.enableScheduler(0, 10, hdlr);
  }
}

void loop() {
  IO_Control.execute();
}