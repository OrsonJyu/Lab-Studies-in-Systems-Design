//
//  for setting up ESP32C3 as I2C slave
//    SDA - IO01
//    SCL - IO00
//    slave address - 0x12
//
//  Repeat the following flow:
//    receive data from master
//    bitwise reverse of received data and reply to master
//
//  Note:
//    for ESP32C3, pull up resistors (with 1K ohm) must be added to SCL and SDA or else I2C communication will fail
//  
#include "IO_Control.h"
#include "I2CSlaveControl.h"

const int sclPin=0;
const int sdaPin=1;
const int16_t I2C_SLAVE = 0x12;

I2CSlaveControl i2cCtrl;

uint8_t rcvbuff[256];
uint16_t rcvByteNum=0;

DeclareHandler(i2cHandler, _ctrl, I2CSlaveControl, {
  err_t err;

  if (_ctrl.receiveEventCount())
  { //  something received since last invocation of handler

    Serial.print("# of bytes received from master=");
    Serial.println(_ctrl.receivedByteNum());

    rcvByteNum=_ctrl.receivedByteNum();
    for (int i=0;i<rcvByteNum;i++)
      rcvbuff[i]=~_ctrl.receiveBuffer[i];
    
    //  prepare requestBuffer
    err=_ctrl.writeReplyBuffer(&(rcvbuff[0]),rcvByteNum);
    Serial.print("writeReplyBuffer, return value=");
    Serial.println(err);
  }

  if (_ctrl.requestEventCount())
  { //  request received from master
    Serial.print("# of request from master=");
    Serial.println(_ctrl.requestEventCount());
  }

});


void setup() {
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = i2cCtrl.init(0,sclPin,sdaPin,I2C_SLAVE,100000);
  if (err != Control_OK) {
    Serial.print("Failed to init I2CSlaveControl. Reason is: ");
    switch (err) {
      case Control_ActiveAlready:
        {
          Serial.println("I2CSlaveControl is active already");
          break;
        }
      default:
        Serial.print("error code=");
        Serial.println(err);
        break;
    }
  }
  i2cCtrl.enableScheduler(500,10,i2cHandler);
}

void loop() {
  IO_Control.execute();
}
