//
//  for setting up ESP32C3 as I2C master
//    SDA - IO01
//    SCL - IO00
//
//  Repeat the following flow:
//    send out no of bytes (=transferByteNum) to an I2C slave device with address = 0x12
//    request from the slave device with the same number of bytes
//
//  Note:
//    for ESP32C3, pull up resistors (with 1K ohm) must be added to SCL and SDA or else I2C communication will fail
//  
#include "IO_Control.h"

const int sclPin=0;
const int sdaPin=1;
const int16_t I2C_SLAVE = 0x12;
const int16_t transferByteNum = 13;

I2CMasterControl i2cCtrl;
enum
{ State_Idle,
  State_SentToSlave,
  State_WaitForDataFromSlave,
  State_SlaveDataReceived,
} state;

ulong_t t0s,t0e,t1s,t1e;
uint8_t sendBuffer[transferByteNum];
uint8_t receiveBuffer[transferByteNum];
uint16_t receiveBufferPtr=0;
uint8_t transferVal=0;

DeclareHandler(i2cHandler, _ctrl, I2CMasterControl, {
  err_t err;

  switch (state){
  case State_Idle:
    t0s = micros();
    err=_ctrl.beginTransmission(I2C_SLAVE);
    for (int i=0;i<transferByteNum;i++)
    { sendBuffer[i]=transferVal;
      _ctrl.write(transferVal++);      
    }
    err=_ctrl.endTransmission();
    state = State_SentToSlave;
    t0e = micros();

    Serial.println("data to slave:");
    for (int i=0;i<transferByteNum;i++)
    { Serial.print(sendBuffer[i],HEX);
      Serial.print(" ");
    }
    Serial.println();
    break;
  case State_SentToSlave:
    t1s = micros(); 
    err=_ctrl.requestFrom(I2C_SLAVE,transferByteNum);
    if (err!=transferByteNum)
    { Serial.println("Error: return value from requestFrom does not match");
      Serial.print("requested=");
      Serial.println(transferByteNum);
      Serial.print("returned value=");
      Serial.println(err);
    }
    state = State_WaitForDataFromSlave;
    receiveBufferPtr=0;
    t1e = micros();
    break;
  case State_WaitForDataFromSlave:
    if (_ctrl.receivedByteNum()>0)
    { for (int i=0;i<_ctrl.receivedByteNum();i++)
      { receiveBuffer[receiveBufferPtr++]=_ctrl.receiveBuffer[i];
      }
      state=State_SlaveDataReceived;
      break;
    }
    break;
  case State_SlaveDataReceived:
    Serial.print("data from slave:");
    for (int i=0;i<receiveBufferPtr;i++)
    { Serial.print(receiveBuffer[i],HEX);
      Serial.print(" ");
    }
    Serial.println();

    Serial.print("t0e-t0s=");
    Serial.println(t0e-t0s);
    Serial.print("t1e-t1s=");
    Serial.println(t1e-t1s);

    state = State_Idle;
    break;
  };
});

void setup() {
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = i2cCtrl.init(0,sclPin,sdaPin,50000);
  if (err != Control_OK) {
    Serial.print("Failed to init I2CMasterControl. Reason is: ");
    switch (err) {
      case Control_ActiveAlready:
        Serial.println("I2CMasterControl is active already");
        break;
      default:
        Serial.print("error code=");
        Serial.println(err);
        break;
    }
  }
  state=State_Idle;
  i2cCtrl.enableScheduler(500,10,i2cHandler);
}

void loop() {
  IO_Control.execute();
}
