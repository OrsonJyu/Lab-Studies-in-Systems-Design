//
//  for demonstrating full-duplex serial transmission over HW UART with flow control 
//    rx = IO01
//    tx = IO00
//    cts = IO03
//    rts = IO04
//
#include "IO_Control.h"
#include "UARTControl.h"

UARTControl uart0Ctrl;
uint8_t data[1024];
uint8_t counter=0;

int rxPin = 1;
int txPin = 0;
int ctsPin = 3; //  -1 if not use
int rtsPin = 4; //  -1 if not use


DeclareHandler(uart0Handler, _ctrl, UARTControl, {
  if (_ctrl.isDataReceived())
  { 
    Serial.print("\nno of bytes received=");
    Serial.println(_ctrl.receivedByteNum());
    for (int i=0;i<_ctrl.receivedByteNum();i++)
    { Serial.print(_ctrl.receiveBuffer[i],HEX);
      Serial.print(" ");
    }
    Serial.println();
  }

});

DeclareHandler(io_control_Handler, _ctrl, IOControl, {

  int len=uart0Ctrl.availableForWrite();
  Serial.print("\navailableForWrite=");
  Serial.println(len);

  if (len!=0)
  { uint8_t val = random(256);

    len = len/2;

    for (int i=0;i<len;i++)
    { data[i]=val;
      val +=1;
    }

    int count=uart0Ctrl.write((uint8_t*) data,len);
    Serial.print("no of bytes written=");
    Serial.println(count);
    for (int i=0;i<len;i++)
    { Serial.print(data[i],HEX);
      Serial.print(" ");
    }
    Serial.println();
  }
});

void setup() {
  // put your setup code here, to run once:

  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = uart0Ctrl.init(1,rxPin,txPin,ctsPin,rtsPin,9600,UARTControl::UART_8N1);
    //  IO01 - rx
    //  IO00 - tx
    //  IO03 - cts
    //  IO04 - rts

  if (err != Control_OK) {
    Serial.print("Failed to init UARTControl. Reason is: ");
    switch (err) {
      case Control_ActiveAlready:
        {
          Serial.println("UARTControl is active already");
          break;
        }
    }
  }

  uart0Ctrl.enableScheduler(1500,1000,uart0Handler);
  IO_Control.enableScheduler(500,1000,io_control_Handler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
