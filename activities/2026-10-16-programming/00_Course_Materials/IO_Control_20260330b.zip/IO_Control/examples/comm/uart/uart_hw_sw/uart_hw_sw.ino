//
//  for demonstrating full-duplex serial transmission between HW UART and SW UART 
//    hw_rx = IO01
//    hw_tx = IO00
//    sw_rx = IO03
//    sw_tx = IO04
//
#include "IO_Control.h"
#include "UARTControl.h"

UARTControl hwUartCtrl;
UARTControl swUartCtrl;

uint8_t data[128];
bool startup=true;

int hwRxPin = 1;
int hwTxPin = 0;
int swRxPin = 3; 
int swTxPin = 4;

DeclareHandler(hwUartHandler, _ctrl, UARTControl, {
  if (_ctrl.isDataReceived())
  { 
    Serial.print("\n(HW) no of bytes received=");
    Serial.println(_ctrl.receivedByteNum());
    for (int i=0;i<_ctrl.receivedByteNum();i++)
    { Serial.print(_ctrl.receiveBuffer[i],HEX);
      Serial.print(" ");
    }
    Serial.println();

    //  write the same number of bytes to other side
    int len=_ctrl.availableForWrite();
    Serial.print("\n(HW) availableForWrite=");
    Serial.println(len);

    if (len!=0)
    { uint8_t val = random(256);

      for (int i=0;i<len;i++)
      { data[i]=val;
        val +=1;
      }

      int count=_ctrl.write((uint8_t*) data,len);
      Serial.print("no of bytes written=");
      Serial.println(count);
      for (int i=0;i<len;i++)
      { Serial.print(data[i],HEX);
        Serial.print(" ");
      }
      Serial.println();
    }
  } 

});

DeclareHandler(swUartHandler, _ctrl, UARTControl, {
  if (_ctrl.isDataReceived())
  { 
    Serial.print("\n(SW) no of bytes received=");
    Serial.println(_ctrl.receivedByteNum());
    for (int i=0;i<_ctrl.receivedByteNum();i++)
    { Serial.print(_ctrl.receiveBuffer[i],HEX);
      Serial.print(" ");
    }
    Serial.println();

    //  write the same number of bytes to other side
    int len=_ctrl.availableForWrite();
    Serial.print("\n(SW) availableForWrite=");
    Serial.println(len);

    if (len!=0)
    { uint8_t val = random(256);

      for (int i=0;i<len;i++)
      { data[i]=val;
        val +=1;
      }

      int count=_ctrl.write((uint8_t*) data,len);
      // for (int i=0;i<len;i++)
      //   _ctrl.write(data[i]);
      // int count=len;

      Serial.print("no of bytes written=");
      Serial.println(count);
      for (int i=0;i<count;i++)
      { Serial.print(data[i],HEX);
        Serial.print(" ");
      }
      Serial.println();
    }
  } 
});

DeclareHandler(io_control_Handler, _ctrl, IOControl, {

  if (startup)
  { Serial.println("startup:");
    int len=hwUartCtrl.availableForWrite();
    Serial.print("(HW) availableForWrite=");
    Serial.println(len);

    if (len!=0)
    { 
      uint8_t val = random(256);
      for (int i=0;i<len;i++)
      { data[i]=val;
        val +=1;
      }

      int count=hwUartCtrl.write((uint8_t*) data,len);
      Serial.print("no of bytes written=");
      Serial.println(count);
      for (int i=0;i<count;i++)
        { Serial.print(data[i],HEX);
          Serial.print(" ");
        }
        Serial.println();
    }
    startup=false;
  }

});

void setup() {
  // put your setup code here, to run once:

  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = hwUartCtrl.init(1,hwRxPin,hwTxPin,-1,-1,9600,UARTControl::UART_8N1);
    //  IO01 - hw_rx
    //  IO00 - hw_tx

  if (err != Control_OK) {
    Serial.print("Failed to init UARTControl (HW). Reason is: ");
    switch (err) {
      case Control_ActiveAlready:
        {
          Serial.println("UARTControl is active already");
          break;
        }
    }
  }

  err = swUartCtrl.init(-1,swRxPin,swTxPin,-1,-1,9600,UARTControl::UART_8N1);
    //  IO03 - sw_rx
    //  IO04 - sw_tx

  if (err != Control_OK) {
    Serial.print("Failed to init UARTControl (SW). Reason is: ");
    switch (err) {
      case Control_ActiveAlready:
        {
          Serial.println("UARTControl is active already");
          break;
        }
    }
  }

  hwUartCtrl.enableScheduler(1500,1000,hwUartHandler);
  swUartCtrl.enableScheduler(1000,1000,swUartHandler);
  IO_Control.enableScheduler(2000,1000,io_control_Handler);

}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}

