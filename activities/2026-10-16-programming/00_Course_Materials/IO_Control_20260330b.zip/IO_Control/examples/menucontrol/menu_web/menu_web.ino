#define USE_WiFiControl

#define USE_AsyncWebServerControl

#include <IO_Control.h>

#include <LittleFS.h>

WiFiControl wifiCtrl;

MenuControl menuCtrl(&Serial);

AsyncWebServerControl awsCtrl;

WebSocketStream wsStream;

Menu* wifiMenu;

MenuItem* mainMenuDownloadInitItem;

String wifi_ssid = "";
String wifi_password = "";

void redirectIndex(AsyncWebServerRequest* _request) {
  _request->redirect("/index.html");
}

void downloadHTML(String hostname, String api, const char* fileName) {
  Serial.println("Downloading init file...");
  NetworkClientSecure ncs;
  ncs.setInsecure();
  String getHeader = "GET " + api + " HTTP/1.0";
  String hostHeader = "Host: " + hostname;
  if (ncs.connect(hostname.c_str(), 443)) {
    ncs.println(getHeader);
    ncs.println(hostHeader);
    ncs.println("Connection: close");
    ncs.println();

    // Open file to save content
    File file = LittleFS.open("/downloadedFile.html", "w");
    if (!file) {
      Serial.println("Failed to open file for writing.");
      return;
    }

    // Skip headers and start saving body content
    bool headersEnded = false;
    while (ncs.connected()) {
      String line = ncs.readStringUntil('\n');
      if (line == "\r") {
        headersEnded = true;
        continue;
      }
      if (headersEnded) {
        file.print(line);  // Save the content into the file
      }
    }

    file.close();  // Close file after saving
    // Serial.println("HTML file downloaded and saved.");
    ncs.stop();
    Serial.println("Download finished.");
    recoverScriptTags("/downloadedFile.html", "/index.html");

    if (LittleFS.exists("/index.html")) {
      mainMenuDownloadInitItem->setDesc("Download Init File (file exists)");
    } else {
      mainMenuDownloadInitItem->setDesc("Download Init File");
    }
  } else {
    Serial.println("Failed to connect to server.");
  }
}

err_t mainMenuFormatFsItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuFormatFsItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  LittleFS.begin(true);
  return Control_OK;
}

err_t mainMenuRebootItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuRebootItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  ESP.restart();
  return Control_OK;
}


void onWsEvent(AsyncWebSocket* server, AsyncWebSocketClient* client,
               AwsEventType type, void* arg, uint8_t* data, size_t len) {
  if (type == WS_EVT_CONNECT) {
    Serial.printf("WebSocket client #%u connected\n", client->id());

    // Create a stream wrapper for this client
    wsStream.setClient(client);

    wsStream.println("Connected to ESP32 Serial Monitor (from wsStream)");

    menuCtrl.setOutputStream(&wsStream);

    menuCtrl.printMenu();

  } else if (type == WS_EVT_DISCONNECT) {
    Serial.printf("WebSocket client #%u disconnected\n", client->id());

    wsStream.setClient(nullptr);

    menuCtrl.setOutputStream(&Serial);

  } else if (type == WS_EVT_DATA) {
    AwsFrameInfo* info = (AwsFrameInfo*)arg;

    if (info->opcode == WS_TEXT && info->final && info->index == 0 && info->len == len) {
      wsStream.setClient(client);
      // Feed the incoming message into the stream buffer
      wsStream.feedMessage((char*)data, len);
    }
  }
}

err_t mainMenuHdlr(MenuControl& _menuCtrl, Menu& _menu, String& msg) {
  _menuCtrl.getStream().print("mainMenuHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}

err_t mainMenuItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  int8_t commaPos1 = msg.indexOf(',');
  int8_t commaPos2 = msg.indexOf(',', commaPos1 + 1);
  if (commaPos1 != -1 && commaPos2 != -1) {
    int8_t pinNum = msg.substring(commaPos1 + 1, commaPos2).toInt();
    int8_t status = msg.substring(commaPos2 + 1).toInt();
    if (status == 0) {
      digitalWrite(pinNum, LOW);
    } else if (status == 1) {
      digitalWrite(pinNum, HIGH);
    }
  }

  return Control_OK;
}

err_t mainMenuDownloadInitItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuDownloadInitItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  if (!wifiCtrl.isInit()) {
    Serial.println("WiFiControl is not initialized.");
    return Control_NotInit;
  } else {
    if (!wifiCtrl.isConnected()) {
      Serial.println("WiFi is not connected. Cannot download file.");
      return WiFiControl_NotConnected;
    }
  }
  downloadHTML("www.designandmake.org", "/download/attachments/260375561/serial_monitor_webapp.html?version=1&modificationDate=1767945310845&api=v2&download=true", "/index.html");
  return Control_OK;
}


err_t wifiMenuHdlr(MenuControl& _menuCtrl, Menu& _menu, String& msg) {
  _menuCtrl.getStream().print("wifiMenuHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}

err_t menuMenuHdlr(MenuControl& _menuCtrl, Menu& _menu, String& msg) {
  _menuCtrl.getStream().println("meshMenuHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}


err_t wifiConfigItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("wifiConfigItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  int8_t commaPos1 = msg.indexOf(',');
  int8_t commaPos2 = msg.indexOf(',', commaPos1 + 1);
  if (commaPos1 != -1 && commaPos2 != -1) {
    String ssid = msg.substring(commaPos1 + 1, commaPos2);
    String pass = msg.substring(commaPos2 + 1);
    wifiCtrl.connect(ssid, pass);
    _menuCtrl.getStream().print("Connecting to ");
    _menuCtrl.getStream().println(ssid);
    while (!wifiCtrl.isConnected()) {
      vTaskDelay(500 / portTICK_PERIOD_MS);
      _menuCtrl.getStream().print(".");
    }
    _menuCtrl.getStream().println();
    _menuCtrl.getStream().println("WiFi connected");
    wifi_ssid = ssid;
    wifi_password = pass;
    saveWiFiCredential(wifi_ssid, wifi_password);
    IPAddress ip = WiFi.localIP();
    String ip_str = String(ip[0]) + "." + String(ip[1]) + "." + String(ip[2]) + "." + String(ip[3]);
    String newWiFiDes = "wifi setting (" + ip_str + ")";
    wifiMenu->setDesc(newWiFiDes);
  }
  return Control_OK;
}

err_t wifiReturnItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("wifiReturnItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}


void setup() {

  Serial.begin(115200);

  IO_Control.begin();

  if (!LittleFS.begin()) {
    LittleFS.begin(true);
  }

  err_t err = wifiCtrl.init(WiFiControlWiFiModeAPSTA);
  if (err != Control_OK) {
    Serial.print("Failed to init wifiCtrl. Error code is: ");
    Serial.println(err);
  }

  File file = LittleFS.open("/wifi.json", "r");
  if (file) {
    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, file);
    if (!err) {
      wifi_ssid = doc["ssid"].as<const char*>();
      wifi_password = doc["password"].as<const char*>();
      wifiCtrl.connect(wifi_ssid, wifi_password);
      uint8_t retryCount = 0;
      Serial.print("wifi.json exists. Now connecting to ");
      Serial.print(wifi_ssid);
      while (!wifiCtrl.isConnected() && retryCount < 4) {
        Serial.print(".");
        retryCount++;
        delay(500);
      }
      Serial.println();
      if (wifiCtrl.isConnected()) {
        Serial.println("WiFi connected successfully");
      } else {
        Serial.println("Failed to connect to WiFi saved in wifi.json");
      }
    }
  }

  menuCtrl.init();

  Menu* mainMenu = menuCtrl.getMainMenu();
  mainMenu->setCmd("main");
  mainMenu->setDesc("Main Menu (L0)");
  // mainMenu->setMenuCmdHandler(mainMenuHdlr);


  MenuItem* mainMenuItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuItem->setCmd("g");
  mainMenuItem->setDesc("Set Status of GPIO <g,pinNum,status> e.g. <g,13,1>");
  mainMenuItem->setItemCmdHandler(mainMenuItemHdlr);
  // mainMenuItem->setConsoleHandler(cHdlr);

  mainMenuDownloadInitItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuDownloadInitItem->setCmd("d");
  if (LittleFS.exists("/index.html")) {
    mainMenuDownloadInitItem->setDesc("Download Init File (file exists)");
  } else {
    mainMenuDownloadInitItem->setDesc("Download Init File");
  }
  mainMenuDownloadInitItem->setItemCmdHandler(mainMenuDownloadInitItemHdlr);

  MenuItem* mainMenuFormatFsItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuFormatFsItem->setCmd("f");
  mainMenuFormatFsItem->setDesc("Format LittleFS");
  mainMenuFormatFsItem->setItemCmdHandler(mainMenuFormatFsItemHdlr);


  wifiMenu = mainMenu->createMenu();
  wifiMenu->setCmd("w");
  if (wifiCtrl.isConnected()) {
    IPAddress ip = WiFi.localIP();
    String ip_str = String(ip[0]) + "." + String(ip[1]) + "." + String(ip[2]) + "." + String(ip[3]);
    String newWiFiDes = "wifi setting (" + ip_str + ")";
    wifiMenu->setDesc(newWiFiDes);
  } else {
    wifiMenu->setDesc("wifi setting");
  }
  wifiMenu->setMenuCmdHandler(wifiMenuHdlr);

  MenuItem* mainMenuRebootItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuRebootItem->setCmd("r");
  mainMenuRebootItem->setDesc("Reboot");
  mainMenuRebootItem->setItemCmdHandler(mainMenuRebootItemHdlr);


  MenuItem* wifiConfigItem = wifiMenu->createMenuItem(MenuItemType::MENU_ITEM);
  wifiConfigItem->setCmd("c");
  wifiConfigItem->setDesc("set SSID and password <c, ssid, password>");
  wifiConfigItem->setItemCmdHandler(wifiConfigItemHdlr);


  MenuItem* wifiReturnItem = wifiMenu->createMenuItem(MenuItemType::MENU_ITEM_RETURN);
  wifiReturnItem->setCmd("x");
  wifiReturnItem->setDesc("return");
  wifiReturnItem->setItemCmdHandler(wifiReturnItemHdlr);

  menuCtrl.printMenu();

  menuCtrl.enableScheduler(0, 10, nullptr);

  awsCtrl.onHTTP("/", HTTPMethod_GET, redirectIndex);

  // awsCtrl.serveStaticFile("/index.html", LittleFS, "/index.html");
  awsCtrl.onHTTP("/index.html", HTTPMethod_GET, [](AsyncWebServerRequest* request) {
    // Optional: Check if file exists first to handle errors gracefully
    if (LittleFS.exists("/index.html")) {
      request->send(LittleFS, "/index.html", "text/html");
    } else {
      request->send(404, "text/plain", "File not found yet");
    }
  });

  awsCtrl.beginWithWS("/ws", onWsEvent);
}

void loop() {
}




// Function to recover <script> and </script> by replacing placeholders
bool recoverScriptTags(const char* sourcePath, const char* destPath) {
  File source = LittleFS.open(sourcePath, FILE_READ);
  if (!source) {
    Serial.println("Failed to open source file for reading");
    return false;
  }

  String content = source.readString();
  source.close();

  // Replace all occurrences of the placeholders
  content.replace("??123??", "<script>");
  content.replace("??321??", "</script>");

  // Write the recovered content to the destination file
  File dest = LittleFS.open(destPath, FILE_WRITE);
  if (!dest) {
    Serial.println("Failed to open destination file for writing");
    return false;
  }

  if (dest.print(content)) {
    dest.close();
    return true;
  } else {
    Serial.println("Failed to write recovered content");
    dest.close();
    return false;
  }
}

void saveWiFiCredential(String ssid, String pass) {
  File file = LittleFS.open("/wifi.json", "w");
  JsonDocument doc;
  doc["ssid"] = ssid;
  doc["password"] = pass;
  serializeJson(doc, file);
  file.close();
}