#define USE_WiFiControl

#define USE_AsyncWebServerControl

#define MESH_PREFIX "mesh_prefix"
#define MESH_PASSWORD "mesh_password"
#define MESH_PORT 5555

#include <IO_Control.h>

#include <LittleFS.h>

#include "painlessMesh.h"

WiFiControl wifiCtrl;

MenuControl menuCtrl(&Serial);

AsyncWebServerControl awsCtrl;

WebSocketStream wsStream;

Menu* wifiMenu;

MenuItem* mainMenuDownloadInitItem;

String wifi_ssid = "";
String wifi_password = "";

Scheduler userScheduler;
painlessMesh mesh;
bool isPainlessMeshInit = false;

uint32_t connectedNode = 0;

void redirectIndex(AsyncWebServerRequest* _request) {
  _request->redirect("/index.html");
}

void downloadHTML(String hostname, String api, const char* fileName) {
  Serial.println("Downloading init file...");
  NetworkClientSecure ncs;
  ncs.setInsecure();
  String getHeader = "GET " + api + " HTTP/1.0";
  String hostHeader = "Host: " + hostname;
  if (ncs.connect(hostname.c_str(), 443)) {
    ncs.println(getHeader);
    ncs.println(hostHeader);
    ncs.println("Connection: close");
    ncs.println();

    // Open file to save content
    File file = LittleFS.open("/downloadedFile.html", "w");
    if (!file) {
      Serial.println("Failed to open file for writing.");
      return;
    }

    // Skip headers and start saving body content
    bool headersEnded = false;
    while (ncs.connected()) {
      String line = ncs.readStringUntil('\n');
      if (line == "\r") {
        headersEnded = true;
        continue;
      }
      if (headersEnded) {
        file.print(line);  // Save the content into the file
      }
    }

    file.close();  // Close file after saving
    // Serial.println("HTML file downloaded and saved.");
    ncs.stop();
    Serial.println("Download finished.");
    recoverScriptTags("/downloadedFile.html", "/index.html");

    if (LittleFS.exists("/index.html")) {
      mainMenuDownloadInitItem->setDesc("Download Init File (file exists)");
    } else {
      mainMenuDownloadInitItem->setDesc("Download Init File");
    }
  } else {
    Serial.println("Failed to connect to server.");
  }
}

void receivedCallback(uint32_t from, String& msg) {
  // Serial.printf("Sensor Node: Received from %u: %s\n", from, msg.c_str());
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, msg);
  if (!err) {
    String incomingMsg = doc["msg"].as<const char*>();
    if (incomingMsg == "broadcast_nodeid") {
      uint32_t _nodeid = doc["nodeid"].as<uint32_t>();
      String _msg = "Device " + String(_nodeid) + " has just broadcasted its id";
      menuCtrl.getStream().println(_msg);
      return;
    }
  }
  if (from == connectedNode) {
    menuCtrl.getStream().println(msg.c_str());
  }
}

void newConnectionCallback(uint32_t nodeId) {
  Serial.printf("Sensor Node: New connection to %u\n", nodeId);
}

void changedConnectionCallback() {
  Serial.printf("Sensor Node: Changed connections. Nodes: %s\n",
                mesh.subConnectionJson().c_str());
}

void onWsEvent(AsyncWebSocket* server, AsyncWebSocketClient* client,
               AwsEventType type, void* arg, uint8_t* data, size_t len) {
  if (type == WS_EVT_CONNECT) {
    Serial.printf("WebSocket client #%u connected\n", client->id());

    // Create a stream wrapper for this client
    wsStream.setClient(client);

    wsStream.println("Connected to ESP32 Serial Monitor (from wsStream)");

    menuCtrl.setOutputStream(&wsStream);

    menuCtrl.printMenu();

  } else if (type == WS_EVT_DISCONNECT) {
    Serial.printf("WebSocket client #%u disconnected\n", client->id());

    wsStream.setClient(nullptr);

    menuCtrl.setOutputStream(&Serial);

  } else if (type == WS_EVT_DATA) {
    AwsFrameInfo* info = (AwsFrameInfo*)arg;

    if (info->opcode == WS_TEXT && info->final && info->index == 0 && info->len == len) {
      wsStream.setClient(client);
      // Feed the incoming message into the stream buffer
      if (strcmp((const char*)data, "disconnectNode") == 0) {
        connectedNode = 0;
        menuCtrl.setOutputStream(&wsStream);
        menuCtrl.printMenu();
        return;
      }

      if (strcmp((const char*)data, "getNodeList") == 0) {
        String nodeArrStr;
        auto nodes = mesh.getNodeList();
        JsonDocument doc;
        JsonArray array = doc.to<JsonArray>();
        for (auto nodeId : nodes) {
          array.add(nodeId);
        }
        serializeJson(doc, nodeArrStr);
        awsCtrl.sendWS(client, nodeArrStr);
        return;
      }

      String inputstr = String((const char*)data, len);
      JsonDocument doc;
      DeserializationError err = deserializeJson(doc, inputstr);
      if (!err) {
        // Serial.println("A JSON is received");
        String msg = doc["msg"].as<const char*>();
        if (msg == "connectNode") {
          uint32_t target = doc["id"].as<uint32_t>();
          connectedNode = target;
          Serial.printf("Receive connectNode command. Connecting to %d\n", target);
          vTaskDelay(2000 / portTICK_PERIOD_MS);
          JsonDocument _doc;
          _doc["msg"] = "initMsg";
          _doc["id"] = mesh.getNodeId();
          String rMsg;
          serializeJson(_doc, rMsg);
          mesh.sendSingle(connectedNode, rMsg);
        } else if (msg == "disconnectCurrentNode") {
          connectedNode = 0;
          JsonDocument _doc;
          _doc["msg"] = "disconnect";
          String rMsg;
          serializeJson(_doc, rMsg);
          menuCtrl.printMenu();
        } else if (msg == "toggleLight") {
          uint32_t _nodeid = doc["nodeid"].as<uint32_t>();
          JsonDocument rdoc;
          rdoc["msg"] = "toggleLight";
          String rMsg;
          serializeJson(rdoc, rMsg);
          mesh.sendSingle(_nodeid, rMsg);
        }
        return;
      }

      if (connectedNode == 0) {
        wsStream.feedMessage((char*)data, len);
      } else {
        String str = String((const char*)data, len);
        mesh.sendSingle(connectedNode, str);
      }
    }
  }
}

err_t mainMenuHdlr(MenuControl& _menuCtrl, Menu& _menu, String& msg) {
  _menuCtrl.getStream().print("mainMenuHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}

err_t mainMenuItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  int8_t commaPos1 = msg.indexOf(',');
  int8_t commaPos2 = msg.indexOf(',', commaPos1 + 1);
  if (commaPos1 != -1 && commaPos2 != -1) {
    int8_t pinNum = msg.substring(commaPos1 + 1, commaPos2).toInt();
    int8_t status = msg.substring(commaPos2 + 1).toInt();
    if (status == 0) {
      digitalWrite(pinNum, LOW);
    } else if (status == 1) {
      digitalWrite(pinNum, HIGH);
    }
  }

  return Control_OK;
}

err_t mainMenuDownloadInitItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuDownloadInitItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  if (!wifiCtrl.isInit()) {
    Serial.println("WiFiControl is not initialized.");
    return Control_NotInit;
  } else {
    if (!wifiCtrl.isConnected()) {
      Serial.println("WiFi is not connected. Cannot download file.");
      return WiFiControl_NotConnected;
    }
  }
  downloadHTML("www.designandmake.org", "/download/attachments/260375561/esp_serial2.html?version=1&modificationDate=1768818277074&api=v2&download=true", "/index.html");
  return Control_OK;
}

err_t mainMenuFormatFsItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuFormatFsItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  LittleFS.begin(true);
  return Control_OK;
}

err_t mainMenuRebootItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("mainMenuRebootItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  ESP.restart();
  return Control_OK;
}


err_t wifiMenuHdlr(MenuControl& _menuCtrl, Menu& _menu, String& msg) {
  _menuCtrl.getStream().print("wifiMenuHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}

err_t menuMenuHdlr(MenuControl& _menuCtrl, Menu& _menu, String& msg) {
  _menuCtrl.getStream().println("meshMenuHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}


err_t wifiConfigItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("wifiConfigItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  int8_t commaPos1 = msg.indexOf(',');
  int8_t commaPos2 = msg.indexOf(',', commaPos1 + 1);
  if (commaPos1 != -1 && commaPos2 != -1) {
    String ssid = msg.substring(commaPos1 + 1, commaPos2);
    String pass = msg.substring(commaPos2 + 1);
    wifiCtrl.connect(ssid, pass);
    _menuCtrl.getStream().print("Connecting to ");
    _menuCtrl.getStream().println(ssid);
    while (!wifiCtrl.isConnected()) {
      vTaskDelay(500 / portTICK_PERIOD_MS);
      _menuCtrl.getStream().print(".");
    }
    _menuCtrl.getStream().println();
    _menuCtrl.getStream().println("WiFi connected");
    wifi_ssid = ssid;
    wifi_password = pass;
    saveWiFiCredential(wifi_ssid, wifi_password);
    IPAddress ip = WiFi.localIP();
    String ip_str = String(ip[0]) + "." + String(ip[1]) + "." + String(ip[2]) + "." + String(ip[3]);
    String newWiFiDes = "wifi setting (" + ip_str + ")";
    wifiMenu->setDesc(newWiFiDes);
  }
  return Control_OK;
}

err_t wifiReturnItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("wifiReturnItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}


// <b, mesh_id, mesh_pass, port, router_ssid, router_pass>
err_t bridgeConfigItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("bridgeConfigItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  int8_t commaPos1 = msg.indexOf(',');
  int8_t commaPos2 = msg.indexOf(',', commaPos1 + 1);
  int8_t commaPos3 = msg.indexOf(',', commaPos2 + 1);
  int8_t commaPos4 = msg.indexOf(',', commaPos3 + 1);
  int8_t commaPos5 = msg.indexOf(',', commaPos4 + 1);
  if (commaPos1 != -1 && commaPos2 != -1 && commaPos3 != -1 && commaPos4 != -1 && commaPos5 != -1) {
    String meshID = msg.substring(commaPos1 + 1, commaPos2);
    String pass = msg.substring(commaPos2 + 1, commaPos3);
    uint32_t mesh_port = msg.substring(commaPos3 + 1, commaPos4).toInt();
    String router_ssid = msg.substring(commaPos4 + 1, commaPos5);
    String router_pass = msg.substring(commaPos5 + 1);

    // mesh.setDebugMsgTypes(ERROR | STARTUP);
    // mesh.init(meshID, pass, &userScheduler, MESH_PORT, WIFI_AP_STA, 0);
    mesh.initAsBridge(meshID.c_str(), pass.c_str(),
                      router_ssid.c_str(), router_pass.c_str(),
                      &userScheduler, mesh_port);
    mesh.onReceive(&receivedCallback);
    mesh.onNewConnection(&newConnectionCallback);
    mesh.onChangedConnections(&changedConnectionCallback);
    mesh.onDroppedConnection([](uint32_t nodeId) {
      Serial.printf("Lost connection to: %u\n", nodeId);
    });
    isPainlessMeshInit = true;
    _menuCtrl.getStream().print("Connecting to ");
    _menuCtrl.getStream().println(router_ssid);
    while (!wifiCtrl.isConnected()) {
      vTaskDelay(500 / portTICK_PERIOD_MS);
      _menuCtrl.getStream().print(".");
    }
    _menuCtrl.getStream().println();
    _menuCtrl.getStream().println("WiFi connected");
    wifi_ssid = router_ssid;
    wifi_password = router_pass;
    saveWiFiCredential(wifi_ssid, wifi_password);
    IPAddress ip = WiFi.localIP();
    String ip_str = String(ip[0]) + "." + String(ip[1]) + "." + String(ip[2]) + "." + String(ip[3]);
    String newWiFiDes = "wifi setting (" + ip_str + ")";
    wifiMenu->setDesc(newWiFiDes);
  }
  return Control_OK;
}

err_t meshConfigItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("meshConfigItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  int8_t commaPos1 = msg.indexOf(',');
  int8_t commaPos2 = msg.indexOf(',', commaPos1 + 1);
  if (commaPos1 != -1 && commaPos2 != -1) {
    String meshID = msg.substring(commaPos1 + 1, commaPos2);
    String pass = msg.substring(commaPos2 + 1);
    mesh.setDebugMsgTypes(ERROR | STARTUP);
    // mesh.init(meshID, pass, &userScheduler, MESH_PORT, WIFI_AP_STA, 0);
    mesh.init(meshID, pass, 5555, WIFI_AP_STA, 0);
    mesh.onReceive(&receivedCallback);
    mesh.onNewConnection(&newConnectionCallback);
    mesh.onChangedConnections(&changedConnectionCallback);
    mesh.onDroppedConnection([](uint32_t nodeId) {
      Serial.printf("Lost connection to: %u\n", nodeId);
    });
  }
  return Control_OK;
}

err_t getNodeListItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("getNodeListItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  auto nodes = mesh.getNodeList();
  if (nodes.size() == 0) {
    _menuCtrl.getStream().println("No Connected Node");
    return Control_OK;
  }
  _menuCtrl.getStream().println("Node: ");
  // Serial.println(nodes.size());
  for (auto nodeId : nodes) {
    _menuCtrl.getStream().println(nodeId);
  }
  return Control_OK;
}

err_t meshReturnItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("meshReturnItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  return Control_OK;
}

err_t connectNodeItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("connectNodeItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  _menuCtrl.setOutputStream(&Serial);
  int8_t commaPos1 = msg.indexOf(',');
  if (commaPos1 != -1) {
    uint32_t targetID = msg.substring(commaPos1 + 1).toInt();
    connectedNode = targetID;
    vTaskDelay(2000 / portTICK_PERIOD_MS);
    JsonDocument doc;
    doc["msg"] = "initMsg";
    doc["id"] = mesh.getNodeId();
    String rMsg;
    serializeJson(doc, rMsg);
    mesh.sendSingle(connectedNode, rMsg);
  }
  return Control_OK;
}

err_t disconnectNodeItemHdlr(MenuControl& _menuCtrl, MenuItem& _menuItem, String& msg) {
  _menuCtrl.getStream().print("connectNodeItemHdlr received: ");
  _menuCtrl.getStream().println(msg);
  connectedNode = 0;
  JsonDocument doc;
  doc["msg"] = "disconnect";
  String rMsg;
  serializeJson(doc, rMsg);
  mesh.sendSingle(connectedNode, rMsg);
  return Control_OK;
}

void setup() {

  Serial.begin(115200);

  IO_Control.begin();

  if (!LittleFS.begin()) {
    LittleFS.begin(true);
  }

  err_t err = wifiCtrl.init(WiFiControlWiFiModeAPSTA);
  if (err != Control_OK) {
    Serial.print("Failed to init wifiCtrl. Error code is: ");
    Serial.println(err);
  }

  File file = LittleFS.open("/wifi.json", "r");
  if (file) {
    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, file);
    if (!err) {
      wifi_ssid = doc["ssid"].as<const char*>();
      wifi_password = doc["password"].as<const char*>();
      wifiCtrl.connect(wifi_ssid, wifi_password);
      uint8_t retryCount = 0;
      Serial.print("wifi.json exists. Now connecting to ");
      Serial.print(wifi_ssid);
      while (!wifiCtrl.isConnected() && retryCount < 4) {
        Serial.print(".");
        retryCount++;
        delay(500);
      }
      Serial.println();
      if (wifiCtrl.isConnected()) {
        Serial.println("WiFi connected successfully");
      } else {
        Serial.println("Failed to connect to WiFi saved in wifi.json");
      }
    }
  }

  // wsStream = new WebSocketStream();

  // menuCtrl.init();

  // String mainMenuDesc = "Main Menu";

  Menu* mainMenu = menuCtrl.getMainMenu();
  mainMenu->setCmd("main");
  mainMenu->setDesc("Main Menu (L0)");
  // mainMenu->setMenuCmdHandler(mainMenuHdlr);


  MenuItem* mainMenuItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuItem->setCmd("g");
  mainMenuItem->setDesc("set status of GPIO <g,pinNum,status> e.g. <g,13,1>");
  mainMenuItem->setItemCmdHandler(mainMenuItemHdlr);
  // mainMenuItem->setConsoleHandler(cHdlr);

  mainMenuDownloadInitItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuDownloadInitItem->setCmd("d");
  // mainMenuDownloadInitItem->setDesc("Download Init File");
  if (LittleFS.exists("/index.html")) {
    mainMenuDownloadInitItem->setDesc("Download Init File (file exists)");
  } else {
    mainMenuDownloadInitItem->setDesc("Download Init File");
  }
  mainMenuDownloadInitItem->setItemCmdHandler(mainMenuDownloadInitItemHdlr);


  wifiMenu = mainMenu->createMenu();
  wifiMenu->setCmd("w");
  if (wifiCtrl.isConnected()) {
    IPAddress ip = WiFi.localIP();
    String ip_str = String(ip[0]) + "." + String(ip[1]) + "." + String(ip[2]) + "." + String(ip[3]);
    String newWiFiDes = "wifi setting (" + ip_str + ")";
    wifiMenu->setDesc(newWiFiDes);
  } else {
    wifiMenu->setDesc("wifi setting");
  }
  wifiMenu->setMenuCmdHandler(wifiMenuHdlr);

  MenuItem* mainMenuFormatFsItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuFormatFsItem->setCmd("f");
  mainMenuFormatFsItem->setDesc("Format LittleFS");
  mainMenuFormatFsItem->setItemCmdHandler(mainMenuFormatFsItemHdlr);


  Menu* meshMenu = mainMenu->createMenu();
  meshMenu->setCmd("m");
  meshMenu->setDesc("mesh setting");
  meshMenu->setMenuCmdHandler(menuMenuHdlr);

  MenuItem* mainMenuRebootItem = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  mainMenuRebootItem->setCmd("r");
  mainMenuRebootItem->setDesc("Reboot");
  mainMenuRebootItem->setItemCmdHandler(mainMenuRebootItemHdlr);


  MenuItem* wifiConfigItem = wifiMenu->createMenuItem(MenuItemType::MENU_ITEM);
  wifiConfigItem->setCmd("c");
  wifiConfigItem->setDesc("set SSID and password <c, ssid, password>");
  wifiConfigItem->setItemCmdHandler(wifiConfigItemHdlr);


  MenuItem* wifiReturnItem = wifiMenu->createMenuItem(MenuItemType::MENU_ITEM_RETURN);
  wifiReturnItem->setCmd("x");
  wifiReturnItem->setDesc("return");
  wifiReturnItem->setItemCmdHandler(wifiReturnItemHdlr);

  MenuItem* bridgeConfigItem = meshMenu->createMenuItem(MenuItemType::MENU_ITEM);
  bridgeConfigItem->setCmd("b");
  bridgeConfigItem->setDesc("set as bridge of mesh network <b, mesh_id, mesh_pass, router_ssid, router_pass, port>");
  bridgeConfigItem->setItemCmdHandler(bridgeConfigItemHdlr);

  MenuItem* getNodeListItem = meshMenu->createMenuItem(MenuItemType::MENU_ITEM);
  getNodeListItem->setCmd("n");
  getNodeListItem->setDesc("get list of connected nodes");
  getNodeListItem->setItemCmdHandler(getNodeListItemHdlr);


  MenuItem* meshConfigItem = meshMenu->createMenuItem(MenuItemType::MENU_ITEM);
  meshConfigItem->setCmd("c");
  meshConfigItem->setDesc("set as regular node <c, meshID, password>");
  meshConfigItem->setItemCmdHandler(meshConfigItemHdlr);

  MenuItem* connectNodeItem = meshMenu->createMenuItem(MenuItemType::MENU_ITEM);
  connectNodeItem->setCmd("t");
  connectNodeItem->setDesc("connect to node <t, nodeID>");
  connectNodeItem->setItemCmdHandler(connectNodeItemHdlr);

  MenuItem* disconnectNodeItem = meshMenu->createMenuItem(MenuItemType::MENU_ITEM);
  disconnectNodeItem->setCmd("d");
  disconnectNodeItem->setDesc("disconnet current node");
  disconnectNodeItem->setItemCmdHandler(disconnectNodeItemHdlr);


  MenuItem* meshReturnItem = meshMenu->createMenuItem(MenuItemType::MENU_ITEM_RETURN);
  meshReturnItem->setCmd("x");
  meshReturnItem->setDesc("return");
  meshReturnItem->setItemCmdHandler(meshReturnItemHdlr);

  menuCtrl.printMenu();

  menuCtrl.enableScheduler(0, 10, nullptr);

  awsCtrl.onHTTP("/", HTTPMethod_GET, redirectIndex);

  // awsCtrl.serveStaticFile("/index.html", LittleFS, "/index.html");
  awsCtrl.onHTTP("/index.html", HTTPMethod_GET, [](AsyncWebServerRequest* request) {
    // Optional: Check if file exists first to handle errors gracefully
    if (LittleFS.exists("/index.html")) {
      request->send(LittleFS, "/index.html", "text/html");
    } else {
      request->send(404, "text/plain", "File not found yet");
    }
  });

  awsCtrl.beginWithWS("/ws", onWsEvent);
}

void loop() {
  if (isPainlessMeshInit) {
    mesh.update();
  }
}




// Function to recover <script> and </script> by replacing placeholders
bool recoverScriptTags(const char* sourcePath, const char* destPath) {
  File source = LittleFS.open(sourcePath, FILE_READ);
  if (!source) {
    Serial.println("Failed to open source file for reading");
    return false;
  }

  String content = source.readString();
  source.close();

  // Replace all occurrences of the placeholders
  content.replace("??123??", "<script>");
  content.replace("??321??", "</script>");

  // Write the recovered content to the destination file
  File dest = LittleFS.open(destPath, FILE_WRITE);
  if (!dest) {
    Serial.println("Failed to open destination file for writing");
    return false;
  }

  if (dest.print(content)) {
    dest.close();
    return true;
  } else {
    Serial.println("Failed to write recovered content");
    dest.close();
    return false;
  }
}

void saveWiFiCredential(String ssid, String pass) {
  File file = LittleFS.open("/wifi.json", "w");
  JsonDocument doc;
  doc["ssid"] = ssid;
  doc["password"] = pass;
  serializeJson(doc, file);
  file.close();
}