#include "IO_Control.h"

MenuControl menuCtrl(&Serial);

uint32_t cHdlrPreviousMillis = 0;

bool cHldrJustCalled = false;

uint32_t cHdlrStartTime = 0;

err_t mainMenuHldr(MenuControl& _menuCtrl, Menu& _menu, String& input) {
  Serial.print("mainMenuHldr received: ");
  Serial.println(input);
  return Control_OK;
}

ulong_t startTimeoutMS=-1;  //  for marking the time when command is processed

//
//  for L0, item 0
//  type = MenuItem
//  input processed by L0_0_CmdProcessor
//  consoleHandler by L0_0_ConsoleHdlr, which execute a timeout function for number of times specified by the command
//  
int L0_0_N=0;
int L0_0_T=500;

err_t L0_0_CmdProcessor(MenuControl& _menuCtrl, MenuItem& _menuItem, String& _input) 
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl

  //  command:
  //  p,<N>     - repeat for N times, deltaT = 500ms
  //  p,<N>,<T> - repeat for N times, deltaT = T

  int l0=_input.indexOf(",");
  if (l0==-1)
  { //  no additional parameters
    _menuItem.setLastErrMsg("command should have one parameter, e.g. p,10 or p,10,1000");
    return MenuControl_CmdError;
  } else
  { int l1=_input.indexOf(",",l0+1);
    if (l1==-1)
    { //  only one parameter: p,<N>
      L0_0_T=500;
      L0_0_N= _input.substring(l0+1).toInt();
    } else
    { //  hase two parameters
      L0_0_N= _input.substring(l0+1,l1).toInt();
      L0_0_T= _input.substring(l1+1).toInt();
    }
  }
  startTimeoutMS = _menuCtrl.getUpdateTime();

  _menuCtrl.getStream().print("Input for L0_0 received : print for ");
  _menuCtrl.getStream().print(L0_0_N);
  _menuCtrl.getStream().print(" times and deltaT=");
  _menuCtrl.getStream().print(L0_0_T);
  _menuCtrl.getStream().println(" ms");

  if (L0_0_N>0)
  { L0_0_N--;
    _menuCtrl.setTimeoutByRelTime(0, printSomething,L0_0_T);
  }
  return Control_OK;
}

//  timeout event handler
DeclareHandler(printSomething, _ctrl, MenuControl, {
  Serial.print("printSomething is invoked, at t=");
  Serial.print(_ctrl.getUpdateTime());
  Serial.print(" originally started timeout at t=");
  Serial.println(startTimeoutMS);

  if (L0_0_N>0)
  { L0_0_N--;
    _ctrl.setTimeoutByRelTime(0, printSomething,L0_0_T);
  }
});

bool L0_0_ConsoleHdlr(MenuControl& _menuCtrl,MenuItem& _menuItem,String& _input)
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl
  if (_menuCtrl.isTimeoutActive(0))
    return true;
  else
    return false;
}

//
//  for L0, item 1
//  type = MenuItem
//  input processed by L0_1_CmdProcessor
//  no consoleHandler 
//
err_t L0_1_CmdProcessor(MenuControl& _menuCtrl, MenuItem& _menuItem, String& _input) 
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl

  startTimeoutMS = _menuCtrl.getUpdateTime();

  _menuCtrl.getStream().print("Input for L0_1 received : current time = ");
  _menuCtrl.getStream().print(startTimeoutMS);
  _menuCtrl.getStream().println(" ms from reset");

  return Control_OK;
}

//
//  for L0, item 2
//  type = Menu
//  input processed by L0_2_CmdProcessor, which start a timeout of 3seconds
//  consoleHandler by L0_2_ConsoleHdlr, which wait till timeout of 3seconds before return false
//
err_t L0_2_CmdProcessor(MenuControl& _menuCtrl, Menu& _menu, String& _input) 
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menu - Menu associated with this processor
  //  _input - input from Stream of MenuControl

  //  no additional parameter for the command
  startTimeoutMS = _menuCtrl.getUpdateTime();

  _menuCtrl.getStream().println("Input for L0_2 received; wait for 3 sec to go to the menu");
  _menuCtrl.setTimeoutByRelTime(0, printSomething,3000);

  return Control_OK;
}

bool L0_2_ConsoleHdlr(MenuControl& _menuCtrl,Menu& _menu,String& _input)
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl
  if (_menuCtrl.isTimeoutActive(0))
    return true;
  else
    return false;
}

//
//  for L1, item 0
//
bool msgPrinted=true;

err_t L1_0_CmdProcessor(MenuControl& _menuCtrl, MenuItem& _menuItem, String& _input) 
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl

  //  no additional parameter for the command
  startTimeoutMS = _menuCtrl.getUpdateTime();

  _menuCtrl.getStream().println("Input for L1_0 received");
  msgPrinted=false;

  return Control_OK;
}

bool L1_0_ConsoleHdlr(MenuControl& _menuCtrl,MenuItem& _menuItem,String& _input)
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl
  if (_input.equals("c"))
    return false;
  else
  { if (!_input.isEmpty())
      msgPrinted=false;
  }
    
  if (!msgPrinted)
  { _menuCtrl.getStream().println("enter 'c' to continue ...");
    msgPrinted=true;
  }
  return true;
}

//
//  for L1, item 1
//
err_t L1_1_CmdProcessor(MenuControl& _menuCtrl, MenuItem& _menuItem, String& _input) 
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl

  //  no additional parameter for the command
  startTimeoutMS = _menuCtrl.getUpdateTime();

  _menuCtrl.getStream().println("Input for L1_1 received; wait for 3 sec to go to parent menu");
  _menuCtrl.setTimeoutByRelTime(0, printSomething,3000);

  return Control_OK;
}

bool L1_1_ConsoleHdlr(MenuControl& _menuCtrl,MenuItem& _menuItem,String& _input)
{ //  _menuCtrl - MenuControl which contains this MenuItem
  //  _menuItem - MenuItem associated with this processor
  //  _input - input from Stream of MenuControl
  if (_menuCtrl.isTimeoutActive(0))
    return true;
  else
    return false;
}

void setup() {

  Serial.begin(115200);

  IO_Control.begin();

  //String mainMenuDesc = "Main Menu";

  //  setup main menu (L0)
  Menu* mainMenu = menuCtrl.getMainMenu();
  mainMenu->setCmd("main");
  //mainMenu->setDesc(mainMenuDesc);
  mainMenu->setDesc("Main Menu (L0)");
  // mainMenu->setMenuCmdHandler(mainMenuHldr);

  //  setup menu items under L0

  //  1st item - a MenuItem
  MenuItem* L0_0 = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  L0_0->setCmd("p");
  L0_0->setDesc("Print several times in console handler (p,<N> or p,<N>,<T>)");
  L0_0->setItemCmdHandler(L0_0_CmdProcessor);
  L0_0->setItemConsoleHandler(L0_0_ConsoleHdlr);

  //  2nd item - a MenuItem
  MenuItem* L0_1 = mainMenu->createMenuItem(MenuItemType::MENU_ITEM);
  L0_1->setCmd("d");
  L0_1->setDesc("Display current time");
  L0_1->setItemCmdHandler(L0_1_CmdProcessor);
  //  without ConsoleHandler, which means print menu immediately after command is processed by L0_1_CmdProcessor

  //  2nd item - a Menu (L1)
  Menu* L0_2 = mainMenu->createMenu();
  L0_2->setCmd("L1");
  L0_2->setDesc("Menu (L1)");
  L0_2->setMenuCmdHandler(L0_2_CmdProcessor);
  L0_2->setMenuConsoleHandler(L0_2_ConsoleHdlr);


  //  setup menu items under L1

  //  1st item - a MenuItem
  MenuItem* L1_0 = L0_2->createMenuItem(MenuItemType::MENU_ITEM);
  L1_0->setCmd("A");
  L1_0->setDesc("About this example");
  L1_0->setItemCmdHandler(L1_0_CmdProcessor);
  L1_0->setItemConsoleHandler(L1_0_ConsoleHdlr);

  //  2nd item - a MenuItem
  MenuItem* L1_1 = L0_2->createMenuItem(MenuItemType::MENU_ITEM_RETURN);
  L1_1->setCmd("R");
  L1_1->setDesc("Return to Main Menu (L0)");
  L1_1->setItemCmdHandler(L1_1_CmdProcessor);
  L1_1->setItemConsoleHandler(L1_1_ConsoleHdlr);

  menuCtrl.printMenu();

  menuCtrl.enableScheduler(0, 1, nullptr);
}

void loop() {
}