#define USE_DHTControl

#include "IO_Control.h"

DHTControl dhtCtrl;


DeclareHandler(dhtCtrlHandler, _ctrl, DHTControl, {
  Serial.print(F("Humidity: "));
  Serial.print(_ctrl.getHumidity());
  Serial.print(F("%  Temperature: "));
  Serial.print(_ctrl.getTemperature_Celsius());
  Serial.print(F("°C "));
  Serial.print(_ctrl.getTemperature_Fahrenheit());
  Serial.print(F("°F"));
  Serial.println();
});

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  IO_Control.begin();

  err_t err;

  err = dhtCtrl.init(DHT11, 0);

  if (err) {
    Serial.print("Error happened when init dhtCtrl: ");
    Serial.println(err);
  }


  dhtCtrl.enableScheduler(0, 2000, dhtCtrlHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
