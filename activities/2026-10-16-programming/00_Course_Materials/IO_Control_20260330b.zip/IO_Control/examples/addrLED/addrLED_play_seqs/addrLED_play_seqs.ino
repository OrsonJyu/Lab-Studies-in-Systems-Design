//
//  for demonstration how to control playback of sequences:
//    playback with playid_1 in indices in target_play1 (0,1,66,67) with the play1_seq1 and play1_seq2 alternatively
//    playback with playid_2 in indices in target_play2 (2,65) with play2_seq1 when the 2nd command in the sequence in playid_1 is started
//    playback with playid_3 in indices in target_play3 (3,64) with play3_seq1, for checking whether the playback action is sync with playid_1
//
//    t     playid_1(0,1,66,67)         playid_2(2,65)                    playid_3(3,64)
//    2000  yellow (play1_seq1)         black                             orange, 0% saturation,100% brightness (play3_seq1)
//    4000  yellow to blue              black                             orange,100% to 50% brightness and 0 to 100% saturation
//    6000  blue to green               black                             from orange to red along color wheel, with 50% brightness
//    8000  green to black              magenta,cyan,each 1s (play2_seq1) red, from 50% to 0% brightness
//   10000  black to green (play1_seq2) blue,red,each 1s                  orange,100% brightness (play3_seq1)
//   12000  green to blue               black                             orange,100% to 50% brightness
//   14000  blue to yellow              black                             from orange to red along color wheel, with 50% brightness
//   16000  yellow                      magenta,cyan,each 1s (play2_seq1) red, from 50% to 0% brightness
//   18000  yellow (play1_seq1)         blue,red,each 1s                  orange,100% brightness (play3_seq1)
//   .... 
//
//    board: Luatos ESP32C3 board
//    circuit:
//      IO05 - DIN of WS2812 strip (with at least 4 LEDs)
//      5V - 5V of WS2812 strip
//      GND - GND of WS2812 strip
//

#define USE_AddrLEDControl 
#include <IO_Control.h>

AddrLEDControl addrledCtrl;
AddrLEDSequence play1_seq1,play1_seq2;
AddrLEDSequence play2_seq1;
AddrLEDSequence play3_seq1;
std::vector<int> target_play1;
std::vector<int> target_play2;
std::vector<int> target_play3;
int playid_1;
int playid_2;
int playid_3;
int playid_1_state=1; //  indicate which sequence is currently playing - =1 for play1_seq2, =2 for play1_seq2
int playid_1_count=0;

DeclareHandler(addrledHandler,_ctrl,AddrLEDControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("IOControl - SchedulerTimerEvent");

  if (_ctrl.isAllSeqStarted())
  { int id=_ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - AllSeqStarted; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  } 

  if (_ctrl.isOneSeqStarted()){
    int id=_ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - OneSeqStarted; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  }  
  if (_ctrl.isOneSeqNewCmdStarted()){ 
    int id=_ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - OneSeqNewCmdStarted; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.print(id);
    Serial.print(" next command index=");
    Serial.println(_ctrl.getNextCommandIndex(id));

    if (_ctrl.getNextCommandIndex(id)==3)
    { //  the 3rd command in the sequence has just been started
      //  hence start the sequence on target_play2
      playid_2 = addrledCtrl.playRelTime(target_play2,play2_seq1,0,1);
    }
  }  
  // if (_ctrl.isOneSeqPaused(_status))
  //   Serial.println("ServoControl - OneSeqPaused");
  if (_ctrl.isOneSeqEnded()){
    int id=_ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - OneSeqEnded; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  }

  if (_ctrl.isAllSeqEnded())
  { int id = _ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - AllSeqEnded; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);

    if (id == playid_1)
    { //  end of playback action with playid_1
      //  playid_2 should have ended as well
      Serial.print("Finished playback sequence in target_play1");
      if (playid_1_state==1)
      { //  then play play1_seq2
        playid_1_state = 2;
        int new_id;
        new_id=_ctrl.playRelTime(target_play1,play1_seq2,0,1);  //  this should have no error, and index == 0
        if (new_id>=0)
        { Serial.print("start playing play1_seq2 in target_play1, time=");
          Serial.print(_ctrl.handlerCurrentMillis);
          Serial.print(" index=");
          Serial.println(new_id);
          playid_1 = new_id; //  allow playback action to be restarted after this one ends
        } else
        { Serial.println("fail to start playing play1_seq2 in target_play1");
        }
      } else
      { //  then play play1_seq1
        playid_1_state = 1;
        int index;
        index=_ctrl.playRelTime(target_play1,play1_seq1,0,1);  //  this should have no error, and index == 0
        if (index>=0)
        { Serial.print("start playing play1_seq1 in target_play1, time=");
          Serial.print(_ctrl.handlerCurrentMillis);
          Serial.print(" index=");
          Serial.println(index);
          playid_1 = index; //  allow playback action to be restarted after this one ends
        } else
        { Serial.println("fail to start playing play1_seq1 in target_play1");
        }
      } 
    }
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  //err_t err=addrledCtrl.init(19,4);
  err_t err=addrledCtrl.init(5,68);
  if (err)
  { Serial.print("Fail to initialize addrledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  //  play1_seq1 - total duration = 8000ms
  play1_seq1.addSetRGB(2000,255,255,0);                 //  yellow, for 2s
  play1_seq1.addInterpolateRGB(2000,255,255,0,0,0,255); //  transit from yellow to blue (in RGB), in 2s
  play1_seq1.addInterpolateRGB(2000,0,0,255,0,255,0);   //  transit from blue to green (in RGB), in 2s
  play1_seq1.addInterpolateRGB(2000,0,255,0,0,0,0);     //  transit from green to black (in RGB), in 2s

  //  play1_seq2 - reverse of play1_seq1
  play1_seq2.addInterpolateRGB(2000,0,0,0,0,255,0);     //  transit from black to green (in RGB), in 2s
  play1_seq2.addInterpolateRGB(2000,0,255,0,0,0,255);   //  transit from green to blue (in RGB), in 2s)
  play1_seq2.addInterpolateRGB(2000,0,0,255,255,255,0); //  transit from blue to yellow (in RGB), in 2s
  play1_seq2.addSetRGB(2000,255,255,0);                 //  yellow, for 2s

  //  play2_seq1 - total duration = 2010ms
  play2_seq1.addSetRGB(1000,255,0,255);    //  magenta, for 1s
  play2_seq1.addSetRGB(1000,0,255,255);    //  cyan, for 1s
  play2_seq1.addSetRGB(1000,0,0,255);      //  blue, for 1s
  play2_seq1.addSetRGB(1000,255,0,0);      //  red, for 1s
  play2_seq1.addSetRGB(10,0,0,0);         //  turn off, for 10ms 

  //  play3_seq1 - total duration = 8000ms
  play3_seq1.addSetHSV(2000,30,0,100);                    //  orange with 0 saturation (ie white), full brightness, for 1s
  play3_seq1.addInterpolateHSV(2000,30,0,100,30,100,50);  //  orange, from full to 50% brightness, and 0 to 100% saturation, for 2s
  play3_seq1.addInterpolateHSV(2000,30,100,50,360,0,50);  //  from orange to red along color wheel, with 50% brightness, for 2s
  play3_seq1.addInterpolateHSV(2000,360,0,50,360,0,0);    //  red, from 50% to 0% brightness, for 2s

  //  use LED at indices 0,1,66,67
  target_play1.clear();
  target_play1.push_back(0);
  target_play1.push_back(1);
  target_play1.push_back(66);
  target_play1.push_back(67);

  //  use LED at indices 2,65
  target_play2.clear();
  target_play2.push_back(2);
  target_play2.push_back(65);

  //  use LED at indices 3,64
  target_play3.clear();
  target_play3.push_back(3);
  target_play3.push_back(64);

  addrledCtrl.clearLEDs();

  playid_1 = addrledCtrl.playRelTime(target_play1,play1_seq1,2000,1);
  playid_1_state=1; //  use play1_seq1 first, and then play1_seq2, and repeat
  playid_1_count=0;

  playid_3 = addrledCtrl.playRelTime(target_play3,play3_seq1,2000,20);

  addrledCtrl.enableScheduler(1000, 1, addrledHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
