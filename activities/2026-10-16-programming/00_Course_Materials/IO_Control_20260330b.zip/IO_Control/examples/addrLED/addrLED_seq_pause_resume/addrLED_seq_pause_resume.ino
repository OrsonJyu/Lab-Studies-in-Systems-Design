//
//  for demonstrating pause and resume of playback action
//    play sequence seq1 on indices in target_seq1 (0), with ID = playid_1
//    play sequence seq2 on indices in target_seq2 (1), with ID = playid_2; playid_2 will be paused at start of 2nd command of seq2, and then resume when playid_1 ends
//
//    t     led#0   Led#1
//    2000  red     magenta
//    3000  green   blue
//    4000  blue    blue (paused)
//    5000  magenta blue (paused)
//    6000  red     blue (paused)
//    7000  green   blue (paused)
//    8000  blue    blue (paused)
//    9000  magenta blue (paused)
//   10000  magenta green (resumed)
//   11000  magenta red
//
//    board: Luatos ESP32C3 board
//    circuit:
//      IO05 - DIN of WS2812 strip (with at least 2 LEDs)
//      5V - 5V of WS2812 strip
//      GND - GND of WS2812 strip
//

#define USE_AddrLEDControl
#include <IO_Control.h>

AddrLEDControl addrledCtrl;
AddrLEDSequence seq1;
AddrLEDSequence seq2;

std::vector<int> target_seq1;
std::vector<int> target_seq2;

int playid_1;
int playid_2;


DeclareHandler(addrledHandler, _ctrl, AddrLEDControl, {
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("IOControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
  { int id=_ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - AllSeqStarted; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  }

  if (_ctrl.isAllSeqEnded())
  { int id=_ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - AllSeqEnded; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  }

  if (_ctrl.isOneSeqStarted()) {
    int id=_ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - OneSeqStarted; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  }
  if (_ctrl.isOneSeqNewCmdStarted()) {
    int id = _ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - OneSeqNewCmdStarted; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
    
    if (id == playid_2) {
      if (_ctrl.getNextCommandIndex(id) == 1) {
          //  pause when 2nd command in the sequence is going to execute
          //  hence, the playback action will be paused AFTER compiete execution of 2nd command
          _ctrl.pauseBeforeNextCommand(id);
      }
    }
  }
  if (_ctrl.isOneSeqPaused()) {
    int id = _ctrl.getCurrentPlayID();
    Serial.print("ServoControl - OneSeqPaused; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.print(id);
    Serial.print(" next command index=");
    Serial.println(_ctrl.getNextCommandIndex(id));
  }

  if (_ctrl.isOneSeqEnded()) {
    int id = _ctrl.getCurrentPlayID();
    Serial.print("AddrLEDControl - OneSeqEnded; t=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  }

  if (_ctrl.isAllSeqStarted()) {
    int id = _ctrl.getCurrentPlayID();
    Serial.print("start playing sequence, time=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
  }
  if (_ctrl.isAllSeqEnded()) {
    int id = _ctrl.getCurrentPlayID();
    Serial.print("end playing sequence, time=");
    Serial.print(_ctrl.handlerCurrentMillis);
    Serial.print(" playID=");
    Serial.println(id);
    if (id == playid_1) {
      _ctrl.resume(playid_2);
    }
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  //err_t err=addrledCtrl.init(5,4);
  err_t err = addrledCtrl.init(5, 2);
  if (err) {
    Serial.print("Fail to initialize addrledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  //  seq1 - total duration = 7000ms
  seq1.addSetRGB(1000, 255, 0, 0);    //  red, for 1s
  seq1.addSetRGB(1000, 0, 255, 0);    //  green, for 1s
  seq1.addSetRGB(1000, 0, 0, 255);    //  blue, for 1s
  seq1.addSetRGB(1000, 255, 0, 255);  //  magenta, for 1s

  //  seq2 - total duration = 1500ms
  seq2.addSetRGB(1000, 255, 0, 255);  //  magenta, for 1s
  seq2.addSetRGB(1000, 0, 0, 255);    //  blue, for 1s
  seq2.addSetRGB(1000, 0, 255, 0);    //  green, for 1s
  seq2.addSetRGB(1000, 255, 0, 0);    //  red, for 1s

  target_seq1.clear();
  target_seq1.push_back(0);

  target_seq2.clear();
  target_seq2.push_back(1);

  addrledCtrl.clearLEDs();
  playid_1 = addrledCtrl.playRelTime(target_seq1, seq1, 2000, 2);
  playid_2 = addrledCtrl.playRelTime(target_seq2, seq2, 2000, 1);

  addrledCtrl.enableScheduler(1000, 1, addrledHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
