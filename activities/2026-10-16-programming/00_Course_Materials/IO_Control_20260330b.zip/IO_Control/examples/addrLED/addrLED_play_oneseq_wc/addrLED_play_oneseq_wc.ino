//
//  for demonstrating use of various functions to control playback of sequences on different targets, including
//    abortPlay(uint16_t), abortPlay()
//    pauseBeforeNextCommand(uint16_t), resume(uint16_t)
//    clearLEDs()
//    getCurrentPlayID()
//
//    board: Luatos ESP32C3 board
//    circuit:
//      IO05 - DIN of WS2812 strip (with at least 2 LEDs)
//      5V - 5V of WS2812 strip
//      GND - GND of WS2812 strip
//
//  commands:
//  R - turn off all LEDs
//  A - abort all playback of sequences
//  t - display current time (ms)
//  p,<target indices>,<seq>,<rel time>,<n>[,...] 
//    - start playback of <seq> on <target indices> for <n> times starting at <rel time> from current time
//    - <target indices> is space sparated list of indices
//    - return playID for each playback action
//  a,<playID>[,...] 
//    - abort one or more playback actions with given playID
//  u,<playID>[,...] 
//    - pause one or more playback actions with given playID
//  r,<playID>[,..]
//    - resume one or more playback actions with given playID
//
//  examples:
//    p,0 1 2,0,0,10
//        play sequence 0, on leds with indices 0,1,2, starting at current time (0ms delay) and for 10 times
//    p,0 1 2,0,0,10,3 4 5,0,500,10
//        play sequence 0, on leds with indices 0,1,2, starting at current time (0ms delay) and for 10 times
//        play sequence 0, on leds with indices 3,4,5, starting at 500ms after current time, and for 10 times
//    p,0 1 2,0,0,10,1,0,500,10
//        play sequence 0, on leds with indices 0,1,2, starting at current time (0ms delay) and for 10 times
//        2nd playback action will result in error, as index #0 has been used by the first playback action
//

#define DEBUG_SERIAL  // Comment out this line to disable Serial.println statements
#define USE_AddrLEDControl
#include <IO_Control.h>

#define SERIAL_OUT
// comment out the above to reduce delay due to Serial.println

AddrLEDControl addrledCtrl;
const int seqNum=2;
AddrLEDSequence seq[seqNum];

const int LedNum=68;
std::vector<bool> paused; //  for avoiding handler of addrledCtrl to keep printing "paused" every time when handler is called
std::vector<int> playID;

bool processCmd_R(Control& _ctrl,String input)
{ //  command:
  //    R

  if (input.equals("R"))
  { //  clear all LEDs
    //  only when no sequence is playing

    Serial.print("Command: ");
    Serial.println(input);

    if (addrledCtrl.isPlaying())
    { Serial.println("At least one sequence is playing, hence cannot clear LEDs");
      return true;
    } else
    { Serial.println("LEDs are cleared");
      addrledCtrl.clearLEDs();
      return true;
    }
  } else
    return false;
}

bool processCmd_A(Control& _ctrl,String input)
{ //  command:
  //    A

  if (input.equals("A"))
  { //  abort all LEDs
    //  only when at least one sequence is playing

    Serial.print("Command: ");
    Serial.println(input);

    if (addrledCtrl.isPlaying())
    { //  at least one sequence is playing, and hence execute abort
      err_t err=addrledCtrl.abortPlay();
      if (err==Control_OK)
        Serial.println("All playback actions are aborted");
      else
      { Serial.print("Error in aborting all playback actions, err=");
        Serial.println(err);
      }
    } else
    { Serial.println("There is no active playback action");
    }
    return true;
  } else
    return false;
}

bool processCmd_p(Control& _ctrl,String input)
{ //  command:
  //    p,<target indices>,<seq>,<rel time>,<n>[,...] 
  
  int i0 = input.indexOf(",");
  if (i0==-1)
  { //  command does not have any comma
    return false;
  }

  if (input.substring(0,i0).equals("p"))
  { //  command: p,...
    input = input.substring(i0+1);

    //  abort all playing sequences
    addrledCtrl.abortPlay();
    addrledCtrl.clearLEDs();
    playID.clear();

    while (1)
    { int i1;   //  index of 1st commma in current set of data [<target indices>,<seq>,<rel time>,<n>]
      int i2;   //  index of 2nd comma in current set of data 
      int i3;   //  index of 3rd comma in current set of data
      int i4;   //  end of string or comma after current set of data 
      
      i1=input.indexOf(',');
      if (i1==-1)
      { Serial.print("command error at position=");
        Serial.println(i1);
        return true;
      }
      i2=input.indexOf(',',i1+1);
      if (i2==-1)
      { Serial.print("command error at position=");
        Serial.println(i2);
        return true;
      }
      i3=input.indexOf(',',i2+1);
      if (i3==-1)
      { Serial.print("command error at position=");
        Serial.println(i3);
        return true;
      }
      i4=input.indexOf(',',i3+1);
      if (i4==-1)
      { //  the current set of data is the last one
        i4 = input.length();
      }
      String target_str = input.substring(0,i1);
      int seq_index = input.substring(i1+1,i2).toInt();
      uint32_t relTime = input.substring(i2+1,i3).toInt();
      int n = input.substring(i3+1,i4).toInt();

      if ((seq_index<0) || (seq_index>=seqNum))
      { Serial.print("Invalid seq_index - value=");
        Serial.println(seq_index);
        return true;
      }

      std::vector<int> target;
      while (target_str.length()!=0)
      { //  remove leading spaces
        if (target_str.charAt(0)==' ')
        { target_str = target_str.substring(1);
          continue;
        }
        int j=target_str.indexOf(' ');
        int index=-1;
        if (j==-1)
        { index = target_str.toInt();
        } else
        { index = target_str.substring(0,j).toInt();
        }
        target.push_back(index);
        if (j==-1)
          break;
        else
          target_str = target_str.substring(j+1);
      }
      Serial.print("target=[");
      for (int i=0;i<target.size();i++)
      { Serial.print(target[i]);
        if (i!=(target.size()-1))
          Serial.print(",");
      }
      Serial.println("]");
      if (!addrledCtrl.checkAvailability(target))
      { Serial.print("target indices not available, cannot proceed");
        return true;
      }

      Serial.print("seq_index=");
      Serial.println(seq_index);
      Serial.print("relTime=");
      Serial.println(relTime);
      Serial.print("n=");
      Serial.println(n);

      int _playid = addrledCtrl.playRelTime(target,seq[seq_index],relTime,n);
      playID.push_back(_playid);
      Serial.print("_playid = ");
      Serial.println(_playid);

      if (i4==input.length())
        break;
      else
        input=input.substring(i4+1);
    }
    return true;
  }
  return false;
}

void str2vint(String _input,std::vector<int>& _vint)
{ //  convert a commma separated list of indices to a vector

  while (1)
  {
    bool isEnd=false;
    int i=_input.indexOf(',');
    if (i==-1)
    { isEnd = true;
      i = _input.length();
    }

    int index = _input.substring(0,i).toInt();
    _vint.push_back(index);
    if (isEnd)
      return;

    _input = _input.substring(i+1);
  }
}

bool processCmd_a(Control& _ctrl,String input)
{ //  command:
  //    a,<playID>[,...] 
  
  int i0 = input.indexOf(",");
  if (i0==-1)
  { //  command does not have any comma
    return false;
  }

  if (input.substring(0,i0).equals("a"))
  { //  command: a,...
    input = input.substring(i0+1);
  
    std::vector<int> indices;
    str2vint(input,indices);
    for (int i=0;i<indices.size();i++)
    { err_t err=addrledCtrl.abortPlay(indices[i]);
      if (err!=Control_OK)
      { Serial.print("error aborting playback sequence with id=");
        Serial.print(indices[i]);
        Serial.print(" error code=");
        Serial.println(err);
      } else
      { Serial.print("abort playback sequence with id=");
        Serial.println(indices[i]);
      }
    }
    return true;
  } else
    return false;
}

bool processCmd_u(Control& _ctrl,String input)
{ //  command:
  //    u,<playID>[,...] 

  int i0 = input.indexOf(",");
  if (i0==-1)
  { //  command does not have any comma
    return false;
  }

  if (input.substring(0,i0).equals("u"))
  { //  command: u,...
    input = input.substring(i0+1);  

    std::vector<int> indices;
    str2vint(input,indices);
    for (int i=0;i<indices.size();i++)
    { err_t err=addrledCtrl.pauseBeforeNextCommand(indices[i]);
      if (err!=Control_OK)
      { Serial.print("error pausing playback sequence with id=");
        Serial.print(indices[i]);
        Serial.print(" error code=");
        Serial.println(err);
      } else
      { Serial.print("pause playback sequence with id=");
        Serial.println(indices[i]);
      }
    }
    return true;
  } else
    return false;
}

bool processCmd_r(Control& _ctrl,String input)
{ //  command:
  //    r,<playID>[,...] 

  int i0 = input.indexOf(",");
  if (i0==-1)
  { //  command does not have any comma
    return false;
  }

  if (input.substring(0,i0).equals("r"))
  { //  command: u,...
    input = input.substring(i0+1);  
  
    std::vector<int> indices;
    str2vint(input,indices);
    for (int i=0;i<indices.size();i++)
    { err_t err=addrledCtrl.resume(indices[i]);
      if (err!=Control_OK)
      { Serial.print("error resuming playback sequence with id=");
        Serial.print(indices[i]);
        Serial.print(" error code=");
        Serial.println(err);
      } else
      { Serial.print("resume playback sequence with id=");
        Serial.println(indices[i]);
      }
    }
    return true;
  } else
    return false;
}

DeclareHandler(iocontrolHandler, _ctrl, IOControl, {

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');

    if (processCmd_R(_ctrl,input))
      return;
    if (processCmd_A(_ctrl,input))
      return;
    if (processCmd_p(_ctrl,input))
      return;
    if (processCmd_a(_ctrl,input))
      return;
    if (processCmd_u(_ctrl,input))
      return;    
    if (processCmd_r(_ctrl,input))
      return;    

    //  else, unknown command
    Serial.print("unknown command:");
    Serial.println(input);
  }
});


DeclareHandler(addrledHandler, _ctrl, AddrLEDControl, {
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("IOControl - SchedulerTimerEvent");

  if (_ctrl.isAllSeqStarted()){ 
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINTLN("AddrLEDControl - AllSeqStarted");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
    paused[index]=false;
  }

  if (_ctrl.isAllSeqEnded()){ 
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINTLN("AddrLEDControl - AllSeqEnded");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
    paused[index]=false;
  }

  if (_ctrl.isOneSeqStarted()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("AddrLEDControl - OneSeqStarted; time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
    paused[index]=false;
  }
  if (_ctrl.isOneSeqNewCmdStarted()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("AddrLEDControl - OneSeqNewCmdStarted; time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
    paused[index]=false;
  }
  if (_ctrl.isOneSeqPaused()) {
    int index=_ctrl.getCurrentPlayID();
    if (!paused[index])
    { DEBUG_PRINT("AddrLEDControl - OneSeqPaused; time=");
      DEBUG_PRINT(_ctrl.handlerCurrentMillis);
      DEBUG_PRINT(" playID=");
      DEBUG_PRINTLN(index);
      paused[index]=true;
    }
  }

  if (_ctrl.isOneSeqEnded()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("AddrLEDControl - OneSeqEnded; time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
    paused[index]=false;
  }

  if (_ctrl.isAllSeqStarted()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("start playing sequence, time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
    paused[index]=false;
  }
  
  if (_ctrl.isAllSeqEnded()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("end playing sequence, time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
    paused[index]=false;
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");
  Serial.println("addrLED_play_oneseq_wc");

  err_t err = addrledCtrl.init(5,LedNum);
  if (err) {
    Serial.print("Fail to initialize addrledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  addrledCtrl.clearLEDs();
  
  for (int i=0;i<LedNum;i++)
    paused.push_back(false);


  //  seq[0] - total duration = 4000ms
  seq[0].addSetRGB(1000, 255, 0, 0);
  seq[0].addSetRGB(1000, 0, 255, 0);
  seq[0].addSetRGB(1000, 0, 0, 255);
  seq[0].addSetRGB(1000, 255, 0, 255);

  //  seq[1] - total duration = 6000ms
  seq[1].addSetRGB(1500, 255, 0, 0);
  seq[1].addSetRGB(1500, 0, 255, 0);
  seq[1].addSetRGB(1500, 0, 0, 255);
  seq[1].addSetRGB(1500, 255, 0, 255);


  addrledCtrl.enableScheduler(0, 1, addrledHandler);
  IO_Control.enableScheduler(0,1,iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
}
