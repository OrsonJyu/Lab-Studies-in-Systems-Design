//
//  for demonstrating playback of one sequence on two LEDs
//    board: Luatos ESP32C3 board
//    circuit:
//      IO05 - DIN of WS2812 strip (with at least 2 LEDs)
//      5V - 5V of WS2812 strip
//      GND - GND of WS2812 strip
//

#define DEBUG_SERIAL  // Comment out this line to disable Serial.println statements
#define USE_AddrLEDControl
#include <IO_Control.h>

#define SERIAL_OUT
// comment out the above to reduce delay due to Serial.println

AddrLEDControl addrledCtrl;
AddrLEDSequence seq1;
AddrLEDSequence seq2;

std::vector<int> target_play1;
std::vector<int> target_play2;

int playid_1;
int playid_2;

DeclareHandler(addrledHandler, _ctrl, AddrLEDControl, {
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("IOControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted()){ 
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINTLN("AddrLEDControl - AllSeqStarted");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }

  if (_ctrl.isAllSeqEnded()){ 
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINTLN("AddrLEDControl - AllSeqEnded");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }

  if (_ctrl.isOneSeqStarted()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("AddrLEDControl - OneSeqStarted; time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }
  if (_ctrl.isOneSeqNewCmdStarted()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("AddrLEDControl - OneSeqNewCmdStarted; time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }
  if (_ctrl.isOneSeqPaused()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("AddrLEDControl - OneSeqPaused; time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }

  if (_ctrl.isOneSeqEnded()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("AddrLEDControl - OneSeqEnded; time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }

  if (_ctrl.isAllSeqStarted()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("start playing sequence, time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }
  
  if (_ctrl.isAllSeqEnded()) {
    int index=_ctrl.getCurrentPlayID();
    DEBUG_PRINT("end playing sequence, time=");
    DEBUG_PRINT(_ctrl.handlerCurrentMillis);
    DEBUG_PRINT(" playID=");
    DEBUG_PRINTLN(index);
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = addrledCtrl.init(5,4);
  if (err) {
    Serial.print("Fail to initialize addrledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  addrledCtrl.clearLEDs();

  //  seq1 - total duration = 7000ms
  seq1.addSetRGB(1000, 255, 0, 0);
  seq1.addSetRGB(1000, 0, 255, 0);
  seq1.addSetRGB(1000, 0, 0, 255);
  seq1.addSetRGB(1000, 255, 0, 255);

  // setup targets
  target_play1.clear();
  target_play1.push_back(0);

  target_play2.clear();
  target_play2.push_back(1);

  //  according to the order of invoking "playRelTime", handlers will be invoked in the following order:
  //    seq1_id, seq2_id
  playid_1 = addrledCtrl.playRelTime(target_play1, seq1, 4000, 10);
  Serial.println(playid_1);
  playid_2 = addrledCtrl.playRelTime(target_play2, seq1, 5000, 10);
  Serial.println(playid_2);

  addrledCtrl.enableScheduler(3000, 1, addrledHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
}
