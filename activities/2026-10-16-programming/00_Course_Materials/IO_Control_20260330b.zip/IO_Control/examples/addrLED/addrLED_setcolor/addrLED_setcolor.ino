//
//  for demonstrating set color (in RGB and HSV) to groups of LEDs on WS2812 strip, using the following methods:
//    setTimeoutByRelTime
//    setRGB and setHSV
//    
//    board: Luatos ESP32C3 board
//    circuit:
//      IO05 - DIN of WS2812 strip (with at least 4 LEDs)
//      5V - 5V of WS2812 strip
//      GND - GND of WS2812 strip
//

#define USE_AddrLEDControl
#include <IO_Control.h>

AddrLEDControl addrledCtrl;

//  color 1, in RGB
uint8_t color1R=128;
uint8_t color1G=64;
uint8_t color1B=0;

//  color 2, in RGB
uint8_t color2R=0;
uint8_t color2G=0;
uint8_t color2B=128;

//  color 3, in HSV
double color3H=0;
double color3S=50;
double color3V=50;

int counter=0;

DeclareHandler(changeColor,_ctrl,AddrLEDControl,{
  switch (counter)
  { case 0:
    { //  set led #0 to color1
      std::vector<int> target_color1;
      target_color1.push_back(0);
      addrledCtrl.setRGB(target_color1,color1R,color1G,color1B);

      //  set led #1 and #2 to color2
      std::vector<int> target_color2;
      target_color2.push_back(1);
      target_color2.push_back(2);
      addrledCtrl.setRGB(target_color2,color2R,color2G,color2B);

      //  set led #3 to color3
      std::vector<int> target_color3;
      target_color3.push_back(3);
      addrledCtrl.setHSV(target_color3,color3H,color3S,color3V);
      counter++;
      break;
    }
    case 1:
    { //  set led #1 to color1
      std::vector<int> target_color1;
      target_color1.push_back(1);
      addrledCtrl.setRGB(target_color1,color1R,color1G,color1B);

      //  set led #0 and #2 to color2
      std::vector<int> target_color2;
      target_color2.push_back(0);
      target_color2.push_back(2);
      addrledCtrl.setRGB(target_color2,color2R,color2G,color2B);

      //  set led #3 to color3
      std::vector<int> target_color3;
      target_color3.push_back(3);
      addrledCtrl.setHSV(target_color3,color3H,color3S,color3V);
      
      counter++;
      break;
    }
    case 2:
    { //  set led #2 to color1
      std::vector<int> target_color1;
      target_color1.push_back(2);
      addrledCtrl.setRGB(target_color1,color1R,color1G,color1B);

      //  set led #0 and #1 to color2
      std::vector<int> target_color2;
      target_color2.push_back(0);
      target_color2.push_back(1);
      addrledCtrl.setRGB(target_color2,color2R,color2G,color2B);

      //  set led #3 to color3
      std::vector<int> target_color3;
      target_color3.push_back(3);
      addrledCtrl.setHSV(target_color3,color3H,color3S,color3V);
      counter++;
      break;
    }
    case 3:
    { //  set led #3 to color1
      std::vector<int> target_color1;
      target_color1.push_back(3);
      addrledCtrl.setRGB(target_color1,color1R,color1G,color1B);

      //  set led #0 and #1 to color2
      std::vector<int> target_color2;
      target_color2.push_back(0);
      target_color2.push_back(1);
      addrledCtrl.setRGB(target_color2,color2R,color2G,color2B);

      std::vector<int> target_color3;
      target_color3.push_back(3);
      addrledCtrl.setHSV(target_color3,color3H,color3S,color3V);

      counter=0;

      //  change color1
      color1R+=20;
      color1G+=20;

      //  change hue of color3
      color3H+=3.5;
      if (color3H>360)
        color3H=0;
      break;
    }
    default:
      break;
  }
  _ctrl.setTimeoutByRelTime(0,changeColor,250);
})

DeclareHandler(addrLEDHdlr,_ctrl,AddrLEDControl,{
  _ctrl.setTimeoutByRelTime(0,changeColor,250); //  only executed once
})

DeclareHandler(iocontrolHandler,_ioCtrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("IOControl - SchedulerTimerEvent");  
  Serial.print("current time=");
  Serial.println(_ioCtrl.handlerCurrentMillis);
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err=addrledCtrl.init(5,4);
  if (err)
  { Serial.print("Fail to initialize addrledCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  addrledCtrl.enableScheduler(1000,1,addrLEDHdlr,1);
  IO_Control.enableScheduler(1000, 500, iocontrolHandler);  //  just for showing current time
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
