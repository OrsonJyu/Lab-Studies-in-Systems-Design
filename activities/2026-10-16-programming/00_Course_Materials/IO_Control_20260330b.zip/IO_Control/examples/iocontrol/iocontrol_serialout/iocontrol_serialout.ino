//
//  for demonstration use of handler function in IOControl for simple printing on Serial Monitor
//  serve as a minimal example for the library
//    board:
//      Luatos ESP32C3 board
//      ESP32S3 Dev Module
//    circuit:
//      none
//

#include <IO_Control.h>

DeclareHandler(hdlr,_ctrl,IOControl,{ //  declare a handler for scheduler
  //  hdlr - name of the handler function
  //  _ctrl - Control object
  //  IOControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");
  Serial.print("current time=");
  Serial.println(_ctrl.getUpdateTime());
});

void setup() 
{
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0, 100, hdlr);
    //  0 - start time of hdlr
    //  100 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...)
}

void loop() {
  // put your main code here, to run repeatedly:
}
