//
//  For demonstrating how to use methods relating to timeout, including:
//    enableScheduler(start_time,interval,hdlr,max_timer_num)
//    setTimeoutByCount(..)
//    setTimeoutByRelTime(..)
//    setTimeoutByAbsTime(..)
//    isTimeoutActive()
//    stopTimeout()
//
//  board:
//    Luatos ESP32C3 board
//    ESP32S3 Dev Module
//
//  commands:
//  c             - check whether any active timneout event
//  c,<count>     - start timeout by count
//  r,<rel_time>  - start timeout by relative time (in ms)
//  a,<abs_time>  - start timeout by absolute time (in ms)
//  ar,<rel_time> - start timeout by absolute time (in ms), at current time + <rel_time> (<rel_time> can be -ve)
//  t             - get current time (in ms)
//  s             - stop an active timeout event
//
//  examples:
//    c,1000 - timeout by count, with total timeout duration = 1000(count)*1(interval)
//    r,2000 - timeout by rel time, with total timeout duration = 2000ms
//    a,3000 - timeout by abs time, with absolute time when timeout event triggered = 3000ms
//    ar,-1000 - timeout by abs time = current time - 1000 ms
//      

#include <IO_Control.h>

ulong_t startTimeoutMS;
bool hasPrintedPrompt=false;

//  timeout event handler
DeclareHandler(doSomething, _ctrl, IOControl, {
  Serial.print("doSomething is invoked, at t=");
  Serial.print(_ctrl.getUpdateTime());
  Serial.print(" originally started timeout at t=");
  Serial.println(startTimeoutMS);

  hasPrintedPrompt=false;
});

bool processCmd_c(Control& _ctrl, String input)
{   //  command: 
    //    c
    //    c,<count>
    //
    //  return true if input has matching commands
    //  otherwise, return false

    if (input.equals("c"))
    { //  check whether any active timneout event 
      Serial.print("command: ");
      Serial.println(input);

      if (_ctrl.isTimeoutActive(1))
        Serial.println("Timeout event is active");
      else
        Serial.println("No timeout event is active");
      
      return true;
    }
    
    int i0=input.indexOf(',');
    if (i0==-1)
    { //  no comma
      return false;
    }

    if (input.substring(0,i0)=="c")
    { //  handle for c,<count>
      if (_ctrl.isTimeoutActive(1))
      { Serial.println("timeout event is still active, cannot start a new one");
        return true;
      }

      int count = input.substring(i0+1).toInt();
      Serial.print("timeout count=");
      Serial.print(count);
      Serial.print(" t=");
      Serial.print(_ctrl.getUpdateTime());
      Serial.print(" interval=");
      Serial.println(_ctrl.getUpdateInterval());

      err_t err;
      if ((err=_ctrl.setTimeoutByCount(1,doSomething, count))==Control_OK)
      { Serial.print("set timeout event at t=");
        Serial.print(_ctrl.getUpdateTime());
        Serial.print(" with count=");
        Serial.println(count);
        startTimeoutMS=_ctrl.getUpdateTime();
        _ctrl.setTimeoutByRelTime(0,printTimeoutActive,0,true); //  start the timeout event handler to show status of the timeout event with ID=1
      } else
      { Serial.print("error in setTimeoutByCount: error code=");
        Serial.println(err);

        hasPrintedPrompt=false;
      }

      return true;
    }

    return false;
}

bool processCmd_t(Control& _ctrl,String input)
{   //  command:
    //  t
    //
    //  return true if input has matching commands
    //  otherwise, return false
  
    if (input.equals("t"))
    { //  check whether any active timneout event 
      Serial.print("command: ");
      Serial.println(input);

      Serial.print("current time=");
      Serial.println(_ctrl.getUpdateTime());

      hasPrintedPrompt=false;

      return true;
    } else
      return false;
}

bool processCmd_r(Control& _ctrl, String input)
{   //  command: 
    //  r,<rel_time>
    //
    //  return true if input has matching commands
    //  otherwise, return false

    int i0=input.indexOf(',');
    if (i0==-1)
    { //  no comma
      return false;
    }

    if (input.substring(0,i0)=="r")
    { //  command: r,<rel_time>
      Serial.print("command: ");
      Serial.println(input);

      if (i0==-1)
      { Serial.println("command error: missing comma");
        return true;
      }

      if (_ctrl.isTimeoutActive(1))
      { Serial.println("timeout event is still active, cannot start a new one");
        return true;
      }

      int rel_time = input.substring(i0+1).toInt();
      Serial.print("timeout rel_time=");
      Serial.print(rel_time);
      Serial.print(" t=");
      Serial.println(_ctrl.getUpdateTime());

      err_t err;
      if ((err=_ctrl.setTimeoutByRelTime(1,doSomething, rel_time))==Control_OK)
      { Serial.print("set timeout event at t=");
        Serial.print(_ctrl.getUpdateTime());
        Serial.print(" with rel_time=");
        Serial.println(rel_time);
        startTimeoutMS=_ctrl.getUpdateTime();
        _ctrl.setTimeoutByRelTime(0,printTimeoutActive,0,true); //  start the timeout event handler to show status of the timeout event with ID=1
      } else
      { Serial.print("error in setTimeoutByRelTime: error code=");
        Serial.println(err);

        hasPrintedPrompt=false;
      }

      return true;
    } else
      return false;
}

bool processCmd_a(Control& _ctrl, String input)
{   //  command: 
    //  a,<abs_time>
    //
    //  return true if input has matching commands
    //  otherwise, return false

    int i0=input.indexOf(',');
    if (i0==-1)
    { //  no comma
      return false;
    }

    if (input.substring(0,i0)=="a")
    { //  command: a,<abs_time>
      Serial.print("command: ");
      Serial.println(input);

      if (_ctrl.isTimeoutActive(1))
      { Serial.println("timeout event is still active, cannot start a new one");
        return true;
      }

      ulong_t abs_time = input.substring(i0+1).toInt();
      Serial.print("timeout at abs_time=");
      Serial.print(abs_time);
      Serial.print(" t=");
      Serial.println(_ctrl.getUpdateTime());

      err_t err;
      if ((err=_ctrl.setTimeoutByAbsTime(1,doSomething, abs_time))==Control_OK)
      { Serial.print("set timeout event at t=");
        Serial.print(_ctrl.getUpdateTime());
        Serial.print(" with abs_time=");
        Serial.println(abs_time);
        startTimeoutMS=_ctrl.getUpdateTime();
        _ctrl.setTimeoutByRelTime(0,printTimeoutActive,0,true); //  start the timeout event handler to show status of the timeout event with ID=1
      } else
      { Serial.print("error in setTimeoutByAbsTime: error code=");
        Serial.println(err);

        hasPrintedPrompt=false;
      }
      return true;
    } else
      return false;
}

bool processCmd_s(Control& _ctrl, String input)
{   //  command:
    //  s
    //
    //  return true if input has matching commands
    //  otherwise, return false

    if (input.equals("s"))
    { //  command: s
      Serial.print("command: ");
      Serial.println(input);

      err_t err = _ctrl.stopTimeout(1);
      if (err==Control_OK)
      { Serial.println("timeout event stopped successfully");

        hasPrintedPrompt=false;
        return true;
      } else
      { Serial.print("fail to stop timeout event; error=");
        Serial.println(err);

        hasPrintedPrompt=false;
        return true;
      }
    }
    return false;
}

bool processCmd_ar(Control& _ctrl, String input)
{   //  command: 
    //  ar,<rel_time>
    //
    //  return true if input has matching commands
    //  otherwise, return false

    int i0=input.indexOf(',');
    if (i0==-1)
    { //  no comma
      return false;
    }

    if (input.substring(0,i0)=="ar")
    { //  command: ar,<rel_time>
      Serial.print("command: ");
      Serial.println(input);

      if (_ctrl.isTimeoutActive(1))
      { Serial.println("timeout event is still active, cannot start a new one");
        return true;
      }

      int rel_time = input.substring(i0+1).toInt();
      Serial.print("timeout at current time + rel_time=");
      Serial.print(rel_time);
      Serial.print(" t=");
      Serial.println(_ctrl.getUpdateTime());

      ulong_t abs_time = _ctrl.getUpdateTime() + rel_time;
      err_t err;
      if ((err=_ctrl.setTimeoutByAbsTime(1,doSomething, abs_time))==Control_OK)
      { Serial.print("set timeout event at t=");
        Serial.print(_ctrl.getUpdateTime());
        Serial.print(" with abs_time=");
        Serial.println(abs_time);
        startTimeoutMS=_ctrl.getUpdateTime();
        _ctrl.setTimeoutByRelTime(0,printTimeoutActive,0,true); //  start the timeout event handler to show status of the timeout event with ID=1
      } else
      { Serial.print("error in setTimeoutByAbsTime: error code=");
        Serial.println(err);

        hasPrintedPrompt=false;
      }
      return true;
    } else
      return false;
}

DeclareHandler(printTimeoutActive, _ctrl, IOControl, {
  if (_ctrl.isTimeoutActive(1))
  { Serial.print("A timeout event is active at t=");
    Serial.print(_ctrl.getUpdateTime());
    Serial.print(", started at t=");
    Serial.println(startTimeoutMS);
    err_t err=_ctrl.setTimeoutByRelTime(0,printTimeoutActive,500,true); //  continue this timeout event after 0.5s
    if (err!=Control_OK)
      Serial.println(err);
  }  
})


DeclareHandler(iocontrolHandler, _ctrl, IOControl, {
  //Serial.print("iocontrolHandler is invoked, at t=");
  //Serial.println(_ctrl.handlerCurrentMillis);

  if (hasPrintedPrompt==false)
  { Serial.println("\nPls enter command");
    hasPrintedPrompt=true;
  }

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.print("received command: ");
    Serial.println(input);

    if (processCmd_c(_ctrl,input))
      return;
    if (processCmd_t(_ctrl,input))
      return;
    if (processCmd_r(_ctrl,input))
      return;
    if (processCmd_a(_ctrl,input))
      return;
    if (processCmd_s(_ctrl,input))
      return;
    if (processCmd_ar(_ctrl,input))
      return;

    //  else, unknown command
    Serial.print("unknown command:");
    Serial.println(input);
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");
  Serial.println("iocontrol_setTimeout");

  IO_Control.enableScheduler(0, 1, iocontrolHandler,2);
    //  0 - start time of hdlr (ie., as soon as possible )
    //  1 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...) 
    //  2 - maximum no of timeout event = 2

  Serial.print("maximum no of timeout event=");
  Serial.println(IO_Control.getMaxTimeoutEvent());
}

void loop() {
  // put your main code here, to run repeatedly:
}
