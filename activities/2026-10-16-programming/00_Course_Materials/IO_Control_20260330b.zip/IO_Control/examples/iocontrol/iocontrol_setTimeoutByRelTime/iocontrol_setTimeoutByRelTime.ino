//
//  for demonstrating a simple use of timeout event
//  this example demonstrates use of the following methods:
//      setTimeoutByRelTime(..)
//      isTimeoutActive()
//
//    board:  
//      Luatos ESP32C3 board
//      ESP32S3 Dev Module
//    circuit:
//      none
//
#include <IO_Control.h>

DeclareHandler(doSomething,_ctrl,IOControl,{
  Serial.print("doSomething at t=");
  Serial.println(_ctrl.getUpdateTime());
});

DeclareHandler(hdlr,_ctrl,IOControl,{ //  declare a handler for scheduler
  //  hdlr - name of the handler function
  //  _ctrl - Control object
  //  IOControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked
  //

  if (!_ctrl.isTimeoutActive(0))
  { Serial.print("start timeout for doSomething at t=");
    Serial.println(_ctrl.getUpdateTime());
    _ctrl.setTimeoutByRelTime(0,doSomething,2000,true);
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(100, 1, hdlr);
    //  100 - start time of hdlr
    //  1 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...)
}

void loop() {
  // put your main code here, to run repeatedly:
}
