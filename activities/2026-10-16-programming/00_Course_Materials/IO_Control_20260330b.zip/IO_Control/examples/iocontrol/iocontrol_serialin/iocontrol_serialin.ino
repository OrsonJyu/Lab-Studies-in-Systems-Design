//
//  for demonstrating use of Serial Monitor input through handler function of IOControl
//    board:
//      Luatos ESP32C3 board
//      ESP32S3 Dev Module
//
#include <IO_Control.h>

DeclareHandler(hdlr,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");     
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.println(input);
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0, 10, hdlr);
    //  0 - start time of hdlr
    //  10 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...)
}

void loop() {
  // put your main code here, to run repeatedly:
}