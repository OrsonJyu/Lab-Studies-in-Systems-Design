//
//  this is for demonstrating configuration of serial interface with PC, under two situation:
//  (a) USB-CDC (that is, CDC is enabled, and USB signals D- and D+ are connected to IO18 and IO19 respectively)
//        in this case, IO18 and IO19 will be reserved and cannot be used by other Control objects
//        IO_Control.getSerial() will return pointer to Stream object for interfacing with host through IO18 and IO19
//  (b) USB-UART (that is, CDC is disabled, and ESP32C3 board has a USB-UART bridge, and connected to IO20 (RX) and IO21 (TX))
//        in this case, IO18 and IO19 can be used by other Control objects, but IO20 or IO21 can be used depending on the mode in IO_Control.begin()
//        IO_Control.getSerial() will return pointer to Stream object for interfacing with host through IO20 and IO21 according to mode in IO_Control.begin()
//
//    board:  Luatos ESP32C3 board, with or without USB-to-Serial chip
//
//    Note: does not work for ESP32S3 Dev Module, as IO43 and IO44 are connected to USB-to-Serial chip and cannot be reconfigured for other use
//

#include <IO_Control.h>
#include <UARTControl.h>
#include <HWCDCControl.h>

Stream* mySerial=0;

BinOutControl binout0;  //  for UARTControl::pinUART0RX
BinOutControl binout1;  //  for HWCDCControl::pinDNeg 
BinOutControl binout2;  //  for HWCDCControl::pinDPos

int state=LOW;
DeclareHandler(binoutHdlr,_ctrl,BinOutControl,{ //  declare a handler for scheduler
  _ctrl.write(state);
  if (state == LOW)
    state= HIGH;
  else
    state= LOW;
});

DeclareHandler(hdlr,_ctrl,IOControl,{ //  declare a handler for scheduler
  //  hdlr - name of the handler function
  //  _ctrl - Control object
  //  IOControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked
  //

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");
  
  mySerial->print("current time=");
  Serial.println(_ctrl.getUpdateTime());

});

err_t status;

void setup() 
{ 
  // put your setup code here, to run once:
  status=IO_Control.begin(115200UL,UART_8N1,IOControl_UART0Mode_TxOnly); 
            //  other possible modes: IOControl_UART0Mode_RxTx, IOControl_UART0Mode_RxOnly
  
  if (status!=Control_OK)
  { Serial.begin(115200);
    Serial.print("error in IO_Control.begin() - ");
    Serial.println(status);
    return;
  }  
  
  mySerial = IO_Control.getSerial();
  //Serial.println((ulong_t) mySerial);

  mySerial->println("chip started");
  //Serial.println("chip started");

  IO_Control.enableScheduler(0, 100, hdlr);
    //  0 - start time of hdlr
    //  100 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...) 
    
  status=binout0.init(UARTControl::pinUART0RX);
  if (status != Control_OK)
  { mySerial->println("error in binout0.init(UARTControl::pinUART0RX)");
    //Serial.println("error in binout.init(pinUART0RX)");
    return;
  }
  binout0.enableScheduler(0,1000,binoutHdlr);
  
  //  try using IO18 for BinOut
  //  will not succeed if using USB-CDC
  status=binout1.init(HWCDCControl::pinDNeg);
  if (status != Control_OK)
  { mySerial->println("error in binout1.init(HWCDCControl::pinDNeg)");
    //Serial.println("error in binout1.init(HWCDCControl::pinDNeg)");
  } else
  { mySerial->println("binout1.init(HWCDCControl::pinDNeg) succeeded");
    binout1.enableScheduler(0,1000,binoutHdlr);
  }

  //  try using IO19 for BinOut
  //  will not succeed if using USB-CDC
  status=binout2.init(HWCDCControl::pinDPos);
  if (status != Control_OK)
  { mySerial->println("error in binout2.init(HWCDCControl::pinDPos)");
    //Serial.println("error in binout1.init(HWCDCControl::pinDPos)");
  } else
  { mySerial->println("binout2.init(HWCDCControl::pinDPos) succeeded");
    binout2.enableScheduler(0,1000,binoutHdlr);
  }

}

void loop() {
  // put your main code here, to run repeatedly:
}
