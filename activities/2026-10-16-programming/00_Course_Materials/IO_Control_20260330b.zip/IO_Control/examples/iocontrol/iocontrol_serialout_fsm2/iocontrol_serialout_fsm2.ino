//
//  for demonstrating use of finite state machine (FSM) to control sequence of message printing through Serial Monitor
//  this is modified from iocontrol_serialout_fsm1.ino, and with additional logic to allow the message sequence to be printed for a number of times
//    board:
//      Luatos ESP32C3 board
//      ESP32S3 Dev Module
//    circuit:
//      none
//
#include <IO_Control.h>

int state=0;  //  define a variable "state" with initial value of 0
              //  "state" is for indicating which message to print in the sequence of messages printing
int repeatCount=0;  //  variable "repeatCount" is for determine when to end the sequence of messages printing

DeclareHandler(hdlr,_ctrl,IOControl,{ //  declare a handler for scheduler
  //  hdlr - name of the handler function
  //  _ctrl - Control object
  //  IOControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked
  //

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");  
  Serial.print("current time=");
  Serial.println(_ctrl.getUpdateTime());
  Serial.print(" state=");
  Serial.println(state);

  switch (state)
  { case 0:
      Serial.println("hello");
      state=1;
      break;
    case 1:
      Serial.println("world");
      state=2;
      break;
    case 2: 
      Serial.println("!!!");
      repeatCount++;      //  same as "repeatCount = repeatCount+1"
      if (repeatCount<=3)
      { state=0;          //  repeat the sequence in printing "hello", "world", "!!!"
        Serial.print("repeated ");
        Serial.print(repeatCount);
        Serial.println(" times");
      } else
      { state=-1; //  stop the sequence
        Serial.println("no more printing!!!");
        repeatCount = 0;
      }
      break;
    default:
      //  do nothing
      break;
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(100, 1000, hdlr);
    //  100 - start time of hdlr
    //  1000 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...) 
}

void loop() {
  // put your main code here, to run repeatedly:
}
