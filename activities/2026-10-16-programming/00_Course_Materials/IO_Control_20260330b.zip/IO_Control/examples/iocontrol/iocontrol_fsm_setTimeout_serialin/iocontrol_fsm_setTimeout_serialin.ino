//
//  for demonstrating use of timeout in FSM with the following logic:
//    IOControl has two timers (0 and 1)
//    FSM has four states, and with different duration at each state (1000ms, 1500ms, 2000ms, and 2500ms)
//    timer 0 is for controlling timeout of each state of FSM
//    tiemr 1 has timeout of 500ms and for printoug out current state of FSM
//    when user enter "s" through Serial Monitor, the current state will be stopped immediately and move on to the next state
//
//  this example demonstrates use of the following methods:
//      enableScheduler(start_time,interval,hdlr,max_timer_num)
//      setTimeoutByRelTime(..)
//      isTimeoutActive()
//      stopTimeout()
//
//    board:  
//      Luatos ESP32C3 board
//      ESP32S3 Dev Module
//    circuit:
//      none
//
#include <IO_Control.h>

int state=-1;  //  define a variable "state" with initial value of 0
              //  "state" is for indicating which message to print in the sequence of messages printing

DeclareHandler(printCurrentState,_ctrl,IOControl,{
  Serial.print("current state=");
  Serial.print(state);
  Serial.print(" at time t=");
  Serial.println(_ctrl.getUpdateTime());
  _ctrl.setTimeoutByRelTime(1,printCurrentState,500,true);
});

DeclareHandler(setNextState,_ctrl,IOControl,{
  switch (state)
  { case -1:
    case 3:
      state=0;
      _ctrl.setTimeoutByRelTime(0,setNextState,1000,true);
      Serial.print("entering state=");
      Serial.print(state);
      Serial.print(" at t=");
      Serial.print(_ctrl.getUpdateTime());
      Serial.println(", duration = 1000ms");
      break;
    case 0:
      state=1;
      _ctrl.setTimeoutByRelTime(0,setNextState,1500,true);
      Serial.print("entering state=");
      Serial.print(state);
      Serial.print(" at t=");
      Serial.print(_ctrl.getUpdateTime());
      Serial.println(", duration = 1500ms");
      break;
    case 1:
      state=2;
      _ctrl.setTimeoutByRelTime(0,setNextState,2000,true);
      Serial.print("entering state=");
      Serial.print(state);
      Serial.print(" at t=");
      Serial.print(_ctrl.getUpdateTime());
      Serial.println(", duration = 2000ms");
      break;
    case 2:
      state=3;
      _ctrl.setTimeoutByRelTime(0,setNextState,2500,true);
      Serial.print("entering state=");
      Serial.print(state);
      Serial.print(" at t=");
      Serial.print(_ctrl.getUpdateTime());
      Serial.println(", duration = 2500ms");
      break;
  }
});

DeclareHandler(hdlr,_ctrl,IOControl,{ //  declare a handler for scheduler
  //  hdlr - name of the handler function
  //  _ctrl - Control object
  //  IOControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked
  //

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");  
  // Serial.print("current time=");
  // Serial.println(_ctrl.getUpdateTime());

  if (!_ctrl.isTimeoutActive(0))
  { _ctrl.setTimeoutByRelTime(0,setNextState,0,true);
  }
  if (!_ctrl.isTimeoutActive(1))
  { _ctrl.setTimeoutByRelTime(1,printCurrentState,0,true);
  }

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    if (input.equals("s"))
    { //  stop current state and move to next
      Serial.print("stop current state=");
      Serial.print(state);
      Serial.print(" at t=");
      Serial.println(_ctrl.getUpdateTime());
      _ctrl.stopTimeout(0);
      _ctrl.setTimeoutByRelTime(0,setNextState,0,true);
    }
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(100, 1, hdlr,2);
    //  100 - start time of hdlr
    //  1 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...)
    //  2 - maximum no of timeout event = 2
}

void loop() {
  // put your main code here, to run repeatedly:
}