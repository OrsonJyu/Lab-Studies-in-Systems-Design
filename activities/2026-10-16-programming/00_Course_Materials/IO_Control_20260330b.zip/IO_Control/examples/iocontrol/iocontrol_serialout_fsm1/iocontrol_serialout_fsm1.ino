//
//  for demonstrating use of finite state machine (FSM) to control sequence of message printing through Serial Monitor
//    board:  
//      Luatos ESP32C3 board
//      ESP32S3 Dev Module
//    circuit:
//      none
//
#include <IO_Control.h>

int state=0;  //  define a variable "state" with initial value of 0
              //  "state" is for indicating which message to print in the sequence of messages printing

DeclareHandler(hdlr,_ctrl,IOControl,{ //  declare a handler for scheduler
  //  hdlr - name of the handler function
  //  _ctrl - Control object
  //  IOControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked
  //

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");  
  Serial.print("current time=");
  Serial.println(_ctrl.getUpdateTime());
  Serial.print(" state=");
  Serial.println(state);

  //  a switch statement for specifying actions for each value of "state"
  //  actions:
  //    print to Serial
  //    set new value of "state" 
  switch (state)
  { case 0:
      Serial.println("hello");
      state=1;
      break;
    case 1:
      Serial.println("world");
      state=2;
      break;
    case 2: 
      Serial.println("!!!");
      state=0;
      break;
    default:
      Serial.println("not possible!!!");
      break;
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(100, 1000, hdlr);
    //  100 - start time of hdlr
    //  1000 - interval between consecutive invocation of hdlr
    //  hdlr - must be declared using DeclareHandler(...)
}

void loop() {
  // put your main code here, to run repeatedly:
}
