//
//  for demonstrating change detection of a GPIO input
//    board:
//      Luatos ESP32C3 board
//    circuit
//      BOOT button at IO09, build-in for Luatos ESP32C3 board 
//

#include <IO_Control.h>

BinInControl binInCtrl0;

DeclareHandler(binInHandler,_ctrl,BinInControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isBinInTriggered())
  { Serial.print("event time=");
    Serial.print(_ctrl.getInterruptTime());
    if (_ctrl.getInterruptState())
      Serial.println(" from LOW to HIGH");
    else
      Serial.println(" from HIGH to LOW");
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  binInCtrl0.init(9,INPUT);

  int button_state = binInCtrl0.read();
  Serial.print("IO09 state=");
  Serial.println(button_state);

  binInCtrl0.enableScheduler(500, 1, binInHandler);
  binInCtrl0.enableInterrupt(CHANGE);
}

void loop() {
  // put your main code here, to run repeatedly:
}
