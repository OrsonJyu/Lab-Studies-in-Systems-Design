//
//  for demonstrating playing of one sequence on a GPIO output
//    board:
//      Luatos ESP32C3 board
//    circuit
//      LED at IO12, build-in for Luatos ESP32C3 board 
//

#include <IO_Control.h>

BinOutControl binOutCtrl0;
BinOutSequence binOutSeq0;

DeclareHandler(binOutHandler,_ctrl,BinOutControl,{ //  declare a handler for scheduler
  //  binOutHandler - name of the handler function
  //  _ctrl - BinOutControl object
  //  BinOutControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked

  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
  { Serial.print("BinOutControl - AllSeqStarted, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isAllSeqEnded())
  { Serial.print("BinOutControl - AllSeqEnded, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isOneSeqStarted())
  { Serial.print("BinOutControl - OneSeqStarted, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isOneSeqNewCmdStarted())
  { Serial.print("BinOutControl - OneSeqNewCmdStarted, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isOneSeqPaused())
  { Serial.print("BinOutControl - OneSeqPaused, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isOneSeqEnded())
  { Serial.print("BinOutControl - OneSeqEnded, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  binOutCtrl0.init(12,LOW);

  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);

  binOutCtrl0.enableScheduler(1000, 1, binOutHandler);
  binOutCtrl0.playRelTime(binOutSeq0, 2000, 2);
}

void loop() {
  // put your main code here, to run repeatedly:
}
