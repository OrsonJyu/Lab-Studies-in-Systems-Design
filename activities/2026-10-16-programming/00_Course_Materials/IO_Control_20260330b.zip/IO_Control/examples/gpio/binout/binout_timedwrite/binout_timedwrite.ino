//
//  for demonstrating use of timeout function in BinOutControl to generate changes in GPIO output
//    logic for controlling FSM is similar to that in iocontrol\iocontrol_fsm_setTimeout_serialin.ino
//    board:
//      Luatos ESP32C3 board
//    circuit
//      LED at IO12, build-in for Luatos ESP32C3 board 
//

#include <IO_Control.h>

BinOutControl binOutCtrl0;
ulong_t onDurationMS = 1000;
ulong_t offDurationMS = 2000;

DeclareHandler(printBinOutState,_ctrl,BinOutControl,{
  Serial.print("current state=");
  Serial.print(_ctrl.read());
  Serial.print(" at t=");
  Serial.println(_ctrl.getUpdateTime());
  _ctrl.setTimeoutByRelTime(1,printBinOutState,500,true);
});

DeclareHandler(changeBinOutState,_ctrl,BinOutControl,{
  if (_ctrl.read()==HIGH)
  { _ctrl.write(LOW);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState,offDurationMS,true);
  } else
  { _ctrl.write(HIGH);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState,onDurationMS,true);
  }
});

DeclareHandler(binOutHandler,_ctrl,BinOutControl,{ //  declare a handler for scheduler
  //  binOutHandler - name of the handler function
  //  _ctrl - BinOutControl object
  //  BinOutControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("BinOutControl - SchedulerTimerEvent"); 
  if (!_ctrl.isTimeoutActive(0))
    _ctrl.setTimeoutByRelTime(0,changeBinOutState,0,true);
  if (!_ctrl.isTimeoutActive(1))
    _ctrl.setTimeoutByRelTime(1,printBinOutState,0,true);

});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  binOutCtrl0.init(12,LOW);

  binOutCtrl0.enableScheduler(0, 1, binOutHandler,2);
}

void loop() {
  // put your main code here, to run repeatedly:
}
