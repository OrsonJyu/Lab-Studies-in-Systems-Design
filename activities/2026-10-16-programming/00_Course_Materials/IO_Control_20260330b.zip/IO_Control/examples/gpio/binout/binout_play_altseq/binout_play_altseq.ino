//
//  for demonstrating playing of two sequences alternatively on a GPIO output
//    board:
//      Luatos ESP32C3 board
//    circuit
//      LED at IO12, build-in for Luatos ESP32C3 board 
//

#include <IO_Control.h>

BinOutControl binOutCtrl0;
BinOutSequence binOutSeq0;
BinOutSequence binOutSeq1;
int binOutState = 0;

DeclareHandler(binOutHandler,_ctrl,BinOutControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
  { Serial.print("BinOutControl - AllSeqStarted, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isAllSeqEnded())
  { Serial.print("BinOutControl - AllSeqEnded, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  // if (_ctrl.isOneSeqStarted())
  // { Serial.print("BinOutControl - OneSeqStarted, at time=");
  //   Serial.println(_currentMillis);
  // }
  // if (_ctrl.isOneSeqNewCmdStarted())
  // { Serial.print("BinOutControl - OneSeqNewCmdStarted, at time=");
  //   Serial.println(_currentMillis);
  // }
  // if (_ctrl.isOneSeqPaused())
  // { Serial.print("BinOutControl - OneSeqPaused, at time=");
  //   Serial.println(_currentMillis);
  // }
  // if (_ctrl.isOneSeqEnded())
  // { Serial.print("BinOutControl - OneSeqEnded, at time=");
  //   Serial.println(_currentMillis);
  // }
    
  if (_ctrl.isAllSeqEnded()) {
    switch (binOutState) {
      case 0:
        Serial.println("play binOutSeq1");
        _ctrl.playRelTime(binOutSeq1, 0, 1);
        binOutState=1;
        break;
      case 1:
        Serial.println("play binOutSeq0");
        _ctrl.playRelTime(binOutSeq0, 0, 1);
        binOutState=0;
        break;
      default:
        break;
    }
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  binOutCtrl0.init(12,LOW);

  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);

  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);
  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);
  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);

  binOutCtrl0.enableScheduler(1000, 1, binOutHandler);
  binOutCtrl0.playRelTime(binOutSeq0, 2000, 1);
}

void loop() {
  // put your main code here, to run repeatedly:
}
