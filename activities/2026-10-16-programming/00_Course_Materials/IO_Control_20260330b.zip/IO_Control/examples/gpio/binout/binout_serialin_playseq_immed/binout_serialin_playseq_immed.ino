//
//  for demonstrating playing of one sequence on a GPIO output BEFORE completing the current sequence (if any) according to input from Serial Montior 
//    board:
//      Luatos ESP32C3 board
//    circuit
//      LED at IO12, build-in for Luatos ESP32C3 board 
//

#include <IO_Control.h>

BinOutControl binOutCtrl0;
BinOutSequence binOutSeq0;
BinOutSequence binOutSeq1;

DeclareHandler(iocontrolHandler,_ctrl,IOControl,{ 
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("IOControl - SchedulerTimerEvent");     
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.print("input:");
    Serial.println(input);

    Serial.print("current time=");
    Serial.println(_ctrl.getUpdateTime());

    if (input.equals("0"))
    { binOutCtrl0.playRelTime(binOutSeq0, 0, 1);
      Serial.println("start playing sequence 0");
      return;
    }
    if (input.equals("1"))
    { binOutCtrl0.playRelTime(binOutSeq1, 0, 1);
      Serial.println("start playing sequence 1");
      return;
    }
    Serial.println("unknown request");

    //  same as above if statements, but using if ... else ... structure
    /*
      if (input.equals("0"))
      { binOutCtrl0.playRelTime(binOutSeq0, 0, 1);
        Serial.println("start playing sequence 0");
      } else
      { if (input.equals("1"))  
        { binOutCtrl0.playRelTime(binOutSeq1, 0, 1);
          Serial.println("start playing sequence 1");
        } else
        { Serial.println("unknown request");
        }
      }
    */

  }
});


DeclareHandler(binOutHandler,_ctrl,BinOutControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
  { Serial.print("BinOutControl - AllSeqStarted, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isAllSeqEnded())
  { Serial.print("BinOutControl - AllSeqEnded, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  // if (_ctrl.isOneSeqStarted())
  // { Serial.print("BinOutControl - OneSeqStarted, at time=");
  //   Serial.println(_currentMillis);
  // }
  // if (_ctrl.isOneSeqNewCmdStarted())
  // { Serial.print("BinOutControl - OneSeqNewCmdStarted, at time=");
  //   Serial.println(_currentMillis);
  // }
  // if (_ctrl.isOneSeqPaused())
  // { Serial.print("BinOutControl - OneSeqPaused, at time=");
  //   Serial.println(_currentMillis);
  // }
  // if (_ctrl.isOneSeqEnded())
  // { Serial.print("BinOutControl - OneSeqEnded, at time=");
  //   Serial.println(_currentMillis);
  // }
    
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0, 100, iocontrolHandler);

  binOutCtrl0.init(12,LOW);

  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);

  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);
  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);
  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);

  binOutCtrl0.enableScheduler(1000, 1, binOutHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
}
