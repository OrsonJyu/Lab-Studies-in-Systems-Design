//
//  for demonstrating use of input from Serial Monitor to control on/off time of GPIO output
//    extended from gpio/binout/binout_timedwrite
//    board:
//      Luatos ESP32C3 board
//    circuit
//      LED at IO12, build-in for Luatos ESP32C3 board 
//
//  input:
//    <number1> - change onDurationMS
//    ,<number2> - change offDurationMS
//    <number1>,<number2> - change onDurationMS (=<number1>) and offDurationMS (=<number2>)
//

#include <IO_Control.h>

BinOutControl binOutCtrl0;
ulong_t onDurationMS = 1000;
ulong_t offDurationMS = 2000;

DeclareHandler(iocontrolHandler,_ctrl,IOControl,{ 
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial.println("IOControl - SchedulerTimerEvent");   

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.print("input command:");
    Serial.println(input);

    Serial.print("current time=");
    Serial.println(_ctrl.getUpdateTime());

    int pos=input.indexOf(',');

    if (pos==-1)
    { //  no comma, assuming user enter one number, and onDurationMS is set to the number
      //  offDurationMS is unchanged

      int val = input.toInt();
      if (val<=0)
      { Serial.println("Error: invalid duration; onDurationMS and offDurationMS unchange");
        return;
      }
      onDurationMS = val;
      Serial.print("Duration for ON=");
      Serial.println(onDurationMS);
      Serial.print("Duration for OFF=");
      Serial.println(offDurationMS);

      return;
    }

    if (pos==0)
    { //  comma at beginning, then no change to onDurationMS and only change offDurationMS
      
      int val = input.substring(1).toInt();
      if (val<=0)
      { Serial.println("Error: invalid duration for offDurationMS; onDurationMS and offDurationMS unchange");
        return;
      }
      offDurationMS = val;

      Serial.print("Duration for ON=");
      Serial.println(onDurationMS);
      Serial.print("Duration for OFF=");
      Serial.println(offDurationMS);

      return;
    }

    if (pos>0)
    { //  at least one comma, assuming the form "<number1>,<number2>"
      if (input.indexOf(',',pos+1) !=-1)
      { //  more than one comma, and hence error 
        Serial.println("Error: more than one comma; onDurationMS and offDurationMS unchange");
        return;
      }
      int _onDurationMS = input.substring(0,pos).toInt();
      int _offDurationMS = input.substring(pos+1).toInt();
      if (_onDurationMS<=0)
      { Serial.print("Error: ON duration <=0 (");
        Serial.print(_onDurationMS);
        Serial.println("); onDurationMS and offDurationMS unchange");
        return;
      }
      if (_offDurationMS<=0)
      { Serial.print("Error: ON duration <= 0 (");
        Serial.print(_offDurationMS);
        Serial.println("); onDurationMS and offDurationMS unchange");
        return;
      }
      onDurationMS = _onDurationMS;
      offDurationMS = _offDurationMS;
      Serial.print("Duration for ON=");
      Serial.println(onDurationMS);
      Serial.print("Duration for OFF=");
      Serial.println(offDurationMS);
    }
  }
});

DeclareHandler(printBinOutState,_ctrl,BinOutControl,{
  Serial.print("current state=");
  Serial.print(_ctrl.read());
  Serial.print(" at t=");
  Serial.println(_ctrl.getUpdateTime());
  _ctrl.setTimeoutByRelTime(1,printBinOutState,500,true);
});

DeclareHandler(changeBinOutState,_ctrl,BinOutControl,{
  if (_ctrl.read()==HIGH)
  { _ctrl.write(LOW);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState,offDurationMS,true);
  } else
  { _ctrl.write(HIGH);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState,onDurationMS,true);
  }
});

DeclareHandler(binOutHandler,_ctrl,BinOutControl,{ //  declare a handler for scheduler
  //  binOutHandler - name of the handler function
  //  _ctrl - BinOutControl object
  //  BinOutControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("BinOutControl - SchedulerTimerEvent"); 
  if (!_ctrl.isTimeoutActive(0))
    _ctrl.setTimeoutByRelTime(0,changeBinOutState,0,true);
  if (!_ctrl.isTimeoutActive(1))
    _ctrl.setTimeoutByRelTime(1,printBinOutState,0,true);

});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0,500,iocontrolHandler);

  binOutCtrl0.init(12,LOW);

  binOutCtrl0.enableScheduler(0, 1, binOutHandler,2);
}

void loop() {
  // put your main code here, to run repeatedly:
}
