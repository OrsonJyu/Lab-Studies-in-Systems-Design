//
//  for demonstrating playing of one sequence on a GPIO output immediately according to input from Serial Montior 
//    board:
//      Luatos ESP32C3 board
//    circuit
//      LED at IO12, build-in for Luatos ESP32C3 board 
//

#include <IO_Control.h>

BinOutControl binOutCtrl0;
BinOutSequence binOutSeq0;
BinOutSequence binOutSeq1;
int nextSeqIndex = -1;

DeclareHandler(iocontrolHandler,_ctrl,IOControl,{ 
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("IOControl - SchedulerTimerEvent");
  
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.print("input:");
    Serial.println(input);

    Serial.print("current time=");
    Serial.println(_ctrl.getUpdateTime());

    if (input.equals("0"))
    { if (binOutCtrl0.isPlaying())
      { nextSeqIndex=0;
        Serial.println("going to play sequence 0 after current one finished");
      } else
      { nextSeqIndex=-1;
        binOutCtrl0.playRelTime(binOutSeq0, 0, 1);
        Serial.println("start playing sequence 0 now");
      }
      return;
    }
    if (input.equals("1"))
    { if (binOutCtrl0.isPlaying())
      { nextSeqIndex=1;
        Serial.println("going to play sequence 1 after current one finished");
      } else
      { nextSeqIndex=-1;
        binOutCtrl0.playRelTime(binOutSeq1, 0, 1);
        Serial.println("start playing sequence 1 now");
      }
      return;
    }
    Serial.println("unknown request");

    //  same as above, but using if ... else ... structure
    /*
      if (input.equals("0"))
      { if (binOutCtrl0.isPlaying())
        { nextSeqIndex=0;
          Serial.println("going to play sequence 0 after current one finished");
        } else
        { nextSeqIndex=-1;
          binOutCtrl0.playRelTime(binOutSeq0, 0, 1);
          Serial.println("start playing sequence 0 now");
        }
      } else
      { if (input.equals("1"))  
        { if (binOutCtrl0.isPlaying())
          { nextSeqIndex=1;
            Serial.println("going to play sequence 1 after current one finished");
          } else
          { nextSeqIndex=-1;
            binOutCtrl0.playRelTime(binOutSeq1, 0, 1);
            Serial.println("start playing sequence 1 now");
          }
        } else
        { Serial.println("unknown request");
        }
      }
    */
  }
});


DeclareHandler(binOutHandler,_ctrl,BinOutControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
  { Serial.print("BinOutControl - AllSeqStarted, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  if (_ctrl.isAllSeqEnded())
  { Serial.print("BinOutControl - AllSeqEnded, at time=");
    Serial.println(_ctrl.getUpdateTime());
  }
  // if (_ctrl.isOneSeqStarted())
  //   Serial.println("BinOutControl - OneSeqStarted");
  // if (_ctrl.isOneSeqNewCmdStarted())
  //   Serial.println("BinOutControl - OneSeqNewCmdStarted");
  // if (_ctrl.isOneSeqPaused())
  //   Serial.println("BinOutControl - OneSeqPaused");
  // if (_ctrl.isOneSeqEnded())
  //   Serial.println("BinOutControl - OneSeqEnded");

  if (_ctrl.isAllSeqEnded())
  { if (nextSeqIndex!=-1)
    { if (nextSeqIndex==0)
        _ctrl.playRelTime(binOutSeq0, 0, 1);
      else if (nextSeqIndex==1)
              _ctrl.playRelTime(binOutSeq1, 0, 1);
      Serial.print("start playing sequence ");
      Serial.print(nextSeqIndex);
      Serial.println(" now");
      nextSeqIndex=-1;
    }
  }
    
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0, 10, iocontrolHandler);

  binOutCtrl0.init(12,LOW);

  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);
  binOutSeq0.addSetState(500, HIGH);
  binOutSeq0.addSetState(500, LOW);

  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);
  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);
  binOutSeq1.addSetState(1000, HIGH);
  binOutSeq1.addSetState(500, LOW);

  binOutCtrl0.enableScheduler(1000, 1, binOutHandler);
  binOutCtrl0.playRelTime(binOutSeq0, 2000, 1);
  Serial.println("start playing sequence 0 now");
}

void loop() {
  // put your main code here, to run repeatedly:
}
