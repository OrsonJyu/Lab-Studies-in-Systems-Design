#define USE_MPR121Control
#define USE_SH1106Control
#define USE_SSD1306Control
#define USE_AddrLEDControl
#include <IO_Control.h>

ADCControl adc0Ctrl;
ADCControl adc1Ctrl;

void adc0CtrlEventHandler(Control& _ctrl) {
  DownCastControl(adcCtrl, ADCControl, _ctrl);

  int val0 = adc0Ctrl.read();
  int val1 = adc1Ctrl.read();

  // Serial.print("adc0=");
  // Serial.print(val0);
  // Serial.print("\tadc1=");
  // Serial.print(val1);

  // Serial.println();
}

BinInControl binIn0Ctrl;
BinInControl binIn1Ctrl;

void binIn0CtrlEventHandler(Control& _ctrl) {
  DownCastControl(binInCtrl, BinInControl, _ctrl);

  if (_ctrl.status & BinInControlEventHandler_BinInTriggered) {
    Serial.print("switch pressed 0, time =");
    Serial.print(binInCtrl.getInterruptTime());
    Serial.print(" state=");
    Serial.println(binInCtrl.getInterruptState());
  }
}

void binIn1CtrlEventHandler(Control& _ctrl) {
  DownCastControl(binInCtrl, BinInControl, _ctrl);

  if (_ctrl.status & BinInControlEventHandler_BinInTriggered) {
    Serial.print("switch pressed 1, time =");
    Serial.print(binInCtrl.getInterruptTime());
    Serial.print(" state=");
    Serial.println(binInCtrl.getInterruptState());
  }
}

I2CMasterControl i2cCtrl;
MPR121Control mpr121Ctrl;

void mpr121CtrlEventHandler(Control& _ctrl) {
  Serial.println("mpr121CtrlEventHandler is called");
  DownCastControl(mpr121Ctrl, MPR121Control, _ctrl);

  if (_ctrl.status & MPR121ControlEventHandler_TouchReleaseEvent) {

    for (uint8_t i = 0; i < 12; i++) {
      if (mpr121Ctrl.touchedTimeMS[i] != 0) {
        //implement touch event here.
        DEBUG_PRINT("touched i=");
        DEBUG_PRINT(i);
        DEBUG_PRINT(" at time=");
        DEBUG_PRINTLN(mpr121Ctrl.touchedTimeMS[i]);
      }

      if (mpr121Ctrl.releasedTimeMS[i] != 0) {
        //implement release event here
        DEBUG_PRINT("released i=");
        DEBUG_PRINT(i);
        DEBUG_PRINT(" at time=");
        DEBUG_PRINTLN(mpr121Ctrl.releasedTimeMS[i]);
      }
    }
  }
}

BinOutControl binOutCtrl0;
BinOutSequence binOutSeq0;
BinOutSequence binOutSeq1;
int binOutState = 0;

void binOutHandler(Control& _ctrl) {
  DownCastControl(binOutCtrl, BinOutControl, _ctrl);

  if (_ctrl.status & BinOutControlEventHandler_AllSeqStarted)
    Serial.println("BinOutControlEventHandler_AllSeqStarted");
  if (_ctrl.status & BinOutControlEventHandler_AllSeqEnded)
    Serial.println("BinOutControlEventHandler_AllSeqEnded");
  if (_ctrl.status & BinOutControlEventHandler_OneSeqStarted)
    Serial.println("BinOutControlEventHandler_OneSeqStarted");
  if (_ctrl.status & BinOutControlEventHandler_OneSeqNewCmdStarted)
    Serial.println("BinOutControlEventHandler_OneSeqNewCmdStarted");
  if (_ctrl.status & BinOutControlEventHandler_OneSeqPaused)
    Serial.println("BinOutControlEventHandler_OneSeqPaused");
  if (_ctrl.status & BinOutControlEventHandler_OneSeqEnded)
    Serial.println("BinOutControlEventHandler_OneSeqEnded");

  if (_ctrl.status & BinOutControlEventHandler_AllSeqEnded) {
    binOutState++;
    switch (binOutState) {
      case 1:
        Serial.println("play binoutSeq1");
        binOutCtrl0.playRelTime(binOutSeq1, 0, 1);
        break;
      case 2:
        Serial.println("play binoutSeq0");
        binOutCtrl0.playRelTime(binOutSeq0, 0, 1);
        break;
      default:
        break;
    }
  }
}


ServoControl servoCtrl;
ServoSequence servoSeq;

PWMControl pwmCtrl;
PWMSequence pwmSeq;

ToneControl toneCtrl0;
ToneSequence toneSeq;

// ToneControl toneCtrl1;





AddrLEDControl addrLedCtrl;
std::vector<int> seqTargets;
AddrLEDSequence seq;
AddrLEDSequence seq2;


SSD1306Control ssd1306Ctrl;
SH1106Control sh1106Ctrl;






void servoCtrlEventHandler(Control& _ctrl) {
  DownCastControl(servoCtrl, ServoControl, _ctrl);
}

void addrLedEventHandler(Control& _ctrl) {
  DownCastControl(addrLedCtrl, AddrLEDControl, _ctrl);
  if (_ctrl.status & AddrLEDControlEventHandler_AllSeqStarted)
    Serial.println("AddrLEDControlEventHandler_AllSeqStarted");
  if (_ctrl.status & AddrLEDControlEventHandler_AllSeqEnded) {
    Serial.println("AddrLEDControlEventHandler_AllSeqEnded");
    //   /*seqTargets.clear();
    //   //seqTargets = {0, 1, 2, 3 ,4, 5, 6, 7};
    //   for (int i = 0; i < 32; i++) {
    //     seqTargets.push_back(i);
    //   }

    //   addrLedCtrl.playRelTime(seqTargets, seq2, 1000, 1);*/
  }
  if (_ctrl.status & AddrLEDControlEventHandler_OneSeqStarted)
    Serial.println("AddrLEDControlEventHandler_OneSeqStarted");
  if (_ctrl.status & AddrLEDControlEventHandler_OneSeqNewCmdStarted) {
    Serial.print("AddrLEDControlEventHandler_OneSeqNewCmdStarted: ");
    Serial.println(_ctrl.handlerCurrentMillis);
  }
  if (_ctrl.status & AddrLEDControlEventHandler_OneSeqPaused)
    Serial.println("AddrLEDControlEventHandler_OneSeqPaused");
  if (_ctrl.status & AddrLEDControlEventHandler_OneSeqEnded)
    Serial.println("AddrLEDControlEventHandler_OneSeqEnded");

  //Serial.print("seqObj index is: ");
  //Serial.println(addrLedCtrl.getCurrentSeqObjIndex());
  //Serial.print("status is: ");
  //Serial.println(_status);
}

// void binInCtrlEventHandler(Control& _ctrl, ulong_t _currentMillis, int _status) {
//   DownCastControl(binInCtrl0, BinInControl, _ctrl, _status);

//   DEBUG_PRINT("binInCtrlEventHandler: event time=");
//   DEBUG_PRINT(_currentMillis);
//   DEBUG_PRINT(" status=");
//   DEBUG_PRINTLN(_status);

//   if (_status & BinInControlEventHandler_BinInTriggered) {  //May be change it to Macro
//     Serial.println("(binInCtrlEventHandler) Interrupt triggered");
//     Serial.print("Event Triggered Time: ");
//     Serial.println(binInCtrl0.getInterruptTime());
//   } else {
//     Serial.println("(binInCtrlEventHandler) Interrupt is not triggered");
//   }
// }







void pwmEventHandler(Control& _ctrl) {
  DownCastControl(pwmCtrl, PWMControl, _ctrl);

  if (_ctrl.status & LedcControlEventHandler_AllSeqStarted)
    Serial.println("LedcControlEventHandler_AllSeqStarted");
  if (_ctrl.status & LedcControlEventHandler_AllSeqEnded)
    Serial.println("LedcControlEventHandler_AllSeqEnded");
  if (_ctrl.status & LedcControlEventHandler_OneSeqStarted)
    Serial.println("LedcControlEventHandler_OneSeqStarted");
  if (_ctrl.status & LedcControlEventHandler_OneSeqNewCmdStarted)
    Serial.println("LedcControlEventHandler_OneSeqNewCmdStarted");
  if (_ctrl.status & LedcControlEventHandler_OneSeqPaused)
    Serial.println("LedcControlEventHandler_OneSeqPaused");
  if (_ctrl.status & LedcControlEventHandler_OneSeqEnded)
    Serial.println("LedcControlEventHandler_OneSeqEnded");
}

void toneEventHandler(Control& _ctrl) {
  DownCastControl(toneCtrl0, ToneControl, _ctrl);

  if (_ctrl.status & LedcControlEventHandler_AllSeqStarted)
    Serial.println("LedcControlEventHandler_AllSeqStarted");
  if (_ctrl.status & LedcControlEventHandler_AllSeqEnded)
    Serial.println("LedcControlEventHandler_AllSeqEnded");
  if (_ctrl.status & LedcControlEventHandler_OneSeqStarted)
    Serial.println("LedcControlEventHandler_OneSeqStarted");
  if (_ctrl.status & LedcControlEventHandler_OneSeqNewCmdStarted)
    Serial.println("LedcControlEventHandler_OneSeqNewCmdStarted");
  if (_ctrl.status & LedcControlEventHandler_OneSeqPaused)
    Serial.println("LedcControlEventHandler_OneSeqPaused");
  if (_ctrl.status & LedcControlEventHandler_OneSeqEnded)
    Serial.println("LedcControlEventHandler_OneSeqEnded");
}




void setup() {
  IO_Control.begin();

  Serial.begin(115200);

  //  ADC at GPIO00 and GPIO01
  err_t err;
  err = adc0Ctrl.init(1, 0, true);
  if (err != 0)
    DEBUG_PRINTLN("error - adc0Ctrl.init()");

  err = adc1Ctrl.init(1, 1, false);
  if (err != 0)
    DEBUG_PRINTLN("error - adc1Ctrl.init()");

  err = adc0Ctrl.enableScheduler(3000, 10, adc0CtrlEventHandler);
  assert(err == Control_OK);

  err = adc1Ctrl.enableScheduler(3000, 10, adc0CtrlEventHandler);
  assert(err == Control_SchedulerNotPermitted);


  //  binary input at GPIO18
  err = binIn0Ctrl.init(18, INPUT_PULLUP);
  if (err != 0)
    DEBUG_PRINTLN("error - binIn0Ctrl.init()");

  err = binIn0Ctrl.enableScheduler(3000, 10, 0);
  assert(err == Control_NullEventHandler);  //  failed due to no handler
  err = binIn0Ctrl.enableInterrupt(CHANGE);
  assert(err == Control_NoScheduler);  //  failed due to scheduler is not enabled

  err = binIn0Ctrl.enableScheduler(3000, 10, binIn0CtrlEventHandler);
  assert(err == Control_OK);  //  err == Control_OK
  err = binIn0Ctrl.enableInterrupt(CHANGE);
  assert(err == Control_OK);  //  err == Control_OK


  //  binary input at GPIO19
  /*err = binIn1Ctrl.init(19, INPUT_PULLUP);
  if (err != 0)
    DEBUG_PRINTLN("error - binIn1Ctrl.init()");
  err = PinMgr.request(binIn1Ctrl);
  if (err != 0)
    DEBUG_PRINTLN("error - PinMgr.request(binIn1Ctrl);");

  binIn1Ctrl.enableScheduler(3000, 10, binIn1CtrlEventHandler);
  binIn1Ctrl.enableInterrupt(FALLING);*/


  //  I2C master, with SCL=6, SDA=10
  err = i2cCtrl.init(1, 6, 10);
  assert(err == I2CMasterControl_InvalidI2CIndex);  //  error; ESP32C3 only support i2cIndex==0

  err = i2cCtrl.init(0, 6, 11);
  assert(err == I2CMasterControl_InvalidSDA);  //  SDA==11 is error, as GPIO11 cannot be used

  err = i2cCtrl.init(0, 6, 10);  //  use i2cNum=0, SCL=6, SDA=10
  assert(err == Control_OK);

  //  to do:
  //    test case: PinMgr.release(i2cCtrl), and then use the IO for other purposes, and then go back to I2C Master

  err = mpr121Ctrl.init(i2cCtrl, 0x5A, 7, 1000, 10, mpr121CtrlEventHandler);


  //Following code is for OLED SSD1306
  /*err = ssd1306Ctrl.init(i2cCtrl, 0x3c, 128, 64, -1);
  err = PinMgr.request(ssd1306Ctrl);
  if (!err) {
    Serial.println("Successfully request ssd1306Ctrl");
    ssd1306Ctrl.getDisplay().display();
    ssd1306Ctrl.getDisplay().display();
    ssd1306Ctrl.getDisplay().clearDisplay();
    ssd1306Ctrl.getDisplay().setTextSize(1);
    ssd1306Ctrl.getDisplay().setTextColor(SH110X_WHITE);
    ssd1306Ctrl.getDisplay().setTextWrap(true);
    ssd1306Ctrl.getDisplay().setCursor(0, 0);
    ssd1306Ctrl.getDisplay().println("Successfully request ssd1306Ctrl");
    ssd1306Ctrl.getDisplay().display();
  } else {
    Serial.println("Fail to request ssd1306Ctrl");
  }*/

  //Following code is for OLED SH1106
  err = sh1106Ctrl.init(i2cCtrl, 0x3c, 128, 64, -1);





  //  BinOutControl

  /*binOutCtrl0.init(5);
  err = PinMgr.request(binOutCtrl0);
  if (!err) {
    binOutSeq0.addCommand(5000, HIGH);
    binOutSeq0.addCommand(1000, LOW);
    binOutSeq0.addCommand(2000, HIGH);
    binOutSeq0.addCommand(1000, LOW);

    binOutCtrl0.enableScheduler(1000, 100, binOutHandler);
    binOutCtrl0.playRelTime(binOutSeq0, 2000, -1);
    //this line will do the same thing as above 2 lines binOutCtrl0.play(binOutSeq0, 2000, -1, 1000, 100, binOutSeqHandler);
  } else {
    Serial.println("Fail to request binOutCtrl0");
  }*/

  pwmCtrl.init(5);



  //init ServoControl instance for pin 7. For timer callback, set the starting time to 10000 and set the interval to 1000
  err = servoCtrl.init(8, true);
  if (err) {  //error
    Serial.println("Failure: Init pin for servo");
  } else {
    servoCtrl.enableScheduler(1000, 100, servoCtrlEventHandler);

    servoSeq.addSetAngle(1000, 30, servoCtrl);
    servoSeq.addSetAngle(1000, 150, servoCtrl);
    servoSeq.addSetAngle(1000, 30, servoCtrl);
    servoSeq.addMoveFromToAngle(2000, 30, 150, servoCtrl);
    servoSeq.addMoveFromToAngle(2000, 150, 30, servoCtrl);
    servoSeq.addSetAngle(1000, 30, servoCtrl);
    servoSeq.addSetAngle(1000, 150, servoCtrl);
    servoSeq.addSetAngle(1000, 30, servoCtrl);
    servoCtrl.playRelTime(servoSeq, 1000, -1);
  }

  // //init ToneControl instance "toneCtrl0" for pin 13
  err = toneCtrl0.init(13, true);
  if (err) {
    Serial.println("Failure: Init pin for tone");
  } else {
    toneCtrl0.enableScheduler(1000, 100, toneEventHandler);
    toneSeq.addInterpolateTone(2000, 4186, 7902, 50, 50);
    toneSeq.addInterpolateTone(2000, 7902, 4186, 50, 50);
    toneCtrl0.playRelTime(toneSeq, 1000, -1);
  }

  // /*binInCtrl0.init(7, INPUT_PULLUP);
  // success = PinMgr.request(binInCtrl0);
  // if (!success) {
  //   Serial.println("Failure: Request pin for BinIn");
  // } else {
  //   binInCtrl0.enableInterrupt(FALLING);
  //   //binInCtrl0.enableScheduler(1000, 1000, binInCtrlEventHandler);  //comment out this line because this pin is used for MPR121
  // }*/

  // i2cCtrl.init(6, 10);
  // success = PinMgr.request(i2cCtrl);
  // if (success) {
  //   Serial.println("i2c is requested successfully");
  // } else {
  //   Serial.println("Fail to request i2c");
  // }

  // mpr121Ctrl.init(i2cCtrl, 0x5A, 7, 1000, 100, mpr121CtrlEventHandler);
  // success = PinMgr.request(mpr121Ctrl);
  // if (success) {
  //   Serial.println("Successfully request mpr121Ctrl");
  // } else {
  //   Serial.println("Fail to request mpr121Ctrl");
  // }

  // //init a PWMControl instance for pin 7. It should be failed because pin 7 has been used by servoCtrl
  // /*pwmCtrl.init(7);
  // success = PinMgr.request(pwmCtrl);
  // if (!success) {
  //   DEBUG_PRINTLN("Failure: Request pin for pwm");
  // } else {
  //   pwmCtrl.setDuty(16000, 0);
  // }


  // //change the pin of pwmCtrl and try to request again. It should be successful
  // pwmCtrl.init(8);
  // success = PinMgr.request(pwmCtrl);
  // if (!success) {
  //   DEBUG_PRINTLN("Failure: Request pin for pwm");
  // } else {
  //   pwmCtrl.setDuty(16000, 0);
  // }*/


  // //init ToneControl instance "toneCtrl0" for pin 18
  // toneCtrl0.init(13);
  // success = PinMgr.request(toneCtrl0);
  // if (!success) {
  //   DEBUG_PRINTLN("Failure: Request pin for tone");
  // } else {
  //   uint32_t noteFreq = toneCtrl0.getNoteFreq(3);
  //   toneCtrl0.setFreqDutyRes(noteFreq, -1);
  //   toneCtrl0.setDuty(200, 0);
  //   delay(500);
  //   toneCtrl0.setDuty(0, 0);
  // } /*

  // //Try to release pwmCtrl which is using pin 8 currently. The LED of pin 8 should be turned off.
  // PinMgr.release(pwmCtrl);

  // //Try to init another ToneControl instance "toneCtrl1" for pin 8 which is just released
  // toneCtrl1.init(8);
  // success = PinMgr.request(toneCtrl1);
  // if (!success) {
  //   DEBUG_PRINTLN("Failure: Request pin for tone");
  // } else {
  //   uint32_t noteFreq = toneCtrl1.getNoteFreq(5);
  //   toneCtrl1.setFreqDutyRes(noteFreq, -1);
  //   toneCtrl1.setDuty(200, 0);
  //   delay(500);
  //   toneCtrl1.setDuty(0, 0);
  // }*/

  err = addrLedCtrl.init(19, 64, true);
  addrLedCtrl.enableScheduler(2000, 10, addrLedEventHandler);
  if (err) {
    DEBUG_PRINTLN("Failure: Init pin for AddrLED");
    if (err == AddrLEDControl_InvalidPinIndex) {
      Serial.println("Pin for AddrLed is invalid");
    }
  } else {
    //SetRGBFunc* moveGroup = new MoveGroup(addrLedCtrl, 8);
    //seq.addSetRGBFunc(0, 50, moveGroup);
    seq.addInterpolateHSV(5000, 0, 80, 50, 360, 80, 80);
    seq.addInterpolateHSV(5000, 360, 80, 80, 0, 80, 50);

    seq2.addSetHSV(1000, 360, 80, 80);
    seq2.addSetHSV(1000, 0, 0, 0);

    seqTargets.clear();
    //seqTargets = {0, 1, 2, 3 ,4, 5, 6, 7};
    for (int i = 0; i < 32; i++) {
      seqTargets.push_back(i);
    }

    addrLedCtrl.playRelTime(seqTargets, seq, 1000, 1);
    //addrLedCtrl.setHSV(seqTargets, 120, 80, 80);

    seqTargets.clear();
    for (int i = 32; i < 64; i++) {
      seqTargets.push_back(i);
    }

    addrLedCtrl.playRelTime(seqTargets, seq, 6000, -1);
    //addrLedCtrl.setHSV(seqTargets, 10922, 200, 200);
  }
}

void loop() {
  IO_Control.execute();
}
