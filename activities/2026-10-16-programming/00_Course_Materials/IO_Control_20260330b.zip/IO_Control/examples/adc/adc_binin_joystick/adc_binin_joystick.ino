//
//  for determining state of a joystick
//    board: Luatos ESP32C3 board
//    circuit:
//      IO00 - VRx
//      IO01 - VRy
//      IO05 - SW
//

#include <IO_Control.h>

ADCControl adcCtrl0;
ADCControl adcCtrl1;
BinInControl binInCtrl0;

DeclareHandler(adcCtrl0Handler, _ctrl, ADCControl, {
    // if (_ctrl.isSchedulerTimeEvent(_status))
    //   Serial.println("BinOutControl - SchedulerTimerEvent");
    if (_ctrl.isIndexChanged()) {
      Serial.print("adcCtrl0 index=");
      Serial.print(_ctrl.getLastIndex());
      Serial.print(" time=");
      Serial.print(_ctrl.getLastChangeTime());
      Serial.print(" value=");
      Serial.println(_ctrl.getLastValue());
    }
});

DeclareHandler(adcCtrl1Handler, _ctrl, ADCControl, {
    // if (_ctrl.isSchedulerTimeEvent(_status))
    //   Serial.println("BinOutControl - SchedulerTimerEvent");
    if (_ctrl.isIndexChanged()) {
      Serial.print("adcCtrl1 index=");
      Serial.print(_ctrl.getLastIndex());
      Serial.print(" time=");
      Serial.print(_ctrl.getLastChangeTime());
      Serial.print(" value=");
      Serial.println(_ctrl.getLastValue());
    }
});

DeclareHandler(binIn0Handler, _ctrl, BinInControl, {
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isBinInTriggered()) {
    Serial.print("event time=");
    Serial.print(_ctrl.getInterruptTime());
    if (_ctrl.getInterruptState())
      Serial.println(" from LOW to HIGH");
    else
      Serial.println(" from HIGH to LOW");
    Serial.print("ADC0 - state = ");
    Serial.println(adcCtrl0.getLastIndex());
    Serial.print("ADC1 - state = ");
    Serial.println(adcCtrl1.getLastIndex());
  }
});

DeclareHandler(iocontrolHandler, _ctrl, IOControl, {
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");

  // int val0=adcCtrl0.read();
  // int val1=adcCtrl1.read();
  // Serial.print("time=");
  // Serial.print(_currentMillis);
  // Serial.print(" adc0=");
  // Serial.print(val0);
  // Serial.print(" adc1=");
  // Serial.println(val1);
});

  void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  std::vector<uint16_t> thres = { 1000, 3000 };
  adcCtrl0.init(1, 0);
  err_t err = adcCtrl0.setThreshold(thres);
  if (err) {
    Serial.print("Fail to execute adcCtrl0.setThreshold. Error code = ");
    Serial.println(err);
    return;
  }
  err = adcCtrl0.enableScheduler(0, 10, adcCtrl0Handler);
  if (err) {
    Serial.print("Fail to execute adcCtrl0.enableScheduler. Error code = ");
    Serial.println(err);
    return;
  }

  adcCtrl1.init(1, 1);
  err = adcCtrl1.setThreshold(thres);
  if (err) {
    Serial.print("Fail to execute adcCtrl1.setThreshold. Error code = ");
    Serial.println(err);
    return;
  }
  err = adcCtrl1.enableScheduler(0, 10, adcCtrl1Handler);
  if (err) {
    Serial.print("Fail to execute adcCtrl1.enableScheduler. Error code = ");
    Serial.println(err);
    return;
  }

  err = binInCtrl0.init(5, INPUT_PULLUP);
  if (err) {
    Serial.print("Fail to initialize binInCtrl0. Error code = ");
    Serial.println(err);
    return;
  }

  err = binInCtrl0.enableScheduler(0, 10, binIn0Handler);
  if (err) {
    Serial.print("Fail to execute binInCtrl0.enableScheduler. Error code = ");
    Serial.println(err);
    return;
  }
  binInCtrl0.enableInterrupt(CHANGE);

  IO_Control.enableScheduler(0, 100, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute(); //  this statement must be run repeatedly
}
