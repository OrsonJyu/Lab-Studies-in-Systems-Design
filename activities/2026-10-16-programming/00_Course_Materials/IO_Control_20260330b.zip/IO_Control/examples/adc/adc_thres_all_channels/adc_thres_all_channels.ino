//
//  for enabling all ADC channels and applying thresholding on analog readings
//    board:  Luatos ESP32C3 board
//    circuit:
//      connect one wiper of VR to each of ADC1 channel 0 to 4
//
//    board:  ESP32S3 Dev Board
//    circuit:
//      connect one wiper of VR to each of ADC1 channel 0 to 9 and ADC2 channel 0 to 9
//      

#include <IO_Control.h>

#ifdef CONFIG_IDF_TARGET_ESP32C3
const int maxChannel=5;
const int maxUnit=1;
#endif

#ifdef CONFIG_IDF_TARGET_ESP32S3
const int maxChannel=10;
const int maxUnit=2;
#endif

ADCControl adcCtrl[maxUnit][maxChannel];
ADCControl  dummy;

DeclareHandler(adcCtrl0Handler,_ctrl,ADCControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isIndexChanged())
  { Serial.printf("adcCtrl unit=%d channel=%d index=",_ctrl.getUnit(),_ctrl.getChannel());
    Serial.print(_ctrl.getLastIndex());
    Serial.print(" time=");
    Serial.print(_ctrl.getLastChangeTime());
    Serial.print(" value=");
    Serial.println(_ctrl.getLastValue());
  }
});

DeclareHandler(iocontrolHandler,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");

  // int val0=adcCtrl0.read();
  // int val1=adcCtrl1.read();
  // Serial.print("time=");
  // Serial.print(_currentMillis);
  // Serial.print(" adc0=");
  // Serial.print(val0);
  // Serial.print(" adc1=");
  // Serial.println(val1);
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  std::vector<uint16_t> thres={1000,3000};
  err_t err;

  err=dummy.init(maxUnit+1,0); //  must be error
  Serial.printf("adc unit=%d, channel 0; err=%d\n",maxUnit+1,err);
  
  err=dummy.init(maxUnit,maxChannel); //  must be error
  Serial.printf("adc unit=%d, channel %d; err=%d\n",maxUnit,maxChannel,err);

  for (int i = 1; i<=maxUnit;i++)
  { for (int j=0;j<maxChannel;j++)
    { err=adcCtrl[i-1][j].init(i,j); //  unit 1, channel 0
      if (err!=Control_OK)
      { Serial.printf("error in initializing adc unit=%d channel=%d; err=%d\n",i,j,err);
      }
      else
      {   err=adcCtrl[i-1][j].setThreshold(thres);
        if (err)
        { Serial.printf("Fail to execute adcCtrl[%d][%d].setThreshold. Error code = ",i-1,j);
          Serial.println(err);
          return;
        }
        err=adcCtrl[i-1][j].enableScheduler(0, 10, adcCtrl0Handler);
        if (err)
        { Serial.print("Fail to execute adcCtrl0.enableScheduler. Error code = ");
          Serial.println(err);
          return;
        }
      }
    }
  }

  IO_Control.enableScheduler(0, 100, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute(); //  this statement must be run repeatedly
}
