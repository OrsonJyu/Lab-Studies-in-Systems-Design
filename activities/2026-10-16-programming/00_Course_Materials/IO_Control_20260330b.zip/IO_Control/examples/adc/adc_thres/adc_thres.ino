//
//  for thresholding two analog inputs
//    board: Luatos ESP32C3 board
//    circuit:
//      IO00 - 1st analog input 
//      IO01 - 2nd analog input
//

#include <IO_Control.h>

ADCControl  adcCtrl0;
ADCControl  adcCtrl1;

DeclareHandler(adcCtrl0Handler,_ctrl,ADCControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isIndexChanged())
  { Serial.print("adcCtrl0 index=");
    Serial.print(_ctrl.getLastIndex());
    Serial.print(" time=");
    Serial.print(_ctrl.getLastChangeTime());
    Serial.print(" value=");
    Serial.println(_ctrl.getLastValue());
  }
});

DeclareHandler(adcCtrl1Handler,_ctrl,ADCControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");
  if (_ctrl.isIndexChanged())
  { Serial.print("adcCtrl1 index=");
    Serial.print(_ctrl.getLastIndex());
    Serial.print(" time=");
    Serial.print(_ctrl.getLastChangeTime());
    Serial.print(" value=");
    Serial.println(_ctrl.getLastValue());
  }
});


DeclareHandler(iocontrolHandler,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("BinOutControl - SchedulerTimerEvent");

  // int val0=adcCtrl0.read();
  // int val1=adcCtrl1.read();
  // Serial.print("time=");
  // Serial.print(_currentMillis);
  // Serial.print(" adc0=");
  // Serial.print(val0);
  // Serial.print(" adc1=");
  // Serial.println(val1);
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  std::vector<uint16_t> thres={1000,3000};
  adcCtrl0.init(1,0);

  err_t err=adcCtrl0.setThreshold(thres);
  if (err)
  { Serial.print("Fail to execute adcCtrl0.setThreshold. Error code = ");
    Serial.println(err);
    return;
  }
  err=adcCtrl0.enableScheduler(0, 10, adcCtrl0Handler);
  if (err)
  { Serial.print("Fail to execute adcCtrl0.enableScheduler. Error code = ");
    Serial.println(err);
    return;
  }

  adcCtrl1.init(1,1);

  err=adcCtrl1.setThreshold(thres);
  if (err)
  { Serial.print("Fail to execute adcCtrl1.setThreshold. Error code = ");
    Serial.println(err);
    return;
  }
  err=adcCtrl1.enableScheduler(0, 10, adcCtrl1Handler);
  if (err)
  { Serial.print("Fail to execute adcCtrl1.enableScheduler. Error code = ");
    Serial.println(err);
    return;
  }

  IO_Control.enableScheduler(0, 100, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute(); //  this statement must be run repeatedly
}
