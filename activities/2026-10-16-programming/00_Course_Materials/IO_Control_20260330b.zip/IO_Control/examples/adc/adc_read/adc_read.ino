//
//  for reading two analog inputs
//    board: Luatos ESP32C3 board
//    circuit:
//      IO00 - 1st analog input
//      IO01 - 2nd analog input
//

#include <IO_Control.h>

ADCControl adcCtrl0;
ADCControl adcCtrl1;

DeclareHandler(iocontrolHandler, _ctrl, IOControl, {
  int val0 = adcCtrl0.read();
  int val1 = adcCtrl1.read();
  Serial.print("time=");
  Serial.print(_ctrl.handlerCurrentMillis);
  Serial.print(" adc0=");
  Serial.print(val0);
  Serial.print(" adc1=");
  Serial.println(val1);
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  adcCtrl0.init(1, 0);

  adcCtrl1.init(1, 1);

  Serial.print("max value from adcCtrl0.read() =");
  Serial.println(adcCtrl0.getMaxValue());

  IO_Control.enableScheduler(0, 100, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute(); //  this statement must be run repeatedly
}
