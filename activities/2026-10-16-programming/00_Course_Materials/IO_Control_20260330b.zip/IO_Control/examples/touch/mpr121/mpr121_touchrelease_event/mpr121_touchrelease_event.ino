//
//  for demonstrating use of MPR121 for touch and release sensing of its 12 capacitive touch terminals
//    circuit:
//      IO07 - IRQ
//      IO10 - SCL
//      IO06 - SDA
//      3.3V - 3.3V on MPR121
//      GND  - GND on MPR121
//

#define USE_MPR121Control
#include <IO_Control.h>

I2CMasterControl i2cCtrl;
MPR121Control mpr121Ctrl;

DeclareHandler(mpr121Handler,_ctrl,MPR121Control,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("MPR121Control - SchedulerTimerEvent");
  for (uint8_t i = 0; i < 12; i++) {
    if (_ctrl.touchedTimeMS[i] != 0) {
      //implement touch event here.
      Serial.print("touched i=");
      Serial.print(i);
      Serial.print(" at time=");
      Serial.println(_ctrl.touchedTimeMS[i]);
    }

    if (_ctrl.releasedTimeMS[i] != 0) {
      //implement release event here
      Serial.print("released i=");
      Serial.print(i);
      Serial.print(" at time=");
      Serial.println(_ctrl.releasedTimeMS[i]);
    }
  }
});


void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = i2cCtrl.init(0, 10, 6);  //  use i2cNum=0, SCL=10, SDA=6
  if (err)
  { Serial.print("Fail to initialize i2cCtrl. Error code = ");
    Serial.println(err);
    return;
  }

  err = mpr121Ctrl.init(i2cCtrl, 0x5A, 7, 1000, 10, mpr121Handler);
  if (err)
  { Serial.print("Fail to initialize mpr121Ctrl. Error code = ");
    Serial.println(err);
    return;
  }

  mpr121Ctrl.enableScheduler(0,10,mpr121Handler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
