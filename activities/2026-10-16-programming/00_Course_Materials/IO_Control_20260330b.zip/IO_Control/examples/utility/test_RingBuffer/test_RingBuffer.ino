#include "RingBuffer.h"

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  RingBuffer buf(64);

  byte data[16];

  //  write block of data of 16 bytes till full
  int i=0;
  while (!buf.isFull())
  {   
      for (int j=0;j<16;j++)
        data[j]=i++;
    
      buf.write(data,16);
      Serial.println(buf.available());
  }
  assert(buf.available()==64);

  //  read block of data of 4 bytes till empty
  while (!buf.isEmpty())
  {   buf.read(data,4);
      for (int i=0;i<4;i++)
      { Serial.print(data[i],HEX);
        Serial.print(" ");
      } 
    Serial.println();
  }
  assert(buf.available()==0);

  //  write 15 bytes at a time, till cannot write
  i=0;
  while (true)
  {   for (int j=0;j<15;j++)
        data[j]=i++;

      bool status=buf.write(data,15);
      if (!status)
        break;
  }
  Serial.print("no of bytes available=");
  Serial.println(buf.available());
  assert(buf.available()==60);  //  should have written 15*4=60 bytes

  //  read 7 bytes at a time from the buffer
  int no_to_read=7;
  while (true)
  { size_t len = buf.read(data,no_to_read);
    for (int i=0;i<len;i++)
    { Serial.print(data[i],HEX);
      Serial.print(" ");
    }
    Serial.println();
    if (len!=no_to_read)
    { assert(len==4); //  the last block of data read = 60%7 = 4
      break;
    }
      
  }
  Serial.print("no of bytes available=");
  Serial.println(buf.available());

  buf.clear();

  i=0;
  while (!buf.isFull())
  {   
      for (int j=0;j<16;j++)
        data[j]='0'+(i++);
    
      buf.write(data,16);
      Serial.println(buf.available());
  }
  buf.read(data,10);  //  data= "0123456789"
  buf.write(data,10); //  put data at end of RingBuffer

  int len = buf.find("678");
  Serial.println(len);
  assert(len==60);

  byte buffer[64];
  len=buf.readUntil(buffer,64,"678");
  Serial.println(len);
  assert(len==63);
  for (int i=0;i<len;i++)
  { Serial.print((char) buffer[i]);
    Serial.print(" ");
  }
  Serial.println();

  Serial.println(buf.available());
  assert(buf.available()==1);

}

void loop() {
  // put your main code here, to run repeatedly:

}
