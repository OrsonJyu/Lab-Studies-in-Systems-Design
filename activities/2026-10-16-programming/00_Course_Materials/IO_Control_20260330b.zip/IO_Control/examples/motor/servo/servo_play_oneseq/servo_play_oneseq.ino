//
//  for demonstrating playback of a sequence of servo angle movements for a servo motor
//    circuit:
//      a servo motor with the following connections:
//      IO08 - PWM
//      5V   - VCC
//      GND  - GND
//

#include <IO_Control.h>

ServoControl servoCtrl0;
ServoSequence servoSeq0;

// uint16_t counter=0;
// double minAngle=10;
// double maxAngle=170;
// uint16_t timeStepInc=10; //  update servo position every 50*4 ms = 200ms
// double angleInc=5;
// double currentAngle=minAngle;

DeclareHandler(servoHandler,_ctrl,ServoControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("ServoControl - SchedulerTimerEvent");
  if (_ctrl.isAllSeqStarted())
    Serial.println("ServoControl - AllSeqStarted");
  if (_ctrl.isAllSeqEnded())
    Serial.println("ServoControl - AllSeqEnded");
  if (_ctrl.isOneSeqStarted())
    Serial.println("ServoControl - OneSeqStarted");
  if (_ctrl.isOneSeqNewCmdStarted())
    Serial.println("ServoControl - OneSeqNewCmdStarted");
  if (_ctrl.isOneSeqPaused())
    Serial.println("ServoControl - OneSeqPaused");
  if (_ctrl.isOneSeqEnded())
    Serial.println("ServoControl - OneSeqEnded");  
  if (_ctrl.isAngleOutOfBound())
    Serial.println("ServoControl - Error: Angle Out of Bound");
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err=servoCtrl0.init(8);
  if (err)
  { Serial.print("Fail to initialize servoCtrl0. Error code = ");
    Serial.println(err);
    return;
  }
  Serial.print("min angle=");
  Serial.println(servoCtrl0.getMinAngle());
  Serial.print("max angle=");
  Serial.println(servoCtrl0.getMaxAngle());

  err=servoSeq0.addSetAngle(500,90,servoCtrl0);
  if (err)
  { Serial.print("Failed in adding command to servoSeq0 - error code=");
    Serial.println(err);
    return;
  }
  err=servoSeq0.addMoveFromToAngle(1000,90,20,servoCtrl0);
  if (err)
  { Serial.print("Failed in adding command to servoSeq0 - error code=");
    Serial.println(err);
    return;
  }
  err=servoSeq0.addMoveFromToAngle(1500,20,160,servoCtrl0);
  if (err)
  { Serial.print("Failed in adding command to servoSeq0 - error code=");
    Serial.println(err);
    return;
  }
  err=servoSeq0.addMoveFromToAngle(1000,160,90,servoCtrl0);
  if (err)
  { Serial.print("Failed in adding command to servoSeq0 - error code=");
    Serial.println(err);
    return;
  }

  servoCtrl0.enableScheduler(0, 20, servoHandler);
  servoCtrl0.playRelTime(servoSeq0,2000,1);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
