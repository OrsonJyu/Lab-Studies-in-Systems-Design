//
//  for demonstrating direct setting of servo angle for a servo motor
//    circuit:
//      a servo motor with the following connections:
//      IO08 - PWM
//      5V   - VCC
//      GND  - GND
//
#include <IO_Control.h>

ServoControl servoCtrl0;
uint16_t timeCounter=0;
double minAngle=10;
double maxAngle=170;
uint16_t timeCounterMax=10; //  update servo position every 50*10 ms = 500ms
double angleInc=5;
double currentAngle=minAngle;

DeclareHandler(iocontrolHandler,_ioCtrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //   Serial.println("IOControl - SchedulerTimerEvent"); 
  if (timeCounter>=timeCounterMax)
  { timeCounter=0;
    currentAngle += angleInc;
    if (currentAngle > maxAngle)
      currentAngle = minAngle;
    servoCtrl0.setAngle(currentAngle);

    Serial.print("current time=");
    Serial.print(_ioCtrl.handlerCurrentMillis);
    Serial.print(" angle=");
    Serial.println(currentAngle);
  } 

  timeCounter++;
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err=servoCtrl0.init(8);
  if (err)
  { Serial.print("Fail to initialize servoCtrl0. Error code = ");
    Serial.println(err);
    return;
  }

  Serial.print("min angle=");
  Serial.println(servoCtrl0.getMinAngle());
  Serial.print("max angle=");
  Serial.println(servoCtrl0.getMaxAngle());

  IO_Control.enableScheduler(0, 50, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
