#define USE_N20Control
#include <IO_Control.h>

N20Control n20Ctrl;
N20Sequence n20Seq;

bool hasPlayed = false;

DeclareHandler(ioCtrlHandler, _ctrl, IOControl, {
  Serial.println(n20Ctrl.currentRPM);
  if (!hasPlayed) {
    if (n20Ctrl.hasInitialized()) {
      Serial.println("Start playing sequence");
      n20Ctrl.playRelTime(n20Seq, 0, -1);
      hasPlayed = true;
    }
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);

  Serial.println("chip started");

  n20Ctrl.init(0, 1, 5, 12);

  n20Seq.addMoveRPM(50000, 50);
  n20Seq.addStop(1000);
  n20Seq.addMoveRPM(5000, 50);
  n20Seq.addStop(1000);

  n20Ctrl.enableScheduler(0, 200, nullptr);

  IO_Control.enableScheduler(0, 200, ioCtrlHandler);

  n20Ctrl.initialize();
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
