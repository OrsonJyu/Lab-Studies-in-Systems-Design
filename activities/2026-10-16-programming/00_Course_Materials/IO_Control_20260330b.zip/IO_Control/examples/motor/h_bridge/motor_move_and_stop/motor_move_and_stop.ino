#define USE_MotorControl
#include <IO_Control.h>

int state = 0;

MotorControl motorCtrl1;

MotorControl motorCtrl2;

DeclareHandler(iocontrolHandler, _ioCtrl, IOControl, {
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //   Serial.println("IOControl - SchedulerTimerEvent");
  switch (state) {
    case 0:
      {
        uint32_t maxDuty = motorCtrl1.getMaxDuty();
        motorCtrl1.move_pwm(maxDuty, -1);
        motorCtrl2.move_pwm(maxDuty, -1);
        state = 1;
        break;
      }
    case 1:
      {
        uint32_t maxDuty = motorCtrl1.getMaxDuty();
        motorCtrl1.move_pwm(maxDuty, 1);
        motorCtrl2.move_pwm(maxDuty, 1);
        state = 0;
        break;
      }
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin();

  Serial.begin(115200);
  Serial.println("chip started");

  err_t err = motorCtrl1.init(1, 2, false);
  if (err) {
    Serial.print("Fail to initialize motorCtrl1. Error code = ");
    Serial.println(err);
    return;
  }

  err = motorCtrl2.init(5, 12, false);
  if (err) {
    Serial.print("Fail to initialize motorCtrl2. Error code = ");
    Serial.println(err);
    return;
  }

  uint32_t maxDuty = motorCtrl1.getMaxDuty();
  Serial.print("Max Duty is: ");
  Serial.println(maxDuty);

  IO_Control.enableScheduler(0, 3000, iocontrolHandler);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}
