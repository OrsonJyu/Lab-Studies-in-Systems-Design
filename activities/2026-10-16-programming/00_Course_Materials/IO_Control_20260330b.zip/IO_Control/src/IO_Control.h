#ifndef IO_CONTROL_H
#define IO_CONTROL_H

#include "Debug.h"
#include "TimeEventManager.h"
#include "PinManager.h"
//#include "TaskScheduler.h"
#include "UARTControl.h"
#include "MenuControl.h"

// #define USE_AddrLEDControl
// #define USE_SSD1306Control
// #define USE_SH1106Control
// #define USE_MPR121Control
// #define USE_DFPlayerMP3Control


#ifdef USE_WiFiControl
#include "WiFiControl.h"
#endif

#ifdef USE_HTTPClientControl
#include "HTTPClientControl.h"
#endif

#ifdef USE_WebServerControl
#include "WebServerControl.h"
#endif

#ifdef USE_AddrLEDControl
#include "AddrLEDControl.h"
#endif

#ifdef USE_SSD1306Control
#include "SSD1306Control.h"
#endif
#ifdef USE_SH1106Control
#include "SH1106Control.h"
#endif
#ifdef USE_MPR121Control
#include "MPR121Control.h"
#endif

#ifdef USE_DFPlayerMP3Control
#include "DFPlayerMP3Control.h"
#endif

#ifdef USE_SoftWarePlayerMP3Control
#include "SoftwarePlayerMP3Control.h"
#endif

#ifdef USE_MotorControl
#include "MotorControl.h"
#endif

#ifdef USE_EncoderControl
#include "EncoderControl.h"
#endif

#ifdef USE_N20Control
#include "N20Control.h"
#endif

#ifdef USE_UltraSonicControl
#include "UltraSonicControl.h"
#endif

#ifdef USE_MAX7219Control
#include "MAX7219Control.h"
#endif

// #ifdef USE_UARTControl
// #include "UARTControl.h"
// #endif

#ifdef USE_VL53L0X
#include "VL53L0XControl.h"
#endif

#ifdef USE_DHTControl
#include "DHTControl.h"
#endif

#ifdef USE_INMP441Control
#include "INMP441Control.h"
#endif

#ifdef USE_AsyncWebServerControl
#include "AsyncWebServerControl.h"
#include "WebSocketStream.h"
#endif

#ifdef USE_PainlessMesh
#include "PainlessMeshStream.h"
#endif

PinManager& PinMgr = PinManager::getInstance();

//	note that both scheduler and timerTargets have to be defined in main sketch, or else the program will crash; reason unknown!!!
//Scheduler TimeEventManager::scheduler;
// Task* TimeEventManager::task;
std::vector<Control*> TimeEventManager::timerTargets;
// uint32_t TimeEventManager::loopCount = 0;

enum IOControl_UART0Mode { IOControl_UART0Mode_RxTx = 0,
                           IOControl_UART0Mode_RxOnly = 1,
                           IOControl_UART0Mode_TxOnly = 2,
};

class IOControl : public Control {
private:
  HWCDCControl* hwcdcCtrl = 0;
  UARTControl* uartCtrl = 0;

public:
  IOControl() {
    active = true;  //	no need to initialize
    clsID = CLS_IOCONTROL;
  }

  static int getStaticClsID() {
    return CLS_IOCONTROL;
  }

  err_t begin(ulong_t _baudRate = 115200, UARTControl_Config _config = UART_8N1,
              IOControl_UART0Mode _mode = IOControl_UART0Mode_RxTx) {  //  set baud rate of the serial interface
    //  set initial mode if

    err_t err;
    TimeEventManager::schedulerStartNow();

#if ARDUINO_USB_CDC_ON_BOOT  //Serial used for USB CDC
    hwcdcCtrl = new HWCDCControl();
    err = hwcdcCtrl->init(_baudRate);
    return err;

#else
//#ifdef CONFIG_IDF_TARGET_ESP32C3
    err = IOControl_UnknownError;
    uartCtrl = new UARTControl();
    switch (_mode) {
      case IOControl_UART0Mode_RxTx:
        err = uartCtrl->init(0, UARTControl::pinUART0RX, UARTControl::pinUART0TX, -1, -1, _baudRate, _config);
        break;
      case IOControl_UART0Mode_RxOnly:
        err = uartCtrl->init(0, UARTControl::pinUART0RX, -1, -1, -1, _baudRate, _config);
        break;
      case IOControl_UART0Mode_TxOnly:
        err = uartCtrl->init(0, -1, UARTControl::pinUART0TX, -1, -1, _baudRate, _config);
        break;
    }
    return err;
//#elif defined(CONFIG_IDF_TARGET_ESP32S3)
//    return Control_OK;
//#endif
#endif
  }

  void execute() {
    TimeEventManager::schedulerExecute();
  }

  bool isInit() {
    return true;
  }

  err_t startControl() {
    return Control_OK;
  }

  err_t stopControl() {
    return Control_OK;
  }

  Stream* getSerial() {
#if ARDUINO_USB_CDC_ON_BOOT  //Serial used for USB CDC
    return hwcdcCtrl->getSerial();
#else
    return uartCtrl->getHardwareSerial();
#endif
  }
};

IOControl IO_Control;

#endif