#ifndef HTTPCLIENTCONTROL_H
#define HTTPCLIENTCONTROL_H

#include "Control.h"
#include "Debug.h"
#include <WiFi.h>
#include <NetworkClient.h>
#include <NetworkClientSecure.h>
#include "WiFiControl.h"
#include "RingBuffer.h"
#include <map>
#include <string>
#include <LittleFS.h>

/*
usage example:


WiFiControl w;
HTTPClientControl c;
c.init(w,isSecure, buffer_size);	//	isSecure == true if https, otherwise for http

to connect and send request, using GET method:
	c.connect(serverIP,port,HTTP1_1);
	c.get(path,handler)
		prepare first line and send to ringBuffer
		while (true)
		{	handler(_ctrl,PrepareHeader);
				fill up ringBuffer
			if (ringBuffer->isEmpty())
				break;
			sendRequestHeaders()
		}
		
		headerTooLarge=false
		counter=0
		while (true)
			Read as many data as possible to fill in ringBuffer
			counter++
		
			if (counter==1)
				get first line of response (with ending "\r\n"), and parse:
					<proto> <response code> <description>
				if format not match,
					state = abort
					handler(_ctrl,ResponseFirstLineError)
				else
					set "response status" and "proto" and "description"
					getResponseStatusCode() and getResponseProto() should have valid values
			else
				if (headerTooLarge)
				{	//	previous header is too large
					len=find("\r\n");
					if (len!=-1)
						handler(_ctrl,ResponseHeaderTooLarge,len)
						headerTooLarge=false
					else
						handler(_ctrl,ResponseHeaderTooLarge,-1)
						continue
				}
			
			len=find("\r\n");
			if (len==0)
				break;	//	end of headers
			if len>0
				handler(_ctrl,ResponseOneHeader,len);	//	remove data from ringBuffer and process
			if len<0
				if ringBuffer is NOT full
					header not complete, continue
				else
					handler(_ctrl,ResponseHeaderTooLarge,-1)
					headerTooLarge=true;
				
		
		
		
				
		
		
	
	
	
		handler(_ctrl,
		sendHeaders(_ctrl,GET)
	c.setReqHeader(name1,value1);
	c.setReqHeader(name2,value2);
	...
*	c.sendRequestHeaders(false);	//	indicate still something to send
	c.setReqHeader(name3,value3);
	c.setReqHeaderConnClose();
*	c.sendRequestHeaders(true);	//	indicate all headers sent





to connect and send request, using POST method:
	c.connect(serverIP,port,HTTP1_1);
*	c.post(path,type,length);	//	add headers for post method, with content type and length
	c.setReqHeader(name1,value1);
	c.setReqHeader(name2,value2);
	...
*	c.sendRequestHeaders(false);	//	indicate still something to send
	c.setReqHeader(name3,value3);
	c.setReqHeader(name4,value4);
*	c.sendRequestHeaders(true);	//	indicate all headers sent
*	c.postBody(...);			//	post data for the body part
								//	can be string, file, ...
*	c.sendRequestBody(false);	//	indicate still some additional part of body to be sent
*	c.postBody(...);
*	c.sendRequestBody(true);	//	indicate all data of body has been sent


from https://www.geeksforgeeks.org/html/http-messages/
<HTTP-Version> <Status-Code> <Reason-Phrase>
<Header-Name>: <Header-Value>
...
<Header-Name>: <Header-Value>

<Optional-Body>


flow to receiving data:
	<_preHandler> 
		wait for data from connection
		wait for first line of response of to complete:
			<proto> <response code> <description>
			if format not match, return error, set state to abort
		set "response status" and "proto" 
			getResponseStatusCode() and getResponseProto() should have valid values
		set state = ResponseHeadersReceiving 
		while (true) 
		{	status =  getHeader(name,value)	//	scan for a name:value pair in header
			switch (status)
			{	case HeaderOK:
					process name and value
					_processHeader(_ctrl,HeaderOK,length of header);	
						- action: remove name and value from RingBuffer, and process
					continue
			
				case HeaderInComplete:
					end of header not detected yet
					return (let _preHandler to retrieve more bytes)
				
				case HeaderTooLarge:
					no free space in RingBuffer, but end of header not detected 
					provide a means to retrieve partial header? or just mark and read till /r/n appears?
					skip and continue ??
					_processHeader(_ctrl,HeaderTooLarge);
						- action: remove part of header from RingBuffer and process by itself
				
				case NoHeaderRemain:
					//	set state = ResponseLastHeaderReceived
					//	calling "getHeader(..)" subsequently will also return "NoHeaderRemain", until next call to SendRequest***()
					//	_c.isBodyInComplete() will be true
					break;
				
				case NotAHeader:
					??
					some way to read the header?
					_processHeader(_ctrl,NotAHeader);
						- action: remove header, and process by itself
					continue
			}
		}
		
		if (_c.isBodyIncomplete() or _c.isBodyAvailable()
		{	getBody()
			Q: issue with return in String? how to read data replied in binary format? say from post?
			
			if (_c.isBodyIncomplete())
				state = ResopnseBodyReceiving
				_processBody(_ctrl,BodyInComplete);
			if (_c.isBodyAvailable())
				state = ResponseBodyEndReceived
				_processBody(_ctrl,BodyEndReceived);
			
		}
	
	

handler(_c)
	_c.getState()
		ResponseReceiving	: receiving data, end not yet reached
		ResponseEndReceived	: end of data received

	

*	if (_c.getState() == ResponseReceiving || == ResponseEndReceived)
	{	//	buffer has data for at least one header
		//	ResponseHeadersReceiving - 
		
	}



handler()
	c.connect(serverIP,port,HTTP1_1);
	c.get("/abc/efg");
	or c.post(...);
	or c.put(...);
	c.setReqHeader("name");
	c.setReqHeader("name","value");	//	write header and value to internal buffer
	c.setReqHeaderConnClose();
	c.sendRequest();
		//	initiate sending data thru http connection

update()
{	while (availableForWrite())
		write some bytes from buffer to destination
	if no more data to write
		

}
*/

enum HTTPClientControl_ProtoVer_t {
	HTTP1_0,
	HTTP1_1
};

enum HTTPClientControl_HTTPState_t {
	Connected,		//	connected to a server, request not yet sent
	NotConnect,		//	not connect to any server
	RequestSending,	//	currently sending request to server; request may be larger than bufferSize and have to be sent in multiple passes
	RequestSent,	//	all data for request has been sent
	ResponseReceiving,	//	receiving response from server, but end of response not yet received
	ResponseReceived,	//	end of response from server received
	Aborted			//	error occurred during http request, and aborted; must be closed and connect again
};

enum HTTPClientControl_Event_t
{	Event_Aborted,

};

enum HTTPClientControl_HTTPMethod_t {
  HTTPMethod_GET = 1,
  HTTPMethod_POST = 2,
};

enum HTTPClientControl_Response_Status {
  NoRepsonse = 0,
  HeaderIncomplete = 1 << 1,
  HeaderAvailable = 1 << 2,
  BodyIncomplete = 1 << 3,
  BodyAvailable = 1 << 4,
};

class HTTPClientControl;

typedef void (*HTTPClientControl_EventHandler)(HTTPClientControl&,HTTPClientControl_Event_t);


//typedef void (*HTTPClientControl_PrepareRequestHandler)(HTTPClientControl& _ctrl);


class PinManager;

class HTTPClientControl : public Control {
protected:

	NetworkClient* nc = nullptr;

	NetworkClientSecure* ncs = nullptr;

	bool isSecure = false;	
	
	HTTPClientControl_ProtoVer_t protocol = HTTP1_0;	//	communication protocol

	HTTPClientControl_HTTPState_t httpState;
	
	RingBuffer* ringBuffer;	//	for holding data for request and from response
	
	HTTPClientControl_HTTPMethod_t method;
	
	HTTPClientControl_EventHandler eventHandler=nullptr;	//	event handler for preparing of http request and processing of http response
  


  bool httpClientCtrlIsInit = false;



  String targetServer = "";

  uint16_t bufferSize = 0;

  uint16_t bufferIndex = 0;

  //byte* byteBuffer;



  

  String httpBody = "";

  byte* httpBodyBytePtr = nullptr;

  int httpBodyContentLength = 0;

  File* httpFile = nullptr;

  String httpFilename = "";

  String httpFileType = "";

  String httpBoundary = "defaultBoundary";

  String httpMultipartHeaderBegin = "";

  String httpMultipartHeaderEnd = "";

  byte* bArray;	//	an internal byte buffer, with bufferSize+1 bytes 

  bool shouldSendRequest = false;

  // bool shouldSendBody = false;
  uint8_t shouldPostData = 0;  // 0: nothing should be sent, 1: should send body, 2:should send file

  int httpResState = NoRepsonse;

  String currentHeaderValue = "";

  err_t addStringToRingBuffer(const char* str);

  bool isInit();

  err_t startControl();

  err_t stopControl();

  void sendHttpHeaders(byte* byteArray, size_t arraySize, NetworkClient* nc);

  void sendHttpHeaders(byte* byteArray, size_t arraySize, NetworkClientSecure* ncs);

  friend PinManager;

public:
  HTTPClientControl();

  static int getStaticClsID() {
    return CLS_HTTPCLIENT;
  }

	//
	//	@brief	Initialize a HTTPClientControl
	//	@param	_wifiCtrl	WiFiControl object; must be in STA mode or AP mode or both
	//	@param	_isSecure	true if this is for https connection, false if not
	//	@param	_bufferSize	size of internal buffer for holding request and response
	//	@return	Control_OK if success, error code if failed 
	//
  err_t init(WiFiControl& _wifiCtrl, bool _isSecure, uint16_t _bufferSize);

	//
	//	@brief	Check whether this object has connected to a server
	//	@return	true if connected, false otherwise
	//	
  bool isConnected();

	//
	//	@brief	Return NetworkClient object associate with this HTTPClientControl
	//	@return	NetworkClient if _isSecure == false, null otherwise
	//	
  NetworkClient* getNetworkClient();

	//
	//	@brief	Return NetworkClientSecure object associate with this HTTPClientControl
	//	@return	NetworkClientSecure if _isSecure == true, null otherwise
	//	
  NetworkClientSecure* getNetworkClientSecure();

	//
	//	@brief	Set NetworkSclientSecure object to insecure mode; only valid if _isSecure == true
	//	@return	Control_OK if successful, error code otherwise
	//	
  err_t setInsecure();

	//
	//	@brief	Connect to a server with a given name and port number, and using specified protocol
	//	@param	_serverName	Name of the server
	//	@param	_serverPort Port number of the server; if ==0, use default according to _isSecure in init(...)
	//						if _isSecure == true, _serverPort = 443
	//						if _isSecure == false, _serverPort = 80
	//	@param	_protocol Protocol, can be HTTP1_0 or HTTP1_1
	//	@return	Control_OK if connect successfully, error code if failed
	//
  err_t connect(const char* _serverName, uint16_t _serverPort = 0, HTTPClientControl_ProtoVer_t _protocol = HTTP1_0);
  
	//
	//	@brief	Connect to a server with a given name and port number, and using specified protocol
	//	@param	_serverName	Name of the server
	//	@param	_serverPort Port number of the server
	//						if _isSecure == true, _serverPort = 443
	//						if _isSecure == false, _serverPort = 80
	//	@param	_protocol Protocol, can be HTTP1_0 or HTTP1_1
	//	@return	Control_OK if connect successfully, error code if failed
	//
  err_t connect(const String& _serverName, uint16_t _serverPort = 0, HTTPClientControl_ProtoVer_t _protocol = HTTP1_0);
  
  	//
	//	@brief	Connect to a server with a given name and port number, and using specified protocol
	//	@param	_serverAddress	IP address of the server
	//	@param	_serverPort Port number of the server
	//						if _isSecure == true, _serverPort = 443
	//						if _isSecure == false, _serverPort = 80
	//	@param	_protocol Protocol, can be HTTP1_0 or HTTP1_1
	//	@return	Control_OK if connect successfully, error code if failed
	//
  err_t connect(const IPAddress& _serverAddress, uint16_t _serverPort = 0, HTTPClientControl_ProtoVer_t _protocol = HTTP1_0);


  err_t clearRingBuffer();


  err_t setReqHeader(const String name, const String value);
  err_t setReqHeader(const String name, int32_t value);
  err_t setReqHeader(const char* name, const char* value);
  err_t setReqHeader(const char* name, int32_t value);
  err_t setReqHeader(const char* aHeader);
  err_t setReqHeader(const String& aHeader);
  
  
  // /** Send an additional header line.  This can only be called in between the
  // calls to beginRequest and endRequest.
  // @param aHeader Header line to send, in its entirety (but without the
  // trailing CRLF.  E.g. "Authorization: Basic YQDDCAIGES"
  // */
  // void HttpClient::sendHeader(const char* aHeader);

  // void HttpClient::sendHeader(const String& aHeader)
  // { sendHeader(aHeader.c_str()); }

  // err_t setReqHeaderBasicAuth(const char* aUser, const char* aPassword);
  // err_t setReqHeaderBasicAuth(const String& aUser, const String& aPassword);
  
  // /** Send a basic authentication header.  This will encode the given username
  // and password, and send them in suitable header line for doing Basic
  // Authentication.
  // @param aUser Username for the authorization
  // @param aPassword Password for the user aUser
  // */
  // void HttpClient::sendBasicAuth(const char* aUser, const char* aPassword);

  // void HttpClient::sendBasicAuth(const String& aUser, const String& aPassword)
  // { sendBasicAuth(aUser.c_str(), aPassword.c_str()); }
  //
  //	https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization
  //	Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l




  err_t sendRequest();
  //	send those request headers added to the internal buffer


  err_t isEndOfHeader();
  //	-ve error
  //	0 end of header not yet passed; body definitely not read yet
  //	+ve end of header has passed
  //

  //err_t isHeaderAvailable();
  //	+ve - at least one header available for consumption in current buffer
  //	-ve - no (compplete) header available for consumption
  //

  //String getHeaderName();
  //	return String("") if error

  //String getHeaderValue();

  int32_t contentLength();
  //	-ve error (e.g. not all headers read, or content length not available)
  //	+ve content length of body
  //
  //	what if "content-length" not available, but all headers read
  //	??

  err_t bodyAvailable();

  err_t isEndOfRequest();


  int32_t responseStatusCode();
  // /** Get the HTTP status code contained in the response.
  // For example, 200 for successful request, 404 for file not found, etc.
  // */
  // int responseStatusCode();

  err_t setReqHeaderConnClose();
  //	add "Connection: Close" to request header, to end HTTP1.1 connection

  err_t connectionKeepAlive();
  // /** Enables connection keep-alive mode
  // */
  // void connectionKeepAlive();
  //
  //	must be http1.1?

  err_t end();

  err_t get(const char* aURLPath);
  err_t get(const String& aURLPath);
  // /** Connect to the server and start to send a GET request.
  // @param aURLPath     Url to request
  // @return 0 if successful, else error
  // */
  // int HttpClient::get(const char* aURLPath);
  // int HttpClient::get(const String& aURLPath);
  //
  //	add "HTTP/1.0" or "HTTP/1.1" depending on isHTTP11
  
  err_t get(const char* _path,HTTPClientControl_EventHandler _handler);
  //err_t get(const String& _path,HTTPClientControl_EventHandler _handler);
  
  

  err_t post(const char* aURLPath, File* file); //server cannot receive file data, esp32 cannot get response
  err_t post(const char* aURLPath, File* file, const char* filename, const char* fileType); //server cannot receive file data, esp32 cannot get response
  err_t post(const char* aURLPath, const char* aContentType, const char* aBody);
  err_t post(const String& aURLPath, const String& aContentType, const String& aBody);
  err_t post(const char* aURLPath, const char* aContentType, int aContentLength, byte aBody[]); //server can receive file data, esp32 will stuck
  // /** Connect to the server and send a POST request
  // with body and content type
  // @param aURLPath     Url to request
  // @param aContentType Content type of request body
  // @param aBody        Body of the request
  // @return 0 if successful, else error
  // */
  // int HttpClient::post(const char* aURLPath, const char* aContentType, const char* aBody);
  // int HttpClient::post(const String& aURLPath, const String& aContentType, const String& aBody);
  // int HttpClient::post(const char* aURLPath, const char* aContentType, int aContentLength, const byte aBody[]);
  //
  //	add "HTTP/1.0" or "HTTP/1.1" depending on isHTTP11

  err_t put(const char* aURLPath);
  err_t put(const String& aURLPath);
  err_t put(const char* aURLPath, const char* aContentType, const char* aBody);
  err_t put(const String& aURLPath, const String& aContentType, const String& aBody);
  err_t put(const char* aURLPath, const char* aContentType, int aContentLength, const byte aBody[]);

  // /** Connect to the server and start to send a PUT request.
  // @param aURLPath     Url to request
  // @return 0 if successful, else error
  // */
  // int HttpClient::put(const char* aURLPath);
  // int HttpClient::put(const String& aURLPath);

  // /** Connect to the server and send a PUT request
  // with body and content type
  // @param aURLPath     Url to request
  // @param aContentType Content type of request body
  // @param aBody        Body of the request
  // @return 0 if successful, else error
  // */
  // int HttpClient::put(const char* aURLPath, const char* aContentType, const char* aBody);
  // int HttpClient::put(const String& aURLPath, const String& aContentType, const String& aBody);
  // int HttpClient::put(const char* aURLPath, const char* aContentType, int aContentLength, const byte aBody[]);

  err_t patch(const char* aURLPath);
  err_t patch(const String& aURLPath);
  err_t patch(const char* aURLPath, const char* aContentType, const char* aBody);
  err_t patch(const String& aURLPath, const String& aContentType, const String& aBody);
  err_t patch(const char* aURLPath, const char* aContentType, int aContentLength, const byte aBody[]);
  // /** Connect to the server and start to send a PATCH request.
  // @param aURLPath     Url to request
  // @return 0 if successful, else error
  // */
  // int patch(const char* aURLPath);
  // int patch(const String& aURLPath);

  // /** Connect to the server and send a PATCH request
  // with body and content type
  // @param aURLPath     Url to request
  // @param aContentType Content type of request body
  // @param aBody        Body of the request
  // @return 0 if successful, else error
  // */
  // int patch(const char* aURLPath, const char* aContentType, const char* aBody);
  // int patch(const String& aURLPath, const String& aContentType, const String& aBody);
  // int patch(const char* aURLPath, const char* aContentType, int aContentLength, const byte aBody[]);

  err_t del(const char* aURLPath);
  err_t del(const String& aURLPath);
  err_t del(const char* aURLPath, const char* aContentType, const char* aBody);
  err_t del(const String& aURLPath, const String& aContentType, const String& aBody);
  err_t del(const char* aURLPath, const char* aContentType, int aContentLength, const byte aBody[]);

  // /** Connect to the server and start to send a DELETE request.
  // @param aURLPath     Url to request
  // @return 0 if successful, else error
  // */
  // int del(const char* aURLPath);
  // int del(const String& aURLPath);

  // /** Connect to the server and send a DELETE request
  // with body and content type
  // @param aURLPath     Url to request
  // @param aContentType Content type of request body
  // @param aBody        Body of the request
  // @return 0 if successful, else error
  // */
  // int del(const char* aURLPath, const char* aContentType, const char* aBody);
  // int del(const String& aURLPath, const String& aContentType, const String& aBody);
  // int del(const char* aURLPath, const char* aContentType, int aContentLength, const byte aBody[]);

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;
  
  void _preHandler_GetMethod();

  err_t request();

  err_t release();

  RingBuffer& getBuffer();

  // err_t parseHeader(const char* headerData);

  // String getHeaderValue(const char* headerName);

  bool isAvailable();

  bool isHeaderAvailable();
	//	true if end of headers has been read into internal buffer
	//	false otherwise

  bool isHeaderIncomplete();
	//	true if at least one header has been read into internal buffer, but yet end of headers have not been read
	//	false otherwise

  bool isBodyAvailable();

  bool isBodyIncomplete();

  String getHeaderName();

  String getHeaderValue();

  // err_t nextHeader();

  String getBody();

  int getBody_lengthOnly();

  byte* getInternalBufferPtr();

  err_t setBoudary(const char* _boundary);

  bool stop();

  HTTPClientControl_HTTPState_t getState();
  

  //err_t enableScheduler(uint32_t start_time, uint32_t duration, void (*handler)());
  //
  //	handler will be invoked by the following call back functions:
  //	void AsyncHTTPRequest::onReadyStateChange(readyStateChangeCB, void* arg = 0);
  //	void AsyncHTTPRequest::onData(onDataCB, void* arg = 0);
  //

  //err_t setTimeout(ulong_t _timeMS);
  //	void AsyncHTTPRequest::setTimeout(int);
  //	note: the API is in seconds
  //
  //	??
  
};

#endif