#ifndef MOTORCONTROL_H
#define MOTORCONTROL_H

#include "Control.h"
#include "PWMControl.h"
#include "Debug.h"

class PinManager;

class MotorControl : public Control {
protected:

  int pinAIndex = -1;

  int pinBIndex = -1;

  uint16_t currentPWM = 0;

  int8_t currentDirection = 0;

  bool isInit();

  err_t startControl();

  err_t stopControl();

  err_t writePinA(uint32_t _duty);

  err_t writePinB(uint32_t _duty);

public:
  MotorControl();

  err_t request();

  err_t release();

  uint8_t mode = 0;  //0:idle, 1: pwm, 2: rpm

  PWMControl* pwmCtrlA = nullptr;

  PWMControl* pwmCtrlB = nullptr;

  err_t init(int _pinAIndex, int _pinBIndex, bool _permitScheduler = true);

  static int getStaticClsID() {
    return CLS_Motor;
  }

  //void update(ulong_t currentMillis) override;

  err_t move_pwm(uint32_t speed, int8_t direction);

  err_t stop();

  uint32_t getMaxDuty();

  err_t setCurrentPWM(uint16_t _pwm);

  err_t setCurrentDirection(int8_t _direction);

  uint16_t getCurrentPWM();

  int8_t getCurrentDirection();

  friend class PinManager;

  friend class N20Control;
};

#endif
