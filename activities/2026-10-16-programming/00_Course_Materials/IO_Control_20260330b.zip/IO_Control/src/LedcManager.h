#ifndef LEDCMANAGER_H
#define LEDCMANAGER_H

#include "driver/ledc.h"
#include "ServoControl.h"
#include "PWMControl.h"
#include "ToneControl.h"

#ifdef CONFIG_IDF_TARGET_ESP32S3
#define NoOfChannels 8
#elif defined CONFIG_IDF_TARGET_ESP32C3
#define NoOfChannels 6
#endif

class LedcManager {

private:
  LedcManager();

  LedcManager(const LedcManager&) = delete;  //add for singleton logic

  LedcManager& operator=(const LedcManager&) = delete;  //add for singleton logic

public:
  static LedcManager& getInstance();  //get pointer of the singleton

  ledc_timer_config_t timers[4];

  int timerUsedCount[4];

  int timerUsage[4];  //-1 for not used, 0 for servo, 1 for tone, 2 for led

  ledc_channel_config_t channels[NoOfChannels];

  int isChannelUsed[NoOfChannels];  //-1 for not used, other correspond to bineded timer

  int usedPin[NoOfChannels];  //initialized as -1, when a pin is used for a channel, set corresponding value as pin number

  int requestServo(ServoControl& servo);

  int requestPWM(PWMControl& pwm);

  int requestTone(ToneControl& tone);

  void releaseServo(ServoControl& servo);

  void releasePWM(PWMControl& pwm);

  void releaseTone(ToneControl& tone);

  void setPin_servo(ServoControl& servo, int newPin);

  void setPin_pwm(PWMControl& pwm, int newPin);

  void setPin_tone(ToneControl& tone, int newPin);
};

#endif