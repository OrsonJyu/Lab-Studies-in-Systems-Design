#ifndef MPR121CONTROL_H
#define MPR121CONTROL_H


#include "Control.h"
#include "Debug.h"
#include "I2CControl.h"
#include "BinInControl.h"
#include <Adafruit_MPR121.h>

class PinManager;

class MPR121Control : public Control {
protected:

  I2CMasterControl* i2c = 0;
  int i2cAddr;

  BinInControl* irq = 0;
  int irqPin;

  ulong_t local_startTime;
  ulong_t local_interval;
  ControlEventHandler local_handler = 0;

  Adafruit_MPR121 cap;

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

  friend PinManager;

public:

  uint16_t currTouched = 0;
  uint16_t lastTouched = 0;

  MPR121Control();

  err_t request();

  err_t release();

  static int getStaticClsID() {
    return CLS_MPR121;
  }

  err_t init(I2CMasterControl& _i2c, int _i2cAddr, int _irqPin, ulong_t _startTime, ulong_t _interval, ControlEventHandler _handler);

  ulong_t touchedTimeMS[12];  // 0 - means no touched
  ulong_t releasedTimeMS[12];

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;
  void _postHandler() override;

  bool isTouchReleaseEvent() {
    return status & MPR121ControlEventHandler_TouchReleaseEvent;
  }

  err_t setThresholds(uint8_t _touchThres, uint8_t _releaseThres);
};

#endif