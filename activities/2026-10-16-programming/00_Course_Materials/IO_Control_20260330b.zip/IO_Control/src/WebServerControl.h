#ifndef WEBSERVERCONTROL_H
#define WEBSERVERCONTROL_H

#include "Control.h"
#include "Debug.h"
#include <WebServer.h>
#include <LittleFS.h>

typedef void(*apiHandler)();

class WebServerControl : public Control {
protected:
  bool isInit();
  err_t startControl();
  err_t stopControl();
  WebServer* server = nullptr;
public:
  WebServerControl();

  err_t init();

  static int getStaticClsID() {
    return CLS_WEBSERVER;
  }

  err_t request();

  err_t release();

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;
  
  err_t send(int httpCode, const char* contentType, const char* content);

  err_t sendHeader(const char* headerType, const char* headerContent);

  err_t sendFile(const char* filename, const char* contentType);

  String getArg(const char* argName);

  err_t setAPI(const char* apiName, apiHandler hdlr);

  WebServer& getServer();
};

#endif