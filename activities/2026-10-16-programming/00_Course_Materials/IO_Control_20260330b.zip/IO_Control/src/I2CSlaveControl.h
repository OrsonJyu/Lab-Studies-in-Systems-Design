//
//  to do:
//    I2CSlaveControl
//      use ControlEventHandler for Wire.onRequest and Wire.onReceive
//    I2CMasterControl
//      Wire.beginTransmission, Wire.endTransmission, Wire.write
//      Write.read
//      Wire.requestFrom 
//    refer to https://www.designandmake.org/display/DET4M/I2C+Communication+between+ESP8266+and+other+Embedded+Devices for use cases
//
#ifndef I2CSLAVECONTROL_H
#define I2CSLAVECONTROL_H

#include "Control.h"
#include "Debug.h"
#include "Wire.h"

class PinManager;

const uint32_t I2CSlaveControl_defaultClockFreq = 400000;
const uint16_t I2CSlaveControl_ReqBuffer_MaxSize = 128;
const uint16_t I2CSlaveControl_ReceiveBuffer_MaxSize = 128;

class I2CSlaveControl;

struct I2CSlave_Data {
  I2CSlaveControl* i2cSlave;
};

class I2CSlaveControl : public Control {
protected:
  int i2cIndex; //  ESP32C3 only has one i2c and hence must be 0 only 
  int scl;
  int sda;
  uint8_t slaveAddr;
  uint32_t clockFreq;
  TwoWire* twoWire;

	//	relate to TwoWire::OnReceive()
	uint16_t _receivedByteNum;	//	total no of bytes received, due to "onReceive"
	uint8_t _receiveEventCount;	//write	no of onReceive invocations since last update()
	uint16_t _receiveBufferOverFlow;	//	no of bytes overflow in readBuffer since last update()
	
	//	relate to TwoWire::OnRequest()
	uint8_t _requestEventCount;	//	no of onRequest invocations since last update()
	uint8_t _replyBuffer[I2CSlaveControl_ReqBuffer_MaxSize];
	uint8_t _replyByteNum;

  //byte msg;

  bool isInit();  //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()
  
  static void receiveEvent_i2c0(int howMany);
  static void requestEvent_i2c0(); 
  //static void receiveEvent_i2c1(size_t howMany);	//	for i2c controller 1, if exists
  //static void requestEvent_i2c1(); 				//	for i2c controller 1, if exists

public:
  I2CSlaveControl();
  //I2CControl(int _scl, int _sda);

  static int getStaticClsID() {
    return CLS_I2C_SLAVE;
  }

  err_t init(int _i2cIndex,int _scl, int _sda, uint8_t _slaveAddr, uint32_t _clockFreq= I2CSlaveControl_defaultClockFreq,bool _permitScheduler=true);
    //  _i2cIndex can only be 0 for ESP32C3
  err_t setClockFreq(uint32_t clockFreq); 
    //  set clock frequency
    //  must be called before PinManager::request(I2CControl)
  uint32_t getClockFreq()	{	return clockFreq;	}

	char receiveBuffer[I2CSlaveControl_ReceiveBuffer_MaxSize];  //  buffer for holding received data
	
	uint16_t receivedByteNum()  { return _receivedByteNum; }
	uint8_t receiveEventCount()	{	return _receiveEventCount; }
	uint16_t receiveBufferOverflowByteNum()	{	return _receiveBufferOverFlow;	}
	
	uint8_t requestEventCount()	{	return _requestEventCount;	}
	err_t writeReplyBuffer(uint8_t* data,int len);

  TwoWire* getTwoWire();

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;
  void _postHandler() override;

  //byte read();

  //void initTwoWire(int _scl, int _sda, uint32_t clockFreq);

  err_t request();
  err_t release();


//  to do:
//  err_t requestAddr(uint32_t _i2cAddr); //  request _i2cAddr for a slave device
//  err_t releaseAddr(uint32_t _i2cAddr); //  release _i2cAddr for a slave device

  friend PinManager;
  friend I2CSlave_Data;
};

#endif