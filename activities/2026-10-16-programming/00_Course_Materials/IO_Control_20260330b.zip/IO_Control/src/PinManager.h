#include "Control.h"

#include "UARTControl.h"
#include "HWCDCControl.h"

#include "BinInControl.h"
#include "BinOutControl.h"

#include "ADCControl.h"

#include "LedcManager.h"
#include "LedcControl.h"

#include "I2CControl.h"
#include "I2CSlaveControl.h"

#include "OneWireControl.h"

#ifdef USE_WiFiControl
#include "WiFiControl.h"
#endif

#ifdef USE_HTTPClientControl
#include "HTTPClientControl.h"
#endif

#ifdef USE_WebServerControl
#include "WebServerControl.h"
#endif

#ifdef USE_AddrLEDControl
#include "AddrLEDControl.h"
#endif

#ifdef USE_SSD1306Control
#include "SSD1306Control.h"
#endif
#ifdef USE_SH1106Control
#include "SH1106Control.h"
#endif
#ifdef USE_MPR121Control
#include "MPR121Control.h"
#endif

#ifdef USE_DFPlayerMP3Control
#include "DFPlayerMP3Control.h"
#endif

#ifdef USE_SoftWarePlayerMP3Control
#include "SoftwarePlayerMP3Control.h"
#endif

#ifdef USE_MotorControl
#include "MotorControl.h"
#endif

#ifdef USE_EncoderControl
#include "EncoderControl.h"
#endif

#ifdef USE_N20Control
#include "N20Control.h"
#endif

#ifdef USE_UltraSonicControl
#include "UltraSonicControl.h"
#endif

#ifdef USE_MAX7219
#include "MAX7219Control.h"
#endif



#ifdef USE_VL53L0XControl
#include "VL53L0XControl.h"
#endif

#ifdef USE_DHTControl
#include "DHTControl.h"
#endif

#ifdef USE_INMP441Control
#include "INMP441Control.h"
#endif

#ifdef USE_AsyncWebServerControl
//#include "AsyncWebServerControl.h"
#endif

// #ifdef USE_UARTControl
// #include "UARTControl.h"
// #endif

#ifndef PINMANAGER_H
#define PINMANAGER_H

//  define which type of LuatOS ESP32C3 board being used
//#define USE_CH343
//#define USE_USB

#ifdef CONFIG_IDF_TARGET_ESP32S3
const uint8_t pinTotalNum = 49;
#elif defined(CONFIG_IDF_TARGET_ESP32C3)
const uint8_t pinTotalNum = 22;
#endif

class PinManager {
private:
  PinManager();
  PinManager(const PinManager&) = delete;  //add for singleton logic

  PinManager& operator=(const PinManager&) = delete;  //add for singleton logic

public:
  enum { USE_LEDC = 1,
         USE_WIFI,
         USE_I2C,
         USE_ADC,
         USE_BININ,
         USE_BINOUT,
         USE_ADDRLED,
         USE_MP3,
         USE_Motor,
         USE_Encoder,
         a,  //  for Max7219 ??
         USE_UART,
         USE_SPI,
         USE_DHT,
         USE_ONEWIRE,
         USE_INMP441,
         USE_USB,
         USE_FORBIDDEN };

  enum CapabilityType { BinOutCap = 1 << 0,
                        BinInCap = 1 << 1,
                        ADCCap = 1 << 2,
  };


  //`total no of pins

  static PinManager& getInstance();
  //get pointer of the singleton

  bool isPinValid(int pinIndex);
  //  check if pinIndex is valid range, without checking availability


  int caps[pinTotalNum] = { 0 };
  //  caps[i] = capabilities of pin index i
  //  initialize in PinManager::PinManager()
  //  refer to bit flag in CapabilityType
  int pins[pinTotalNum] = { 0 };
  //  pins[i] = availability of pin index i
  //  0 for available, >0 corresponding to different usages



  //
  //  err_t request(Control& ctrl)
  //    request resources (specifically GPIO pin(s)) to allow normal operation of ctrl
  //    ctrl will be active after executing this method with Control_OK status returned
  //  err_t release(Control& ctrl)
  //    release all resources (including GPIO pin(s)) for operation of the ctrl, so that those resources are available for other Controls
  //    ctrl will be inactive after executing this method with Control_OK status returned
  //

  err_t request(Control& _ctrl);

  err_t release(Control& _ctrl);

  err_t request(ADCControl& adcCtrl);

  err_t release(ADCControl& adcCtrl);

  err_t request(BinInControl& binInCtrl);

  err_t release(BinInControl& binInCtrl);

  err_t request(UARTControl& uartCtrl);

  err_t release(UARTControl& uartCtrl);

  err_t request(I2CMasterControl& i2cCtrl);

  err_t release(I2CMasterControl& i2cCtrl);

  err_t request(I2CSlaveControl& i2cCtrl);

  err_t release(I2CSlaveControl& i2cCtrl);

  err_t request(BinOutControl& binOutCtrl);

  err_t release(BinOutControl& binOutCtrl);


  err_t request(ServoControl& servoCtrl);

  err_t release(ServoControl& servoCtrl);

  err_t request(PWMControl& pwmCtrl);

  err_t release(PWMControl& pwmCtrl);

  err_t request(ToneControl& toneCtrl);

  err_t release(ToneControl& toneCtrl);


#ifdef USE_WiFiControl
  err_t request(WiFiControl& wifiCtrl);

  err_t release(WiFiControl& wifiCtrl);
#endif

  err_t request(HWCDCControl& hwcdcCtrl);

  err_t release(HWCDCControl& hwcdcCtrl);


#ifdef USE_INMP441Control
  err_t request(INMP441Control& inmpCtrl);

  err_t release(INMP441Control& inmpCtrl);
#endif


#ifdef USE_MPR121Control
  err_t request(MPR121Control& _mpr121Ctrl);

  err_t release(MPR121Control& _mpr121Ctrl);
#endif


#ifdef USE_AddrLEDControl
  err_t request(AddrLEDControl& inLedCtrl);

  err_t release(AddrLEDControl& inLedCtrl);
#endif

#ifdef USE_SSD1306Control
  err_t request(SSD1306Control& _ssd1306Ctrl);

  err_t release(SSD1306Control& _ssd1306Ctrl);
#endif

#ifdef USE_SH1106Control
  err_t request(SH1106Control& _sh1106Ctrl);

  err_t release(SH1106Control& _sh1106Ctrl);
#endif


#ifdef USE_DFPlayerMP3Control
  err_t request(DFPlayerMP3Control& _mp3Ctrl);

  err_t release(DFPlayerMP3Control& _mp3Ctrl);
#endif


#ifdef USE_DHTControl
  err_t request(DHTControl& dhtCtrl);

  err_t release(DHTControl& dhtCtrl);
#endif


#ifdef USE_EncoderControl
  err_t request(EncoderControl& encoderCtrl);

  err_t release(EncoderControl& encoderCtrl);
#endif


#ifdef USE_MAX7219
  err_t request(MAX7219Control& max7219Ctrl);

  err_t release(MAX7219Control& max7219Ctrl);
#endif

  err_t request(OneWireControl& oneWireCtrl);

  err_t release(OneWireControl& oneWireCtrl);
};

#endif