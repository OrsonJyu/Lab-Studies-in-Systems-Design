#ifndef N20CONTROL_H
#define N20CONTROL_H

#include "Control.h"
#include "Debug.h"
#include "MotorControl.h"
#include "EncoderControl.h"

class PinManager;

struct N20_command {
  uint8_t mode;  //0 for move_pwm, 1 for move_rpm, 2 for stop
};

struct N20_command_movePWM : public N20_command {
  int32_t targetPos;
  uint16_t speed;
};

struct N20_command_moveRPM : public N20_command {
  int32_t targetPos;
  double speed;
};

struct N20_command_stop : public N20_command {
  uint32_t duration;
};

class N20Sequence {
public:
  std::vector<N20_command*> sequence;
  err_t addMovePWM(int32_t _targetPos, uint16_t _speed);
  err_t addMoveRPM(int32_t _targetPos, double _speed);
  err_t addStop(uint32_t _duration);
};

class N20Control : public Control {
protected:
  MotorControl* motor = nullptr;

  EncoderControl* encoder = nullptr;

  int motorPinAIndex = -1;

  int motorPinBIndex = -1;

  int encoderPinAIndex = -1;

  int encoderPinBIndex = -1;

  int8_t cmdDirection = 0;

  int rpmMovementDirection = 0;

  int16_t motorCurrentSpeed = 0;

  N20Sequence localSeq;
  ulong_t playInvokedTime;
  ulong_t seqTargetRelStartTime;
  ulong_t seqExecutedCount = 0;
  int seqRepeatCount = 0;  // -1 for infinite loop
  uint8_t commandPointer = 0;
  bool isCurrentCommandStarted = false;
  ulong_t currentCmdStartTime;

  bool isFineTuning = false;

  int32_t targetCount_fineTune = 0;

  int8_t fineTuneDirection = 0;

  bool _isPlaying;

  int32_t currentNormalizedCount = 0;

  int32_t currentCmdTargetCount = 0;

  bool isInit();

  err_t startControl();

  err_t stopControl();

  int32_t previousCount = 0;

  long initDelayCount = 0;

  bool isInitialized = false;

  bool isInitializing = false;

  bool isMaxCountSet = false;

  bool isMinCountSet = false;

  long stallDelayCount = 600;

  bool isStalling_A = false;

  bool isStalling_B = false;

public:
  N20Control();

  err_t request();

  err_t release();

  err_t init(int _motorPinAIndex, int _motorPinBIndex, int _encoderPinAIndex, int _encoderPinBIndex, bool _permitScheduler = true);

  static int getStaticClsID() {
    return CLS_N20;
  }

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;
  void _postHandler() override;

  MotorControl& getMotor();

  EncoderControl& getEncoder();

  err_t playRelTime(N20Sequence& seq, ulong_t _seqRelStartTime, int _seqRepeatCount);

  err_t playAbsTime(N20Sequence& _seq, ulong_t _seqAbsStartTime, int _seqRepeatCount);

  bool shouldPause = false;

  err_t pauseBeforeNextCommand();

  err_t resume();

  uint32_t getSeqExecutedCount();

  uint32_t getCurrentCommandIndex();

  bool isPlaying();

  bool hasInitialized();

  err_t initialize();

  double currentRPM = -1;

  double targetRPM = -1;

  err_t move_rpm(double _targetRPM, int direction);

  err_t move_pwm(uint32_t speed, int8_t direction);  //for consistency of API

  err_t fineTune(int32_t count, int8_t direction);

  err_t setStalling(int8_t direction);

  err_t resolveStalling(int8_t direction);

  int32_t getCurrentNormalizedCount();

  int32_t getCurrentCmdTargetCount();

  err_t setSeqRepeatCount(int _seqRepeatCount);

  bool isMotorInit();

  friend class PinManager;
};

#endif
