#ifndef MENU_CONTROL_H
#define MENU_CONTROL_H
#include <vector>
#include "Control.h"


class MenuControl;

class Menu;

class MenuItem;

typedef err_t (*ProcessItemCmdHandler)(MenuControl&, MenuItem&, String&);
typedef err_t (*ProcessMenuCmdHandler)(MenuControl&, Menu&, String&);
typedef bool (*ItemConsoleHandler)(MenuControl&, MenuItem&, String&);
typedef bool (*MenuConsoleHandler)(MenuControl&, Menu&, String&);
//  return value:
//      Control_OK  - cmd has no problem, and processed successfully
//      CMDError    - command match, but error in additional parameters; and update menuItem._lastErrMsg
//      CMDNotMatch - command does not match; and update menuItem._lastErrMsg

enum MenuItemType {
  MENU,
  MENU_ITEM,
  MENU_ITEM_RETURN
};

class MenuItem {
protected:
  //	int16_t id = -1;
  MenuItemType type;
  String cmd;
  String desc;
  String _lastErrMsg;
  
  MenuControl* menuControl = nullptr;
  ProcessItemCmdHandler menuItemProcessor = nullptr;
  ItemConsoleHandler itemCHdlr = nullptr;
  
  err_t _processCmdPreCheck(String& _input);	//	perform some prelim checking for processCmd(..)

public:
	MenuItem();

	// MenuItem(String _cmd, String& _desc, ProcessItemCmdHandler _processor, bool isReturn = false, ConsoleHandler cHdlr = nullptr);

	//
	//	@brief	Set MenuControl object which this MenuItem is associated with
	//	@param	_menuControl	MenuControl object
	//	@return	none
	//
	void setMenuControl(MenuControl* _menuControl);
	
	//
	//	@brief	Set type of this MenuItem
	//	@param _type type of this MenuItem, which can be MENU_ITEM or MENU_ITEM_RETURN
	//
	void setType(MenuItemType _type);

	//
	//	@brief	Get type of this MenuItem
	//	@return type of this MenuItem, which can be MENU_ITEM or MENU_ITEM_RETURN
	//
	MenuItemType	getType();

	//
	//	@brief	Set ProcessItemCmdHandler for processing command for this MenuItem
	//	@param	_processor handler to parse command under this MenuItem, to determine whether it is to be activated or not
	//	@return	none
	//	
	void setItemCmdHandler(ProcessItemCmdHandler _processor);

	//
	//	@brief	Set ItemConsoleHandler for this MenuItem when this is activated
	//	@param	_hdlr handler to be invoked while the MenuItem is activated, until _hdlr returns false
	//	@return	none
	//	
	void setItemConsoleHandler(ItemConsoleHandler _hdlr);

	//
	//	@brief	Process an input string with command and optional parameters, in the form <cmd>[,<param1>,...]
	//	@param	_input string to be processed
	//	@return	Control_OK if input with correct <cmd> and optional parameters, MenuControl_CmdError if input with <cmd> correct but error in parameters, MenuControl_CmdNotMatch if <cmd> is not valid
	//	
	virtual err_t processCmd(String& _input);

	//
	//	@brief	Set description for this MenuItem 
	//	@param	_desc	description in String
	//	@return	none
	//	
	void setDesc(String _desc);
	
	//
	//	@brief	Set description for this MenuItem 
	//	@param	_desc	description in const char*
	//	@return	none
	//
	//void setDesc(const __FlashStringHelper char* desc);

	//
	//	@brief	Get description of this MenuItem
	//	@return	description in String
	//
	String getDesc();

	//
	//	@brief	Set error message, which can be retrieved through lastErrMsg()
	//	@param _msg	error message in String
	//	@return	none
	//
	void	setLastErrMsg(String _msg);
	
	//
	//	@brief	Set error message, which can be retrieved through lastErrMsg()
	//	@param _msg	error message in const char*
	//	@return	none
	//
	//void 	setLastErrMsg(const __FlashStringHelper char* _msg);

	//
	//	@brief	Get error message from last call to handler (may be in processCmd() or consoleHandler())
	//	@return	last error message in String
	//
	String 	getLastErrMsg();

	//
	//	@brief Handler which process input from Stream and output to Stream when this MenuItem is active
	//	@param1	_input	input from Stream
	//	@return	true if continue executing consoleHandler next time, false otherwise
	//	
	virtual bool consoleHandler(String& _input);

	//
	//	@brief Set command for this MenuItem
	//	@param1	_cmd	command for this MenuItem; for example "Re", and an input from user can be "Re,10"
	//	@return	none
	//	
	void setCmd(String _cmd);

	//
	//	@brief Get command for this MenuItem, previously set by setCmd(..)
	//	@return	command in String
	//	
	String getCmd();

	//	bool isConsoleHandlerNull();
};

class Menu : public MenuItem {
protected:
	ProcessMenuCmdHandler menuProcessor = nullptr;
	MenuConsoleHandler menuCHdlr = nullptr;
	
	Menu* parentMenu;	//	Menu in previous level
	std::vector<MenuItem*> items;	//	items in this Menu, each item can be a MenuItem or a Menu

public:

	//
	//	@brief	Constructor for Menu
	//
	Menu();

	//
	//	@brief	Set ProcessMenuCmdHandler for processing command for this Menu
	//	@param	_processor handler to parse command under this Menu, to determine whether it is to be activated or not
	//	@return	none
	//	
	void setMenuCmdHandler(ProcessMenuCmdHandler _processor);
	
	//
	//	@brief	Set MenuConsoleHandler for this MenuItem when this is activated
	//	@param	_hdlr handler to be invoked while the MenuItem is activated, until _hdlr returns false
	//	@return	none
	//	
	void setMenuConsoleHandler(MenuConsoleHandler _hdlr);
	
	//
	//	@brief	Process an input string with command and optional parameters, in the form <cmd>[,<param1>,...]
	//	@param	_input string to be processed
	//	@return	Control_OK if input with correct <cmd> and optional parameters, MenuControl_CmdError if input with <cmd> correct but error in parameters, MenuControl_CmdNotMatch if <cmd> is not valid
	//	
	err_t processCmd(String& input);  //override
	
	//
	//	@brief Handler which process input from Stream and output to Stream when this Menu is active
	//	@param1	_input	input from Stream
	//	@return	true if continue executing consoleHandler next time, false otherwise
	//	
	bool consoleHandler(String& _input);	//	override

	//
	//	@brief	Create a MenuItem object and add to this Menu
	//	@param	_type	type of this MenuItem, which can be MENU_ITEM or MENU_ITEM_RETURN; return null if _type == MENU
	//	@return	pointer to MenuItem 
	//	
	MenuItem* createMenuItem(MenuItemType _type);
	
	//
	//	@brief	Create a Menu object and add to this Menu
	//	@return	pointer to Menu 
	//	
	Menu* createMenu();
	
	//
	//	@brief	Delete a MenuItem object and remove from this Menu
	//	@param _menuItem	pointer of the MenuItem (or Menu) object to be deleted; must be returned from createMenuItem(..) or createSubMenu() of this same Menu object
	//	@return	CONTROL_OK if successful, MenuControl_MenuItemNotExist if _menuItem not found and will not be deleted
	//
	err_t deleteMenuItem(MenuItem* _menuItem);

	//
	//	@brief	Print this Menu object to Stream
	//	@param _s	Pointer to Stream displaying the Menu
	//	@return	CONTROL_OK if successful
	//
	err_t printMenu(Stream* _s);
	
	friend class MenuControl;

};


class MenuControl : public Control {
protected:
  Menu* menu = nullptr;	//	first level menu of this MenuControl

  Stream* s;		//	for input/output of this MenuControl
  int currentLevel;	//	?? useful?
  Menu* currMenu;	//	current Menu being displayed
  MenuItem* activeItem = 0;	//	currently active MenuItem, if available

  bool isInitCalled = false;

  bool isInit();
  err_t startControl();
  err_t stopControl();

public:

	MenuControl();

	//
	//	@brief	Constructor for MenuControl, with a Stream object
	//	@param	_s	Stream object for input/output of MenuControl object
	//	@return	None
	//	
	MenuControl(Stream* _s);

	//
	//	@brief	Set a new Stream object for this MenuControl object
	//	@param	_newStream	Stream object for input/output of MenuControl object
	//	@return	None
	//	
	void setOutputStream(Stream* _newStream);

	//
	//	@brief	Set a new Stream object for this MenuControl object
	//	@param	_newStream	Stream object for input/output of MenuControl object
	//	@return	None
	//	
	Menu* getMainMenu();


	// err_t setMainMenu(Menu& _menu);

	//
	//	@brief	Print the current Menu
	//	@return	Control_OK
	//	
	err_t printMenu();

	//
	//	@brief	Process an input string
	//	@param	_input	Command input from stream to be processed
	//	@return	error code
	//
	err_t processCmd(String& _input);
	
	//
	//	@brief	Get Stream of this MenuControl
	//	@return	Stream of this MenuControl if defined, Serial otherwise
	//
	Stream& getStream();

	err_t init();

	static int getStaticClsID() {
		return CLS_MENU;
	}

	err_t request();

	err_t release();

	void _preHandler() override;

	friend class PinManager;
};


#endif