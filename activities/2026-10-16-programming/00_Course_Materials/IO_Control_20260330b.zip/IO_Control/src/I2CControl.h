//
//  to do:
//    I2CSlaveControl
//      use ControlEventHandler for Wire.onRequest and Wire.onReceive
//    I2CMasterControl
//      Wire.beginTransmission, Wire.endTransmission, Wire.write
//      Write.read
//      Wire.requestFrom
//    refer to https://www.designandmake.org/display/DET4M/I2C+Communication+between+ESP8266+and+other+Embedded+Devices for use cases
//
#ifndef I2CCONTROL_H
#define I2CCONTROL_H

#include "Control.h"
#include "Debug.h"
#include "Wire.h"

class PinManager;

const uint32_t I2CMasterControl_defaultClockFreq = 400000;
const uint16_t I2CMasterControl_ReceiveBuffer_MaxSize = 256;


class I2CMasterControl : public Control {
protected:
  int i2cIndex;  //  ESP32C3 only has one i2c and hence must be 0 only
  int scl;
  int sda;
  uint32_t clockFreq;
  TwoWire* twoWire;
  
  uint16_t _receivedByteNum;

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

public:
  I2CMasterControl();
  //I2CControl(int _scl, int _sda);

  static int getStaticClsID() {
    return CLS_I2C;
  }

  err_t init(int _i2cIndex, int _scl, int _sda, uint32_t _clockFreq = I2CMasterControl_defaultClockFreq, bool _permitScheduler = true);
	//  _i2cIndex can only be 0 for ESP32C3

  err_t request();
  err_t release();

  err_t setClockFreq(uint32_t clockFreq);
	//  set clock frequency
	//  must be called before PinManager::request(I2CControl)
  uint32_t getClockFreq() {
    return clockFreq;
  }
  
	char receiveBuffer[I2CMasterControl_ReceiveBuffer_MaxSize];  //  buffer for holding received data
	
	uint16_t receivedByteNum()  { return _receivedByteNum; }
  
	//void update(ulong_t currentMillis) override;
	void _preHandler() override;

	err_t beginTransmission(uint16_t addr);	//	adapt from TwoWire::beginTransmission()
	
	err_t endTransmission(bool stop=true);	//	adapt from TwoWire::endTransmission()
	
	//err_t write(byte msg, uint8_t slaveAddr);
	
	//int write(uint16_t slaveAddr, byte msg);	//	no need to use beginTransmission and endTransmission
	
	int write(uint8_t val);				//	must execute "beginTransmission()" before
	int write(uint8_t* data,int len);	//	must execute "beginTransmission()" before
	// int write(const char* msg);			//	must execute "beginTransmission()" before
	
	int requestFrom(uint16_t addr, uint8_t quantity, bool stop=true);	// adapt from TwoWire::requestFrom()

  TwoWire* getTwoWire();

  //void initTwoWire(int _scl, int _sda, uint32_t clockFreq);

  //  to do:
  //  err_t requestAddr(uint32_t _i2cAddr); //  request _i2cAddr for a slave device
  //  err_t releaseAddr(uint32_t _i2cAddr); //  release _i2cAddr for a slave device

  friend PinManager;
};

#endif