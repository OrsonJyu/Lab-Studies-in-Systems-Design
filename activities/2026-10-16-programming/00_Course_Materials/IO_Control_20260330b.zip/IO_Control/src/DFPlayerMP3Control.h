#include <cstdint>
#ifndef DFPlayerMP3CONTROL_H
#define DFPlayerMP3CONTROL_H

#include "Control.h"
#include "Debug.h"
#include "DFRobotDFPlayerMini.h"
#include "BinInControl.h"
#include "UARTControl.h"
#include "RingBuffer.h"

class PinManager;

struct DFPlayerCommand {
  uint8_t index;  //refer to the MP3 to be played, 0 means do not play for a specific duration
  uint8_t volume;
  ulong_t duration;
  bool loopAfterEnd;  //When MP3 ends earlier than target duration, it will either play again or play nothing until duration ends
  uint32_t fadeInTime;
  uint32_t fadeOutTime;
};

class DFPlayerSequence {
public:
  std::vector<DFPlayerCommand*> sequence;

  err_t addCommand(uint8_t _index, uint8_t _volume, uint32_t _duration, bool _loopAfterEnd = false, uint32_t _fadeInTime = 0, uint32_t _fadeOutTime = 0);

  err_t addPause(uint32_t _duration);

  err_t clearCommand();
};

class DFPlayerMP3Control : public Control {
protected:
  UARTControl* uart;

  bool mp3CtrlIsInit = false;

  uint8_t rx_pin;

  uint8_t tx_pin;

  uint8_t busy_pin;

  err_t startControl();

  err_t stopControl();

  void printDetail(uint8_t type, int value);

  BinInControl* busyPinCtrl = nullptr;

  DFPlayerSequence localSeq;
  ulong_t playInvokedTime;
  ulong_t seqTargetRelStartTime;
  ulong_t seqExecutedCount = 0;
  int seqRepeatCount = 0;  // -1 for infinite loop
  uint8_t commandPointer = 0;
  bool isCurrentCommandStarted = false;
  ulong_t currentCmdStartTime;
  bool _isPlaying = false;
  bool isSeqVolSet = false;

  uint8_t currentVolume = 0;

  enum LastCommand {
    MP3_PLAY,
    MP3_NEXT,
    MP3_SET_VOL,
    MP3_PAUSE
  };

  LastCommand lastCmd;

  int8_t lastCmdCaller = -1; // 0: called by user, 1: called by sequence

  // struct MP3_EVENT {
  //   uint8_t _lastCmd;
  //   uint8_t type;
  //   int16_t value; 
  // };

  SemaphoreHandle_t mp3EventInfoRBMutex;

  // RingBuffer // command, type, value
  RingBuffer* mp3EventInfoRB = nullptr;

  bool shouldCheckACK = false;

public:
  DFPlayerMP3Control();

  DFRobotDFPlayerMini* myDFPlayer = nullptr;

  DFRobotDFPlayerMini& getPlayer();

  err_t init(UARTControl& _uart /*uint8_t _rx, uint8_t _tx*/, uint8_t _busyPin, size_t _mp3EventBufferSize = 1024);

  static int getStaticClsID() {
    return CLS_DFPlayerMP3;
  }

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  bool isInit();

  err_t request();

  err_t release();

  bool shouldPause = false;

  err_t playRelTime(DFPlayerSequence& _seq, ulong_t _seqRelStartTime, int _seqRepeatCount);

  err_t playAbsTime(DFPlayerSequence& _seq, ulong_t _seqAbsStartTime, int _seqRepeatCount);

  err_t pauseBeforeNextCommand();

  err_t resume();

  uint32_t getSeqExecutedCount();

  uint32_t getCurrentCommandIndex();

  bool isPlaying();

  err_t play(uint8_t _index, int8_t caller = 0);

  err_t playNext(int8_t caller = 0);

  err_t setVolume(uint8_t _vol, int8_t caller = 0);

  err_t pause(int8_t caller = 0);

  void writeMP3EventInfo(LastCommand _lastCmd, int8_t _lastCmdCaller, uint8_t type, uint8_t value);

  err_t readMP3EventInfo(uint8_t* _data);

  bool eventInfoAvailable();

  friend class PinManager;
};

#endif
