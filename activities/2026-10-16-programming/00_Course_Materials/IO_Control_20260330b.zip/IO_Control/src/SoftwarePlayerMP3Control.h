#ifndef SOFTWAREPLAYERMP3CONTROL_H
#define SOFTWAREPLAYERMP3CONTROL_H

#include <AudioFileSourceHTTPStream.h>
#include <AudioFileSourceBuffer.h>
#include <AudioGeneratorMP3.h>
#include <AudioOutputI2S.h>
#include <AudioFileSourceLittleFS.h>
#include <AudioFileSourceSD.h>

#include "PinManager.h"
#include "Control.h"
#include "WiFiControl.h"
#include "Debug.h"
#include <LittleFS.h>

class PinManager;

class SoftwarePlayerMP3Control : public Control {
protected:
  int pin_BCLK = -1;  // I2S Speaker Serial Clock

  int pin_LRC = -1;  // I2S Speaker Left Right Clock

  int pin_DIN = -1;  // I2S Speaker Serial Data

  AudioGeneratorMP3 *mp3 = nullptr;

  AudioFileSourceHTTPStream *httpFile = nullptr;

  AudioFileSourceLittleFS *fsFile = nullptr;

  AudioFileSourceSD* sdFile = nullptr;

  AudioFileSourceBuffer *buff = nullptr;

  AudioOutputI2S *out = nullptr;

  bool mp3CtrlIsInit = false;

  bool isInit() {
	return mp3CtrlIsInit;
  }

  err_t startControl() {
  Serial.println("SoftwarePlayerMP3Control::startControl() is called");
  if (isActive()) {
    Serial.println("SoftwarePlayerMP3Control is active already");
    return Control_ActiveAlready;
  }

  // SD.begin();

  out = new AudioOutputI2S(0, 0, 8, 1); //abp pll
  out->SetPinout(pin_BCLK, pin_LRC, pin_DIN);
  mp3 = new AudioGeneratorMP3();

  setActive(true);

  enableScheduler(0, 10, nullptr);

  return Control_OK;
  }

  err_t stopControl(){
  if (!isActive()) {
    //	cannot stop if not active
    return Control_NotActive;
  }

  delete mp3;

  delete httpFile;

  delete fsFile;

  delete buff;

  delete out;

  disableScheduler();

  setActive(false);

  return Control_OK;
  }

  bool isMP3Finished = true;

public:
  SoftwarePlayerMP3Control() {
   clsID = CLS_SoftwarePlayerMP3;
  }

  err_t init(int _pin_BCLK, int _pin_LRC, int _pin_DIN) {
  if (isActive()) {  //  already active, and should not be initialized
    return Control_ActiveAlready;
  }

  if (mp3 != nullptr) {
    delete mp3;
    mp3 = nullptr;
  }

  if (httpFile != nullptr) {
    delete httpFile;
    httpFile = nullptr;
  }

  if (fsFile != nullptr) {
    delete fsFile;
    fsFile = nullptr;
  }

  if (sdFile != nullptr) {
    delete sdFile;
    sdFile = nullptr;
  }

  if (buff != nullptr) {
    delete buff;
    buff = nullptr;
  }

  if (out != nullptr) {
    delete out;
    out = nullptr;
  }

  pin_BCLK = _pin_BCLK;

  pin_LRC = _pin_LRC;

  pin_DIN = _pin_DIN;

  setPermitScheduler(true);  //must have scheduler

  mp3CtrlIsInit = true;

  err_t err = request();

  return err;
  }

  static int getStaticClsID() {
    return CLS_SoftwarePlayerMP3;
  }

  //void update(ulong_t currentMillis) override;
  void _preHandler() override {
	if (mp3 != nullptr) {
     if (mp3->isRunning()) {
      if (!mp3->loop()) {
        mp3->stop();
        isMP3Finished = true;
        status |= MP3EventHandler_FinishedPlaying;
      }
    }
  }
  Control::_preHandler();
  }

  err_t request(){
  PinManager *pmgr = &PinManager::getInstance();
  if (pmgr->pins[pin_BCLK] == 0 && pmgr->pins[pin_LRC] == 0 && pmgr->pins[pin_DIN] == 0) {  //pins are not being used
    pmgr->pins[pin_BCLK] = PinManager::USE_MP3;
    pmgr->pins[pin_LRC] = PinManager::USE_MP3;
    pmgr->pins[pin_DIN] = PinManager::USE_MP3;

    err_t err = pmgr->request(*this);

    return err;
  } else {  // pins are not available
    Serial.println("(SoftwarePlayerMP3Control) Some pins are not available");
    return Control_PinNotAvailable;
  }
  }

  err_t release() {
  PinManager *pmgr = &PinManager::getInstance();
  pmgr->pins[pin_BCLK] = 0;
  pmgr->pins[pin_LRC] = 0;
  pmgr->pins[pin_DIN] = 0;

  err_t err = pmgr->release(*this);
  return err;
  }

  err_t stream(const char *url, uint16_t buffSize, WiFiControl &wifiCtrl){// should verify wifi connection before streaming
   if (wifiCtrl.isInit()) {
    delete httpFile;
    httpFile = new AudioFileSourceHTTPStream(url);
    delete buff;
    buff = new AudioFileSourceBuffer(httpFile, buffSize);
    mp3->begin(buff, out);
    return Control_OK;
  } else {
    Serial.println("(SoftwarePlayerMP3Control)  WiFi is not init");
    return SoftwarePlayerMP3Control_WiFiNotInit;
  }
  }  

  err_t playFromFS(const char *filename) {
  if (LittleFS.begin()) {
    delete fsFile;
    fsFile = new AudioFileSourceLittleFS(filename);
    mp3->begin(fsFile, out);
    return Control_OK;
  } else {
    return SoftwarePlayerMP3Control_LittleFSFailure;
  }
  }

  err_t playFromSD(const char* filename) {
  if (SD.begin()) {
    delete sdFile;
    sdFile = new AudioFileSourceSD(filename);
    mp3->begin(sdFile, out);
    return Control_OK;
  } else {
    return SoftwarePlayerMP3Control_SDFailure;
  }

  // delete sdFile;
  // sdFile = new AudioFileSourceSD(filename);
  // mp3->begin(sdFile, out);
  // return Control_OK;
  }

  friend class PinManager;
};

#endif