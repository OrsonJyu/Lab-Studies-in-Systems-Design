#ifndef MAX7219CONTROL_H
#define MAX7219CONTROL_H

#include "Control.h"
#include "Debug.h"

//#include <MD_Parola.h>
#include <MD_MAX72xx.h>
#include <SPI.h>

class MAX7219BitMap {
public:
  uint8_t bitMap[8];
};

struct MAX7219_command {
  uint32_t duration;
  MAX7219BitMap bitMap;
};

class MAX7219Sequence {
public:
  std::vector<MAX7219_command*> sequence;
  err_t addShowBitMap(uint32_t _duration, MAX7219BitMap& _bitMap);
};

struct MAX7219SeqObj {
  uint16_t index;
  MAX7219Sequence localSeq;
  ulong_t playInvokedTime;
  ulong_t seqTargetRelStartTime;
  ulong_t seqExecutedCount;
  int seqRepeatCount;
  int commandPointer = 0;
  bool isCurrentCommandStarted = false;
  ulong_t currentCmdStartTime;
  bool shouldPause = false;
};

class PinManager;

class MAX7219Control : public Control {
protected:

  MD_MAX72XX* mx;

  MAX7219BitMap* bitMaps;  //pointer for an array with dynamic size based on number of modules

  int dinPinIndex = -1;

  int clkPinIndex = -1;

  int csPinIndex = -1;

  uint16_t noOfModule = 0;

  uint8_t hardwareType = 0;

  char msgBuf[30];  //message to scroll

  char* msgCharPtr = 0;  //pointing to specific char in the message

  uint8_t charBuf[8];  //one byte for one column of char

  uint8_t msgCharColIndex = 0;  //index of specific columun of the char

  uint8_t currentCharWidth = 0;  // number of columns of the current char to scroll

  int scrollDirection = 0;

  uint32_t scrollInterval = 0;

  bool shouldScrollLoop = false;

  bool currentCharDone = true;

  bool currentMsgDone = true;

  bool shouldClearScroll = false;

  uint32_t lastScrollTime = 0;

  uint8_t emptyShiftCount = 0;

  uint8_t noOfColForScroll;

  bool isInit();

  err_t startControl();

  err_t stopControl();

  std::vector<MAX7219SeqObj*> seqObjs;

  uint16_t updateCount = 0;
  bool shouldCurrentSeqObjBeDeleted;
  

public:
  MAX7219Control();

  err_t init(int _dinPinIndex, int _clkPinIndex, int _csPinIndex, uint16_t _noOfModule, uint8_t _hardwareType, bool _permitScheduler = true);

  static int getStaticClsID() {
    return CLS_MAX7219;
  }

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;
  void _postHandler() override;

  err_t request();

  err_t release();

  err_t setBitMap(MAX7219BitMap& _max7219BitMap, uint16_t targetModule);

  err_t showBitMap();

  void reverseCharArray(char* str);

  err_t scrollText(char* pMsg, int direction, uint32_t timeInterval, bool shouldLoop);

  err_t stopScrollText();

  err_t printText(uint8_t modStart, uint8_t modEnd, char* pMsg, uint16_t charSpacing);

  int playRelTime(uint8_t index, MAX7219Sequence& seq, ulong_t _seqRelStartTime, unsigned int _seqRepeatCount);

  int playAbsTime(uint8_t index, MAX7219Sequence& seq, ulong_t _seqAbsStartTime, unsigned int _seqRepeatCount);

  err_t pauseBeforeNextCommand(int seqObjID);

  err_t resume(int seqObjID);

  friend class PinManager;
};

#endif
