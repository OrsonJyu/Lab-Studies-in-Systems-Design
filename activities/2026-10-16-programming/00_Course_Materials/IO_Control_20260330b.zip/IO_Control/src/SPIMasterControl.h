#ifndef SPICONTROL_H
#define SPICONTROL_H

#include "Control.h"
#include "Debug.h"
#include <SPI.h>

class PinManager;

class SPIControl : public Control {
protected:
  SPIClass* spi;

  uint32_t clkFreq = 0;

  int mosiPinIndex = -1;

  int misoPinIndex = -1;

  int clkPinIndex = -1;

  int cs1PinIndex = -1;

  int cs2PinIndex = -1;

  int cs3PinIndex = -1;

  bool isInit();

  err_t startControl();

  err_t stopControl();

public:
  SPIControl();

  err_t init(uint32_t _clkFreq, int _mosiPinIndex, int _misoPinIndex, int _clkPinIndex, int _cs1PinIndex, int _cs2PinIndex, int _cs3PinIndex, bool _permitScheduler = true);

  static int getStaticClsID() {
    return CLS_SPI;
  }

  //void update(ulong_t currentMillis) override;

  err_t request();

  err_t release();

  byte sendByte(int target, byte data);

  friend class PinManager;
};

#endif
