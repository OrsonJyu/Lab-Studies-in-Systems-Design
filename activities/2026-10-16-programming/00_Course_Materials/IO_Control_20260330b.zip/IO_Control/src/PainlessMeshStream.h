#include <Arduino.h>
#include "painlessMesh.h"
#include <freertos/semphr.h>

class PainlessMeshStream : public Stream {
private:
  painlessMesh* mesh;

  int32_t targetNodeID = -1;

  // Buffers
  String rxBuffer;  // Input (Thread safe)
  String txBuffer;  // Output (accumulates print() calls)

  // Thread safety
  SemaphoreHandle_t lock;

public:
  PainlessMeshStream() {
    lock = xSemaphoreCreateMutex();
    rxBuffer.reserve(512);  // Pre-allocate to reduce fragmentation
    txBuffer.reserve(512);
  }

  ~PainlessMeshStream() {
    delete mesh;
    if (lock) vSemaphoreDelete(lock);
  }

  void init(String meshID, String meshPassword, uint32_t port, uint32_t targetID = 0) {
    mesh = new painlessMesh();
    mesh->init(meshID.c_str(), meshPassword.c_str(), port, WIFI_AP_STA, 0);
    targetNodeID = targetID;
  }

  void setTarget(uint32_t targetID) {
    xSemaphoreTake(lock, portMAX_DELAY);
    targetNodeID = targetID;
    rxBuffer = "";
    txBuffer = "";
    xSemaphoreGive(lock);
  }

  // --- Stream Interface (Read) ---

  int available() override {
    xSemaphoreTake(lock, portMAX_DELAY);
    int len = rxBuffer.length();
    xSemaphoreGive(lock);
    return len;
  }

  int read() override {
    xSemaphoreTake(lock, portMAX_DELAY);
    if (rxBuffer.length() == 0) {
      xSemaphoreGive(lock);
      return -1;
    }
    // Read first char and remove it to save memory
    char c = rxBuffer[0];
    rxBuffer.remove(0, 1);
    xSemaphoreGive(lock);
    return c;
  }

  int peek() override {
    xSemaphoreTake(lock, portMAX_DELAY);
    if (rxBuffer.length() == 0) {
      xSemaphoreGive(lock);
      return -1;
    }
    int c = rxBuffer[0];
    xSemaphoreGive(lock);
    return c;
  }

  // --- Stream Interface (Write) ---

  // Accumulate bytes into a buffer instead of sending immediately
  size_t write(uint8_t c) override {
    if (targetNodeID == -1) return 0;

    txBuffer += (char)c;

    // Flush automatically on newline (standard Stream behavior)
    if (c == '\n') {
      flush();
    }
    return 1;
  }

  size_t write(const uint8_t* buffer, size_t size) override {
    if (targetNodeID == -1) return 0;

    // Efficiently append block
    char temp[size + 1];
    memcpy(temp, buffer, size);
    temp[size] = '\0';
    txBuffer += temp;

    // Check if we should flush (if buffer is getting too big or contains newline)
    if (txBuffer.length() > 1024 || memchr(buffer, '\n', size)) {
      flush();
    }
    return size;
  }

  // Actually send the packet
  void flush() override {
    if (targetNodeID == -1 || txBuffer.length() == 0) return;
    if (targetNodeID == 0) {
      mesh->sendBroadcast(txBuffer);
    } else {
      mesh->sendSingle(targetNodeID, txBuffer);
    }
    txBuffer = "";
  }

  // --- Interface for painlessMesh receive Callbacks ---

  void feedMessage(const char* data, size_t len) {
    xSemaphoreTake(lock, portMAX_DELAY);
    // Append new data to the end of the buffer
    rxBuffer += String(data).substring(0, len);
    // Optional: Add newline here if your parser expects line-endings but the WS client doesn't send them
    rxBuffer += "\n";
    xSemaphoreGive(lock);
  }

  painlessMesh& getMesh() {
  return *mesh;
}
};