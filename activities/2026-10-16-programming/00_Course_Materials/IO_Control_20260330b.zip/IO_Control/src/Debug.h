#ifndef DEBUG_H
#define DEBUG_H

#include <assert.h>
//#define NDEBUG    //  enable this to turn off assert()

//#define DEBUG_SERIAL  // Comment out this line to disable Serial.println statements

#ifdef DEBUG_SERIAL
#define DEBUG_PRINT(x) Serial.print(x)
#define DEBUG_PRINTLN(x) Serial.println(x)
#define DEBUG_PRINTF(format,...) Serial.printf(format, __VA_ARGS__)
#else
#define DEBUG_PRINT(x)
#define DEBUG_PRINTLN(x)
#define DEBUG_PRINTF(format,...) 
#endif


#endif  // DEBUG_H