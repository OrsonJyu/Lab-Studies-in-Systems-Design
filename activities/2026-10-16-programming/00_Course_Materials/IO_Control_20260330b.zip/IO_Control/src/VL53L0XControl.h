#ifndef VL53L0XCONTROL_H
#define VL53L0XCONTROL_H

#include "Control.h"
#include "Debug.h"
#include "I2CControl.h"
#include <VL53L0X.h>

class VL53L0XControl : public Control {
protected:
  I2CMasterControl* i2c = 0;
  
  int i2cAddr = -1;

  VL53L0X* sensor;

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

public:

  VL53L0XControl();

  err_t init(I2CMasterControl& _i2c);

  ~VL53L0XControl();

  static int getStaticClsID() {
    return CLS_VL53L0X;
  }

  err_t request();

  err_t release();

  VL53L0X* getSensor();

  int16_t measureDistance();

  friend class PinManager;
};


#endif