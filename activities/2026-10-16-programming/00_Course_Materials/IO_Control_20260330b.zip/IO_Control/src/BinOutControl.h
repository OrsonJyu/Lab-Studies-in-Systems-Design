#ifndef BINOUTCONTROL_H
#define BINOUTCONTROL_H

#include "Control.h"
//#include "Debug.h"

struct BinOutCommand {
  uint8_t state;
  ulong_t duration;
};

class BinOutSequence {
protected:

public:
  std::vector<BinOutCommand*> sequence;

  err_t addSetState(uint32_t _duration, uint8_t _state);
};

class BinOutControl : public Control {
protected:
  int pinIndex;  //  -1 if not initialized
  int state;     //	current state of this output pin

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

  //  for playing BinOutSequence
  //std::vector<BinOutSequence> currentSequences; //  for sequence playback
  BinOutSequence localSeq;  //  a local copy of sequence for playback
  ulong_t playInvokedTime;  //  time when last playRelTime() was invoked
                            //  (ulong_t) -1 when last playRelTime() has been completed and nothing to play
  //ulong_t seqTargetStartTime;
  ulong_t seqTargetRelStartTime;  //  starting time to play the sequence relative to playInvokedTime
  int seqRepeatCount = 0;         // -1 for infinite loop

  uint32_t seqExecutedCount = 0;         //  how many times the current sequence is being played so far
  uint32_t commandPointer = 0;           //  pointer to the current active command
                                         //  Tony: why uint8_t ? does this correspond to the curent command when "BinOutControlEventHandler_OneSeqNewCmdStarted" is returned?
  bool isCurrentCommandStarted = false;  //  Tony: what is this for?
  ulong_t currentCmdStartTime;

  bool _isPlaying;

public:
  BinOutControl();
  //BinOutControl(int _pinIndex);
  err_t init(uint8_t _pinIndex, uint8_t _initState = LOW, bool _permitScheduler = true);
  static int getStaticClsID() {
    return CLS_BINOUT;
  }

  err_t write(uint8_t val);
  uint8_t read();  //	get the current state of this BinOutControl

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  bool isAllSeqStarted() {
    return status & BinOutControlEventHandler_AllSeqStarted;
  }
  bool isAllSeqEnded() {
    return status & BinOutControlEventHandler_AllSeqEnded;
  }
  bool isOneSeqStarted() {
    return status & BinOutControlEventHandler_OneSeqStarted;
  }
  bool isOneSeqNewCmdStarted() {
    return status & BinOutControlEventHandler_OneSeqNewCmdStarted;
  }
  bool isOneSeqPaused() {
    return status & BinOutControlEventHandler_OneSeqPaused;
  }
  bool isOneSeqEnded() {
    return status & BinOutControlEventHandler_OneSeqEnded;
  }

  err_t playRelTime(BinOutSequence& _seq, uint32_t _seqRelStartTime, int32_t _seqRepeatCount);
  //  play seq starting from _seqRelStartTime relative to current time
  //  _seqRepeatCount == 0 means repeat infinitely

  err_t playAbsTime(BinOutSequence& _seq, uint32_t _seqAbsStartTime, int32_t _seqRepeatCount);

  bool isPlaying() {
    return _isPlaying;
  }

  bool shouldPause = false;

  err_t pauseBeforeNextCommand();

  err_t resume();

  int32_t getSeqExecutedCount();

  int32_t getCurrentCommandIndex();

  err_t request();

  err_t release();

  //int play(BinOutSequence& seq, ulong_t _seqStartTime, unsigned int _seqRepeatCount, ulong_t _startTime, ulong_t _interval, ControlEventHandler _handler);

  //int playStop();

  friend class PinManager;
};

#endif