#ifndef TONECONTROL_H
#define TONECONTROL_H

#include "LedcControl.h"

//
//	adapted from https://github.com/Dlloydev/ESP32-ESP32S2-AnalogWrite/blob/main/src/pwmWrite.cpp
//
enum NoteBaseType { NoteBaseC = 4186,
                    NoteBaseCS = 4435,
                    NoteBaseD = 4699,
                    NoteBaseDS = 4978,
                    NoteBaseE = 5274,
                    NoteBaseF = 5588,
                    NoteBaseFS = 5920,
                    NoteBaseG = 6272,
                    NoteBaseGS = 6645,
                    NoteBaseA = 7040,
                    NoteBaseAS = 7459,
                    NoteBaseB = 7902
};


struct Tone_command {
  uint8_t mode;  //0 for setTone, 1 for setNote, 2 for interpolation
  uint32_t duration;
};

struct Tone_command_setTone : public Tone_command {
  uint32_t freq;
  uint16_t duty;
};

struct Tone_command_setNote : public Tone_command {
  NoteBaseType note;
  uint8_t octave;
  uint16_t duty;
};

struct Tone_command_interpolate : public Tone_command {
  uint32_t startFreq;
  uint32_t endFreq;
  uint16_t startDuty;
  uint16_t endDuty;
};

class ToneSequence {
public:
  std::vector<Tone_command*> sequence;
  err_t addSetTone(uint32_t _duration, uint32_t _freq, uint16_t _duty);
  err_t addSetNote(uint32_t _duration, NoteBaseType _note, uint8_t _octave, uint16_t _duty);
  err_t addInterpolateTone(uint32_t _duration, uint32_t _startFreq, uint32_t _endFreq, uint16_t _startDuty, uint16_t _endDuty);
};

class ToneControl : public LedcControl {
protected:
  //bool isInit();         //  refer to comments on Control::init()
  //err_t startControl();  //  refer to comments on Control::startControl()
  //err_t stopControl();   //  refer to comments on Control::stopControl()

  ToneSequence localSeq;

  uint32_t seqTargetRelStartTime;

  int seqRepeatCount = 0;  // -1 for infinite loop

  uint8_t commandPointer = 0;
  bool isCurrentCommandStarted = false;
  

  uint32_t currentCmdStartTime;

public:
  ToneControl();
  //ToneControl(int _pinIndex);

  err_t init(uint8_t _pinIndex, bool _permitScheduler = true);

  ~ToneControl();  // no public constructor

  static int getStaticClsID() {
    return CLS_TONE;
  }

  uint32_t getNoteFreq(NoteBaseType _notebase, uint8_t octave);  //	convert notebase and octave to frequency

  err_t setTone(uint32_t freq, uint16_t duty);  //	if freq==0, duty will be set to zero

  err_t setNote(NoteBaseType _notebase, uint8_t octave, uint16_t duty);  //	if octave >8, duty will be set to zero

  err_t playRelTime(ToneSequence& _seq, uint32_t _seqRelStartTime, int32_t _seqRepeatCount);

  err_t playAbsTime(ToneSequence& _seq, uint32_t _seqAbsStartTime, int32_t _seqRepeatCount);

  bool shouldPause = false;

  err_t pauseBeforeNextCommand();

  err_t resume();

  int32_t getSeqExecutedCount();

  int32_t getCurrentCommandIndex();

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  err_t request();

  err_t release();

  friend class PinManager;
};

#endif