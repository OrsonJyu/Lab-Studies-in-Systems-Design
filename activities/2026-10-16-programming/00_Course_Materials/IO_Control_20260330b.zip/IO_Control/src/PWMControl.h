#ifndef PWMCONTROL_H
#define PWMCONTROL_H

#include "LedcControl.h"

struct PWM_command {
  uint8_t mode;  //0 for setDuty, 1 for fade
  uint32_t duration;
};

struct PWM_command_setDuty : public PWM_command {
  uint16_t duty;
};

struct PWM_command_fade : public PWM_command {
  uint16_t startDuty;
  uint16_t endDuty;
};

class PWMSequence {
public:
  std::vector<PWM_command*> sequence;
  err_t addSetDuty(uint32_t _duration, uint16_t _duty);
  err_t addFade(uint32_t _duration, uint16_t _startDuty, uint16_t _endDuty);
  int stop();
};

class PWMControl : public LedcControl {
protected:
  //bool isInit();         //  refer to comments on Control::init()
  //err_t startControl();  //  refer to comments on Control::startControl()
  //err_t stopControl();   //  refer to comments on Control::stopControl()

  //std::vector<PWMSequence> currentSequences;
  PWMSequence localSeq;

  uint32_t seqTargetRelStartTime;

  int seqRepeatCount = 0;  // -1 for infinite loop
  uint8_t commandPointer = 0;

  bool isCurrentCommandStarted = false;
  uint32_t currentCmdStartTime;

public:
  //  Note:
  //      a method to change frequency and duty resolution
  //      all ServoControl share the same timer
  PWMControl();
  //PWMControl(int _pinIndex);

  err_t init(uint8_t _pinIndex, bool _permitScheduler = true);
  //void init(int _pinIndex, ulong_t _startTime, ulong_t _interval, ControlEventHandler _handler);

  ~PWMControl();  //  no public constructor

  static int getStaticClsID() {
    return CLS_PWM;
  }

  //sequence related variables and functions

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  err_t playRelTime(PWMSequence& seq, uint32_t _seqRelStartTime, int32_t _seqRepeatCount);

  err_t playAbsTime(PWMSequence& _seq, uint32_t _seqAbsStartTime, int32_t _seqRepeatCount);

  bool shouldPause = false;

  err_t pauseBeforeNextCommand();

  err_t resume();

  int32_t getSeqExecutedCount();

  int32_t getCurrentCommandIndex();

  //bool isPlaying()	{	return _isPlaying;	}
  //int playStop();    //not yet implemented

  err_t request();

  err_t release();

  friend class PinManager;
};


#endif