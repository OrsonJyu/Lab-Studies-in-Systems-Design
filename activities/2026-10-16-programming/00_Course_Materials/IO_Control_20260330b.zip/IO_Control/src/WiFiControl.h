#ifndef WIFICONTROL_H
#define WIFICONTROL_H

#include "Control.h"
#include "Debug.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include "RingBuffer.h"
//#include <semph.h>

enum WiFiControlWiFiMode_t { WiFiControlWiFiModeAP = 0,
                             WiFiControlWiFiModeSTA = 1,
                             WiFiControlWiFiModeAPSTA = 2,
							 WiFiControlWiFiOff=-1
};

//	available events relating to WiFi (and also ethernet and PPP) come from arduino_event_id_t in https://github.com/espressif/arduino-esp32/blob/master/libraries/Network/src/NetworkEvents.h
enum WiFiContolEvent_t {
		WiFiControl_EVENT_NONE = ARDUINO_EVENT_NONE ,   
		

		//	ETH
		WiFiControl_EVENT_ETH_START = ARDUINO_EVENT_ETH_START,                                // ESP32 ethernet start
		WiFiControl_EVENT_ETH_STOP = ARDUINO_EVENT_ETH_STOP,                                  // ESP32 ethernet stop
		WiFiControl_EVENT_ETH_CONNECTED = ARDUINO_EVENT_ETH_CONNECTED,                        // ESP32 ethernet phy link up
		WiFiControl_EVENT_ETH_DISCONNECTED = ARDUINO_EVENT_ETH_DISCONNECTED,                  // ESP32 ethernet phy link down
		WiFiControl_EVENT_ETH_GOT_IP = ARDUINO_EVENT_ETH_GOT_IP,                              // ESP32 ethernet got IP from connected AP
		WiFiControl_EVENT_ETH_LOST_IP = ARDUINO_EVENT_ETH_LOST_IP, 							//	ESP32 ethernet lost IP from connected AP
		WiFiControl_EVENT_ETH_GOT_IP6 = ARDUINO_EVENT_ETH_GOT_IP6,                            // ESP32 ethernet interface v6IP addr is preferred
		
		//	WiFi
		WiFiControl_EVENT_WIFI_OFF = ARDUINO_EVENT_WIFI_OFF,  
		WiFiControl_EVENT_WIFI_READY = ARDUINO_EVENT_WIFI_READY,                              //	ESP32 WiFi ready
		
		//	WiFi Scan
		WiFiControl_EVENT_WIFI_SCAN_DONE = ARDUINO_EVENT_WIFI_SCAN_DONE,                      //	ESP32 finish scanning AP
		
		//	WiFi FTM
		WiFiControl_EVENT_WIFI_FTM_REPORT = ARDUINO_EVENT_WIFI_FTM_REPORT,
		
		//	WiFi STA
		WiFiControl_EVENT_WIFI_STA_START = ARDUINO_EVENT_WIFI_STA_START,                      //	ESP32 station start
		WiFiControl_EVENT_WIFI_STA_STOP = ARDUINO_EVENT_WIFI_STA_STOP,                        // ESP32 station stop
		WiFiControl_EVENT_WIFI_STA_CONNECTED = ARDUINO_EVENT_WIFI_STA_CONNECTED,              // ESP32 station connected to AP
		WiFiControl_EVENT_WIFI_STA_DISCONNECTED = ARDUINO_EVENT_WIFI_STA_DISCONNECTED,        // ESP32 station disconnected from AP
		WiFiControl_EVENT_WIFI_STA_AUTHMODE_CHANGE = ARDUINO_EVENT_WIFI_STA_AUTHMODE_CHANGE,  // the auth mode of AP connected by ESP32 station changed
		WiFiControl_EVENT_WIFI_STA_GOT_IP = ARDUINO_EVENT_WIFI_STA_GOT_IP,                    // ESP32 station got IP from connected AP
		WiFiControl_EVENT_WIFI_STA_GOT_IP6 = ARDUINO_EVENT_WIFI_STA_GOT_IP6,                  // ESP32 station interface v6IP addr is preferred
		WiFiControl_EVENT_WIFI_STA_LOST_IP = ARDUINO_EVENT_WIFI_STA_LOST_IP,                  // ESP32 station lost IP and the IP is reset to 0
		
		//	WiFi AP
		WiFiControl_EVENT_WIFI_AP_START = ARDUINO_EVENT_WIFI_AP_START,                        // ESP32 soft-AP start
		WiFiControl_EVENT_WIFI_AP_STOP = ARDUINO_EVENT_WIFI_AP_STOP,                          // ESP32 soft-AP stop
		WiFiControl_EVENT_WIFI_AP_STACONNECTED = ARDUINO_EVENT_WIFI_AP_STACONNECTED,          // a station connected to ESP32 soft-AP
		WiFiControl_EVENT_WIFI_AP_STADISCONNECTED = ARDUINO_EVENT_WIFI_AP_STADISCONNECTED,    // a station disconnected from ESP32 soft-AP
		WiFiControl_EVENT_WIFI_AP_STAIPASSIGNED = ARDUINO_EVENT_WIFI_AP_STAIPASSIGNED,        // ESP32 soft-AP assign an IP to a connected station
		WiFiControl_EVENT_WIFI_AP_PROBEREQRECVED = ARDUINO_EVENT_WIFI_AP_PROBEREQRECVED,      // Receive probe request packet in soft-AP interface
		WiFiControl_EVENT_WIFI_AP_GOT_IP6 = ARDUINO_EVENT_WIFI_AP_GOT_IP6,                    // ESP32 ap interface v6IP addr is preferred						 
		
		//	WiFi WPS
		WiFiControl_EVENT_WPS_ER_SUCCESS = ARDUINO_EVENT_WPS_ER_SUCCESS,                      // ESP32 station wps succeeds in enrollee mode
		WiFiControl_EVENT_WPS_ER_FAILED = ARDUINO_EVENT_WPS_ER_FAILED,                        // ESP32 station wps fails in enrollee mode
		WiFiControl_EVENT_WPS_ER_TIMEOUT = ARDUINO_EVENT_WPS_ER_TIMEOUT,                      // ESP32 station wps timeout in enrollee mode
		WiFiControl_EVENT_WPS_ER_PIN = ARDUINO_EVENT_WPS_ER_PIN,                              // ESP32 station wps pin code in enrollee mode
		WiFiControl_EVENT_WPS_ER_PBC_OVERLAP = ARDUINO_EVENT_WPS_ER_PBC_OVERLAP,
		
		//	WiFi Smart Config
		WiFiControl_EVENT_SC_SCAN_DONE = ARDUINO_EVENT_SC_SCAN_DONE,
		WiFiControl_EVENT_SC_FOUND_CHANNEL = ARDUINO_EVENT_SC_FOUND_CHANNEL,
		WiFiControl_EVENT_SC_GOT_SSID_PSWD = ARDUINO_EVENT_SC_GOT_SSID_PSWD,
		WiFiControl_EVENT_SC_SEND_ACK_DONE = ARDUINO_EVENT_SC_SEND_ACK_DONE,
		
		//	WiFi Provisioning
		WiFiControl_EVENT_PROV_INIT = ARDUINO_EVENT_PROV_INIT,
		WiFiControl_EVENT_PROV_DEINIT = ARDUINO_EVENT_PROV_DEINIT,
		WiFiControl_EVENT_PROV_START = ARDUINO_EVENT_PROV_START,
		WiFiControl_EVENT_PROV_END = ARDUINO_EVENT_PROV_END,
		WiFiControl_EVENT_PROV_CRED_RECV = ARDUINO_EVENT_PROV_CRED_RECV,
		WiFiControl_EVENT_PROV_CRED_FAIL = ARDUINO_EVENT_PROV_CRED_FAIL,
		WiFiControl_EVENT_PROV_CRED_SUCCESS = ARDUINO_EVENT_PROV_CRED_SUCCESS,
		
		//	PPP
		WiFiControl_EVENT_PPP_START = ARDUINO_EVENT_PPP_START,
		WiFiControl_EVENT_PPP_STOP = ARDUINO_EVENT_PPP_STOP,
		WiFiControl_EVENT_PPP_CONNECTED = ARDUINO_EVENT_PPP_CONNECTED,
		WiFiControl_EVENT_PPP_DISCONNECTED = ARDUINO_EVENT_PPP_DISCONNECTED,
		WiFiControl_EVENT_PPP_GOT_IP = ARDUINO_EVENT_PPP_GOT_IP,
		WiFiControl_EVENT_PPP_LOST_IP = ARDUINO_EVENT_PPP_LOST_IP,
		WiFiControl_EVENT_PPP_GOT_IP6 = ARDUINO_EVENT_PPP_GOT_IP6,
		
		WiFiControl_EVENT_MAX = ARDUINO_EVENT_MAX,
		
		WiFiControl_TakeMutexFailed
};


class WiFiControlEventData {
  arduino_event_t event;
  ulong_t timeMS;
  ulong_t timeUS;
};


class WiFiControl : public Control {
protected:
  int8_t mode = -1;	//	enum WiFiControlWiFiMode_t
  bool isInitCalled = false;

//  bool isConnecting = false;
//  uint32_t connectionStartTime = 0;

  err_t startControl();
  err_t stopControl();
  
	//	for handling of WiFiEvent and associated data
	static RingBuffer *wifiEventInfoRB;
	static void wifiEventHandler(WiFiEvent_t event, WiFiEventInfo_t info);
	static void saveWiFiEventInfo(uint8_t _wifiEvent,uint8_t _wifiInfoLen,byte* _wifiInfo);
	static SemaphoreHandle_t wifiEventInfoRBMutex;
	
	//	for SmartConfig
	char cryptKey[17];

  friend PinManager;
  
public:
  WiFiControl();

  bool isInit();

  err_t init(WiFiControlWiFiMode_t _mode,size_t _wifiEventBufferSize=1024);
	//	_mode: WiFiControlWiFiModeAP, WiFiControlWiFiModeSTA, WiFiControlWiFiModeAPSTA
	//	_wifiEventBufferSize: size of ring buffer for storing wifiEvent and associated data

  static int getStaticClsID() {
    return CLS_WIFI;
  }

  err_t subscribeEvent(WiFiContolEvent_t event_id);
  err_t unsubscribeEvent(WiFiContolEvent_t event_id);
	WiFiContolEvent_t	getWiFiEvent(uint8_t* _data,uint8_t& _len);
	
  
  int8_t getMode();
  //=======================================
  //              STA Mode
  //=======================================

  err_t
  connect(const String &ssid, const String &passphrase = (const char *)NULL, int32_t channel = 0, const uint8_t *bssid = NULL, bool connect = true);
  //	WiFiSTAClass::wl_status_t begin(const String &ssid, const String &passphrase = (const char *)NULL, int32_t channel = 0, const uint8_t *bssid = NULL, bool connect = true)

  err_t config(IPAddress local_ip, IPAddress gateway, IPAddress subnet, IPAddress dns1 = (uint32_t)0x00000000, IPAddress dns2 = (uint32_t)0x00000000);
  //	WiFiSTAClass::config(IPAddress local_ip, IPAddress gateway, IPAddress subnet, IPAddress dns1 = (uint32_t)0x00000000, IPAddress dns2 = (uint32_t)0x00000000);

  err_t setDNS(IPAddress dns1, IPAddress dns2 = (uint32_t)0x00000000);
  //	WiFiSTAClass::setDNS(IPAddress dns1, IPAddress dns2 = (uint32_t)0x00000000)

  err_t bandwidth(wifi_bandwidth_t bandwidth);
  //	WiFiSTAClass::bandwidth(wifi_bandwidth_t bandwidth)

  err_t reconnect();
  //	WiFiSTAClass::reconnect()

  bool isConnected();
  //	WiFiSTAClass::isConnected()

  err_t disconnect(bool wifioff = false, bool eraseap = false);
  //	WiFiSTAClass::disconnectAsync(bool wifioff = false, bool eraseap = false);
  //	do not use the sync one - WiFiSTAClass::disconnect(bool wifioff = false, bool eraseap = false, unsigned long timeoutLength = 100);

  err_t eraseAP(void);
  //	WiFiSTAClass::eraseAP(void);

  err_t setAutoReconnect(bool autoReconnect);
  //	WiFiSTAClass::setAutoReconnect(bool autoReconnect)

  err_t getAutoReconnect();
  //	WiFiSTAClass::getAutoReconnect()

  int16_t getStatus();
  //	wl_status_t WiFiSTAClass::status()

  String SSID();
  //	String WiFiSTAClass::SSID() const;


  String BSSID(String bssid);
  //	combine:
  //		uint8_t *WiFiSTAClass::BSSID(uint8_t *bssid = NULL);
  //		String WiFiSTAClass::BSSIDstr();

  int8_t RSSI();
  //	int8_t WiFiSTAClass::RSSI();

  IPAddress localIP();
  //	IPAddress WiFiSTAClass::localIP();

  String macAddress();
  //	combine:
  //		uint8_t *WiFiSTAClass::macAddress(uint8_t *mac);
  //		String WiFiSTAClass::macAddress();

  IPAddress subnetMask();
  //	IPAddress WiFiSTAClass::subnetMask();

  IPAddress gatewayIP();
  //	IPAddress WiFiSTAClass::gatewayIP();

  IPAddress dnsIP(uint8_t dns_no = 0);
  //	IPAddress WiFiSTAClass::dnsIP(uint8_t dns_no = 0);

  err_t subnetCIDR();
  //	uint8_t WiFiSTAClass::subnetCIDR();

  IPAddress broadcastIP();
  //	IPAddress WiFiSTAClass::broadcastIP();

  IPAddress networkID();
  //	IPAddress WiFiSTAClass::networkID();



  //========================================
  //                AP Mode
  //========================================
  err_t createAP(const String &ssid, const String &passphrase = emptyString, int channel = 1, int ssid_hidden = 0, int max_connection = 4, bool ftm_responder = false);
  //	WiFiAPClass::softAP(const String &ssid, const String &passphrase = emptyString, int channel = 1, int ssid_hidden = 0, int max_connection = 4, bool ftm_responder = false,
  //		wifi_auth_mode_t auth_mode = WIFI_AP_DEFAULT_AUTH_MODE, wifi_cipher_type_t cipher = WIFI_AP_DEFAULT_CIPHER)

  err_t config_AP(IPAddress local_ip, IPAddress gateway, IPAddress subnet, IPAddress dhcp_lease_start = (uint32_t)0, IPAddress dns = (uint32_t)0);
  //	bool WiFiAPClass::softAPConfig(IPAddress local_ip, IPAddress gateway, IPAddress subnet, IPAddress dhcp_lease_start = (uint32_t)0, IPAddress dns = (uint32_t)0);

  err_t disconnect_AP(bool wifioff = false);
  //	bool WiFiAPClass::softAPdisconnect(bool wifioff = false);

  err_t bandwidth_AP(wifi_bandwidth_t bandwidth);
  //	bool WiFiAPClass::softAPbandwidth(wifi_bandwidth_t bandwidth);

  err_t getStationNum_AP();
  //	uint8_t WiFiAPClass::softAPgetStationNum();

  String SSID_AP();
  //	String WiFiAPClass::softAPSSID(void) const;

  IPAddress localIP_AP();
  //	IPAddress WiFiAPClass::softAPIP();

  IPAddress broadcastIP_AP();
  //	IPAddress WiFiAPClass::softAPBroadcastIP();

  err_t subnetCIDR_AP();
  //	uint8_t WiFiAPClass::softAPSubnetCIDR();

  IPAddress networkID_AP();
  //	IPAddress WiFiAPClass::softAPNetworkID();

  IPAddress subnetMask_AP();
  //	IPAddress WiFiAPClass::softAPSubnetMask();

  String hostName_AP(String _newHostName = "");
  //	combine:
  //		const char *WiFiAPClass::softAPgetHostname();
  //		bool WiFiAPClass::softAPsetHostname(const char *hostname);

  String macAddress_AP();
  //	combine:
  //		uint8_t *WiFiAPClass::softAPmacAddress(uint8_t *mac);
  //		String WiFiAPClass::softAPmacAddress(void);
  //


  //========================================
  //                Scan
  //========================================
  err_t setScanTimeout(uint32_t _timeMS);
  //	void WiFiScanClass::setScanTimeout(uint32_t ms);

  err_t setScanActiveMinTime(uint32_t _timeMS);
  //	void WiFiScanClass::setScanActiveMinTime(uint32_t ms);

  int16_t scanNetworks(bool show_hidden = false, bool passive = false, uint32_t max_ms_per_chan = 300, uint8_t channel = 0,
                     const char *ssid = nullptr, const uint8_t *bssid = nullptr);
  //	int16_t WiFiScanClass::scanNetworks(bool async = false, bool show_hidden = false, bool passive = false, uint32_t max_ms_per_chan = 300, uint8_t channel = 0,
  //		const char *ssid = nullptr,const uint8_t *bssid = nullptr
  //
  //	must be async
  //	potential issue: cannot report scan results while scanning; but can be run one channel at a time

  bool isScanCompleted();
  //	to be used by handler to check end of scanNetworks
  //
  //	from int16_t WiFiScanClass::scanComplete()

  int16_t getScanNetworkNum();
  //	return number of networks from last scanNetwork
  //
  //	from int16_t WiFiScanClass::scanComplete()

  err_t scanDelete();
  //	delete results from last scan
  //
  //	void WiFiScanClass::scanDelete()

  err_t getNetworkInfo(uint8_t networkItem, String &ssid, uint8_t &encryptionType, int32_t &RSSI, uint8_t *&BSSID, int32_t &channel);
  //	bool WiFiScanClass::getNetworkInfo(uint8_t networkItem, String &ssid, uint8_t &encryptionType, int32_t &RSSI, uint8_t *&BSSID, int32_t &channel);

  String getSSID(uint8_t networkItem);
  //	String WiFiScanClass::SSID(uint8_t networkItem);

  wifi_auth_mode_t getEncryptionType(uint8_t networkItem);
  //	wifi_auth_mode_t WiFiScanClass::encryptionType(uint8_t networkItem);

  int32_t getRSSI(uint8_t networkItem);
  //	int32_t WiFiScanClass::RSSI(uint8_t networkItem);

  String getBSSID(int8_t networkItem);
  //	combine:
  //		uint8_t *WiFiScanClass::BSSID(uint8_t networkItem, uint8_t *bssid = NULL);
  //		String WiFiScanClass::BSSIDstr(uint8_t networkItem);
  //

  int32_t getChannel(int8_t networkItem);
  //	int32_t WiFiScanClass::channel(uint8_t networkItem);

	//
	//	Smart Config
	//
	
	err_t beginSmartConfig(smartconfig_type_t type = SC_TYPE_ESPTOUCH, const char *crypt_key = NULL);
		//	WiFiSTA::beginSmartConfig(smartconfig_type_t,char*)
		//	type = SC_TYPE_ESPTOUCH or SC_TYPE_ESPTOUCH_V2
		//	crypt_key = 16-byte character string
	err_t stopSmartConfig();
		//	WiFiSTA::stopSmartConfig()
	bool smartConfigDone();
		//	WiFiSTA::smartConfigDone()

	//
	//	WiFiControl specific
	//

  err_t request();

  err_t release();

  //void update(ulong_t currentMillis) override;

  bool connected = false;

	//
	//	to be phased out
	//

  String httpGet(const char *serverURL);

  String httpPost(const char *serverURL, String data, const char *contentType);

  err_t downloadFile(const char *url, const char *filename);
	//	to be moved to "httpClientControl"
};

#endif