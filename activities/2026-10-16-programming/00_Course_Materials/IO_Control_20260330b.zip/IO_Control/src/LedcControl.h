#ifndef LEDCCONTROL_H
#define LEDCCONTROL_H

#include "driver/ledc.h"
#include "Control.h"
//#include "ServoControl.h"
//#include "FastLED.h"

class LedcControl : public Control {
protected:

  uint32_t maxDuty = 0;

  int pinIndex = -1;
  int channelIndex = -1;

  uint32_t playInvokedTime = (ulong_t)-1;
  uint32_t seqExecutedCount = 0;

  bool _isPlaying = false;

  bool isInit();
  err_t startControl();
  err_t stopControl();

public:
  uint32_t hpoint = 0;

  LedcControl();

  err_t init(int _pinIndex, bool _permitScheduler = true);

  uint32_t getFreq();
  uint8_t getDutyRes();
  err_t setDuty(uint16_t duty);  //	set duty, and use last value of hpoint (default to 0)
  err_t setDuty(uint16_t duty, uint32_t _hpoint);
  //	set duty and hpoint; if success, _hpoint will be saved for future use
  //	2024/04/01 - hpoint cannot be set, need further investigation!!!
  err_t setFreqDutyRes(uint32_t freq, uint8_t dutyRes);  //	set frequency and duty resolution; freq==0 means frequency unchanged
  uint32_t getMaxDuty();

  bool isAllSeqStarted() {
    return status & LedcControlEventHandler_AllSeqStarted;
  }
  bool isAllSeqEnded() {
    return status & LedcControlEventHandler_AllSeqEnded;
  }
  bool isOneSeqStarted() {
    return status & LedcControlEventHandler_OneSeqStarted;
  }
  bool isOneSeqNewCmdStarted() {
    return status & LedcControlEventHandler_OneSeqNewCmdStarted;
  }
  bool isOneSeqPaused() {
    return status & LedcControlEventHandler_OneSeqPaused;
  }
  bool isOneSeqEnded() {
    return status & LedcControlEventHandler_OneSeqEnded;
  }

  bool isPlaying() {
    return _isPlaying;
  }

  friend class LedcManager;
};


#endif