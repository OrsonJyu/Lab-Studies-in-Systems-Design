#ifndef ONEWIRECONTROL_H
#define ONEWIRECONTROL_H

#include "Control.h"
#include "Debug.h"
#include <OneWire.h>

class PinManager;

class OneWireControl : public Control {
protected:
  OneWire* oneWire;

  int8_t pinIndex = -1;

  byte deviceAddr[8];

  byte data[9];

  bool isInit();

  err_t startControl();

  err_t stopControl();

public:
  OneWireControl();

  err_t init(int8_t _pinIndex, bool _permitScheduler = true);

  static int getStaticClsID() {
    return CLS_OneWire;
  }

  //void update(ulong_t currentMillis) override;

  err_t request();

  err_t release();

  err_t searchDeviceAddr();

  err_t validateDevice();

  err_t selectDevice(const uint8_t _addr[8]);

  err_t read();

  friend class PinManager;
};

#endif
