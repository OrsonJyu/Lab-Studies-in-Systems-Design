#ifndef ADDRLEDCONTROL_H
#define ADDRLEDCONTROL_H

#include "Control.h"
#include "Debug.h"

#include <Adafruit_NeoPixel.h>

//	for compatibility with previous version
#define seqObjs seqTargets
#define abortAllSequences abortPlay

class AddrLEDSequence;

class SetRGBFunc {
public:
  virtual void execute(ulong currentMillis) = 0;
};


struct NP_command {
  int mode;  //0 for setColorRGB, 1 for setColorHSV, 2 for interpolateRGB, 3 for interpolateHSV
  unsigned long duration;
};

struct NP_command_setColorRGB : public NP_command {
  uint8_t r;
  uint8_t g;
  uint8_t b;
};

struct NP_command_setColorHSV : public NP_command {
  double h;  //uint16_t h;
  double s;  //uint8_t s;
  double v;  //uint8_t v;
};

struct NP_command_interpolateRGB : public NP_command {
  uint8_t r_start;
  uint8_t g_start;
  uint8_t b_start;

  uint8_t r_end;
  uint8_t g_end;
  uint8_t b_end;
};

struct NP_command_interpolateHSV : public NP_command {
  double h_start;  //uint16_t h_start;
  double s_start;  //uint8_t s_start;
  double v_start;  //uint8_t v_start;

  double h_end;  //uint16_t h_end;
  double s_end;  //uint8_t s_end;
  double v_end;  //uint8_t v_end;
};

class AddrLEDSequence {
public:
  std::vector<NP_command*> sequence;

  SetRGBFunc* rgbFunc = 0;

  int seqType;  //0 is original, 1 is setRGBFunc

	//
	//	@brief	Add a SetColorRGB command to the sequence
	//	@param _duration Duration of this SetColorRGB command, in ms
	//	@param _r,_g,_b R,G,B value to be set
	//	@return Control_OK if succeed, error code if fail
	//
  err_t addSetRGB(uint32_t _duration, uint8_t _r, uint8_t _g, uint8_t _b);
  
 	//
	//	@brief	Add a SetColorHSV command to the sequence
	//	@param _duration Duration of this SetColorHSV command, in ms
	//	@param _h,_s,_v HSV value to be set
	//	@return Control_OK if succeed, error code if fail
	//
  err_t addSetHSV(uint32_t _duration, double _h, double _s, double _v);
  
 	//
	//	@brief	Add a interpolateRGB command to the sequence
	//	@param _duration Duration of this interpolateRGB command, in ms
	//	@param _r_start,_g_start,_b_start R,G,B value at start of this command
	//	@param _r_end,_g_end,_b_end R,G,B value at end of this command
	//	@return Control_OK if succeed, error code if fail
	//	
  err_t addInterpolateRGB(uint32_t _duration, uint8_t _r_start, uint8_t _g_start, uint8_t _b_start, uint8_t _r_end, uint8_t _g_end, uint8_t _b_end);

	//
	//	@brief	Add a interpolateHSV command to the sequence
	//	@param _duration Duration of this interpolateHSV command, in ms
	//	@param _h_start,_s_start,_v_start H,S,V value at start of this command
	//	@param _h_end,_s_end,_v_end H,S,V value at end of this command
	//	@return Control_OK if succeed, error code if fail
	//	
  err_t addInterpolateHSV(uint32_t _duration, double _h_start, double _s_start, double _v_start, double _h_end, double _s_end, double _v_end);


  err_t addSetRGBFunc(uint32_t startTime, ulong interval, SetRGBFunc* setRGBFunc);
  err_t clearCommand();
};

struct AddrLedSeqTargets {
  uint16_t index;
  std::vector<int> seqTargets;
  //std::vector<AddrLEDSequence> currentSequences;
  AddrLEDSequence localSeq;
  uint32_t playInvokedTime;
  uint32_t seqTargetRelStartTime;
  uint32_t seqExecutedCount;	//	no of times this sequence has been played
  int32_t seqRepeatCount;		//	total no of times this sequence is to be played
  int8_t commandPointer = 0;
  bool isCurrentCommandStarted = false;
  uint32_t currentCmdStartTime;
  bool shouldPause = false;
};

class AddrLEDControl : public Control {
protected:
	uint8_t pinIndex;
	uint16_t ledNum;
	bool* availableLEDs;
  
	Adafruit_NeoPixel* strip = 0;
  
	bool isInit();
	err_t startControl();
	err_t stopControl();
	
  
	//
	//	For sequencing
	//

	//
	//	@brief	Set availability status of those indices in _targets
	//	@param	_targets Set of indices of LEDs
	//	@param	_value Availability status to be set; true for "available", false for "unavailable"
	//	@return false if _targets includes at least one invalid index, and no availability status will be changed; true if success
	//
  bool setAvailability(const std::vector<int>& _targets, bool _value);

  uint16_t updateCount = 0;	//	if inside the handler, corresponding to the sequence id of the currently executed sequence
  
	bool shouldCurrentSeqObjBeDeleted;

public:

  std::vector<AddrLedSeqTargets*> seqTargets;	//	for storing AddrLedSeqTargets objects in this AddrLEDControl
												//	no of elements == ledNum, as assuming in worst case one sequence for one LED

  static int16_t getStaticClsID() {
    return CLS_ADDRLED;
  }

  AddrLEDControl();

	//
	//	@brief	Initialize the AddrLEDControl object
	//	@param	_pinIndex GPIO pin number for controlling the WS2812 strip
	//	@param 	_ledNum Number of LEDs in the WS2812 strip
	//	@param	_permitScheduler true if permit use of scheduler
	//	@return Control_OK if success, otherwise error code
	//
  err_t init(uint8_t _pinIndex, uint16_t _ledNum, bool _permitScheduler = true);

  err_t request();
  
  err_t release();

	//
	//	@brief	Get number of LEDs in the WS2812 strip
	//	@return Number of LEDs of this WS2812 strip
	//
  uint16_t getLedNum();
  
 	//
	//	@brief	Check if those indices in _targets are valid and available to use
	//	@param	_targets Set of indices of LEDs
	//	@return true if all indices in _targets are valid and available, false otherwise
	//
  bool checkAvailability(const std::vector<int>& _targets);

  //void update(uint32_t currentMillis) override;
  void _preHandler() override;
  void _postHandler() override;
  
	//
	//	methods valid to use only within handler function
	//
  
	//
	//	@brief	Return the playID of the playback action just performed before invoking the handler
	//	@return	playID if >=0, error code if <=0 (e.g. when there is no active playback action, including pause)
	//
	int16_t getCurrentPlayID();
	
/*
//	replaced by getCurrentPlayID()
	//
	//	@brief	Get the sequence id currently being processed 
	//	@return sequence id of the sequence just updated if >=0, AddrLEDControl_PlayIDNotActive  if no sequence is playing
	//
  int16_t getCurrentSeqObjIndex();
*/

  
//**	name of methods  may have to be revised to use term like "play" instead of "seq"
  bool isAllSeqStarted() {
    return status & AddrLEDControlEventHandler_AllSeqStarted;
  }
  bool isAllSeqEnded() {
    return status & AddrLEDControlEventHandler_AllSeqEnded;
  }
  bool isOneSeqStarted() {
    return status & AddrLEDControlEventHandler_OneSeqStarted;
  }
  bool isOneSeqNewCmdStarted() {
    return status & AddrLEDControlEventHandler_OneSeqNewCmdStarted;
  }
  bool isOneSeqPaused() {
    return status & AddrLEDControlEventHandler_OneSeqPaused;
  }
  bool isOneSeqEnded() {
    return status & AddrLEDControlEventHandler_OneSeqEnded;
  }

	//
	//	for setting of individual LED status
	//

	//
	//	@brief	Turn off all LEDs on the WS2812 strip
	//	@return Control_OK if success, otherwise error code
	//
  err_t clearLEDs();

	//
	//	@brief	Update LEDs with changes by set*(...) since last invocation of this method
	//	@return Control_OK if success, otherwise error code
	//
  err_t showLEDs();

	//
	//	@brief	Set RGB value of those LEDs as defined in _targets
	//	@param _targets	Set of indices of LEDs to be set with the RGB value
	//	@param _r	R value [0,255]
	//	@param _g	G value [0,255]
	//	@param _b	B value [0,255]
	//	@return Control_OK if success, otherwise error code
	//
  err_t setRGB(const std::vector<int>& _targets, uint8_t _r, uint8_t _g, uint8_t _b);

	//
	//	@brief	Set HSV value of those LEDs as defined in _targets
	//	@param _targets	Set of indices of LEDs to be set with the HSV value
	//	@param _h	H value [0,360]
	//	@param _s	S value [0,100]
	//	@param _v	V value [0,100]
	//	@return Control_OK if success, otherwise error code
	//
  err_t setHSV(const std::vector<int>& _targets, double _h, double _s, double _v);

	//
	//	@brief	Set HSV value of those LEDs as defined in _targets, with no mapping
	//	@param _targets	Set of indices of LEDs to be set with the HSV value
	//	@param _h	H value [0,65535]
	//	@param _s	S value [0,255]
	//	@param _v	V value [0,255]
	//	@return Control_OK if success, otherwise error code
	//
  err_t setHSV_noMap(const std::vector<int>& targets, uint16_t H, uint8_t S, uint8_t V);

	//
	//	for playback of sequence
	//	

	//
	//	@brief	Start a playback action with lighitng sequence _seq on those indices in _targets for _SeqRepeatCount times, starting at time (in ms) _playRelStartTime after the current time
	//	@param _targets	Set of indices of LEDs to be set
	//	@param _playRelStartTime	Time to start playback of the sequence _seq relative to current time
	//	@param _SeqRepeatCount Number of times the sequence _seq is playback
	//	@return playID if >=0 and error code if <0; playID is for identifying this specific playback action
	//
  int16_t playRelTime(const std::vector<int>& _targets, AddrLEDSequence& _seq, uint32_t _playRelStartTime, int32_t _SeqRepeatCount);
  
  	//
	//	@brief	Start a playback action with lighting sequence _seq on those indices in _targets _SeqRepeatCount times at the absolute time_seqAbsStartTime
	//	@param _targets	Set of indices of LEDs to be set
	//	@param _seqAbsStartTime	Absolute time to start playback of the sequence _seq
	//	@param _seqRepeatCount Number of times the sequence _seq is playback
	//	@return playID if >=0 and error code if <0; playID is for identifying this specific playback action
	//
  int16_t playAbsTime(const std::vector<int>& _targets, AddrLEDSequence& _seq, uint32_t _playAbsStartTime, int32_t _SeqRepeatCount);


	//
	//	for control of a playback action
	//

    //
	//	@brief	Pause playback action with _playID BEFORE start of next command
	//	@param _playID	playID returned by playRelTime(...) or playAbsTime(...)
	//	@return Control_OK if success, AddrLEDControl_PlayIDNotActive  if _playID is invalid (meaning that playback of that sequence has ended)
	//
  err_t pauseBeforeNextCommand(int16_t _playID);

    //
	//	@brief	Resume a paused playback action with _playID
	//	@param _playID	playID returned by playRelTime(...) or playAbsTime(...)
	//	@return Control_OK if success, AddrLEDControl_PlayIDNotActive  if _playID is invalid (meaning that playback of that sequence has ended)
	//
  err_t resume(int16_t _playID);

    //
	//	@brief	Get index of the next command to be executed in the playback action with _playID
	//	@param _playID	playID returned by playRelTime(...) or playAbsTime(...)
	//	@return current command index if >=0, AddrLEDControl_PlayIDNotActive  if _playID is invalid (meaning that playback of that sequence has ended)
	//
  err_t getNextCommandIndex(int16_t _playID);
  //err_t getCurrentCommandIndex(int16_t _playID	//	replaced by getNextCommandIndex()

    //
	//	@brief	Get the total repeat count of the playback action with _playID
	//	@param _playID	playID returned by playRelTime(...) or playAbsTime(...)
	//	@return total repeat count if >0, AddrLEDControl_PlayIDNotActive  if _playID is invalid (meaning that playback of that sequence has ended)
	//
  int32_t getSeqRepeatCount(int16_t _playID);

    //
	//	@brief	Set the total repeat count of the playback action with _playID
	//	@param _playID	playID returned by playRelTime(...) or playAbsTime(...)
	//	@param _SeqRepeatCount new value of SeqRepeatCount to be set; must be larger than the number of times the sequence has been executed
	//	@return new total repeat count (>=0) if success, <0 if error, with possible error code AddrLEDControl_PlayIDNotActive and AddrLEDControl_FailToSetNewRepeatCount
	//
  err_t setSeqRepeatCount(int16_t _playID, int32_t _SeqRepeatCount);
  
    //
	//	@brief	Get the number of sequence which has already been executed in the playback action with _playID
	//	@param _playID	playID returned by playRelTime(...) or playAbsTime(...)
	//	@return number of times the sequence has been executed
	//
  int32_t getSeqExecutedCount(int16_t _playID);

	//
	//	@brief	Abort a playback action with playID = _playID
	//	@param _playID	playID returned by playRelTime(...) or playAbsTime(...)
	//	@return Control_OK if success, AddrLEDControl_PlayIDNotActive  if fail
	//
	err_t abortPlay(int16_t _playID);
	
	//
	//	@brief	Abort all playback actions
	//	@return Control_OK if success, AddrLEDControl_PlayIDNotActive  if fail
	//
	err_t abortPlay();
	
	//
	//	@brief	Check if a particular playback action with _playID is still active. Note that a paused playback action is considered as "playing"
	//	@param _playID  playID returned by playRelTime(...) or playAbsTime(...)
	//	@return true if still playing, false otherwise
	//
  bool isPlaying(int16_t _playID);

	//
	//	@brief	Check if at least one playback action is still active
	//	@return true if still playing, false otherwise
	// 
	bool isPlaying();
	

  friend class PinManager;

  friend class MoveGroup;
};


class MoveGroup : public SetRGBFunc {
private:
  AddrLEDControl* addrLedCtrl;
  int groupSize;
  uint32_t calculateBrightness(int pixelIndex, int groupCenter, int groupSize);

public:
  MoveGroup(AddrLEDControl& _addrLedCtrl, int _groupSize);
  void execute(ulong currentMillis);
};


#endif