#ifndef HWCDCCONTROL_H
#define HWCDCCONTROL_H

#include "Control.h"
#include "Debug.h"
#include "HWCDC.h"

class PinManager;
                                    
class HWCDCControl : public Control {
public:

#ifdef CONFIG_IDF_TARGET_ESP32C3
  //  for ESP32 C3
  static const uint8_t pinDNeg = 18; 
  static const uint8_t pinDPos = 19;
#endif

#ifdef CONFIG_IDF_TARGET_ESP32S3
	//  for ESP32 S3
  static const uint8_t pinDNeg = 19; 
  static const uint8_t pinDPos = 20;
#endif

  HWCDCControl();

  err_t init(ulong_t _baudRate=115200UL, ulong_t _txTimeOutMS=20000UL);

  static int getStaticClsID() {
    return CLS_HWCDC;
  }

  //void update(ulong_t currentMillis) override; 
  
  err_t request();
  err_t release();
  
  HWCDC* getSerial()
  { if (isActive())
      return hwcdc;
    else
      return 0;
  }

protected:
  HWCDC* hwcdc = nullptr;;
  
  ulong_t baudRate=0;
  ulong_t txTimeOutMS=0;
  
  bool isInit();

  err_t startControl();
  err_t stopControl();

friend class PinManager;
};

#endif

