#ifndef DHTCONTROL_H
#define DHTCONTROL_H

#include "Control.h"
#include "Debug.h"
#include "DHT.h"

class PinManager;

class DHTControl : public Control {
protected:
  DHT* dht;

  uint8_t type; //DHT11/DHT22/DHT21/AM2301/DHT12

  int8_t pinIndex = -1;

  bool isInit();

  err_t startControl();

  err_t stopControl();

public:
  DHTControl();

  err_t init(uint8_t _type, int8_t _pinIndex, bool _permitScheduler = true);

  static int getStaticClsID() {
    return CLS_DHT;
  }

  //void update(ulong_t currentMillis) override;

  err_t request();

  err_t release();

  float getTemperature_Celsius();

  float getTemperature_Fahrenheit();

  float getHumidity();

  friend class PinManager;
};

#endif
