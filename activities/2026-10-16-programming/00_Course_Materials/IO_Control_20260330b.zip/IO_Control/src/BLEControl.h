#ifndef BLECONTROL_H
#define BLECONTROL_H

#include "Control.h"
#include "Debug.h"
#include <NimBLEDevice.h>

enum {
  BLE_READ_ENC,
  BLE_READ_AUTHEN,
  BLE_READ_AUTHOR,
  BLE_WRITE,
  BLE_WRITE_NR,
  BLE_WRITE_ENC,
  BLE_WRITE_AUTHEN,
  BLE_WRITE_AUTHOR,
  BLE_BROADCAST,
  BLE_NOTIFY,
  BLE_INDICATE
};

class BLEControl : public Control {
protected:

  //For BLE Server
  BLEServer* server = nullptr;
  BLEService** services = nullptr;
  BLECharacteristic*** characteristics = nullptr;
  BLEAdvertising* advertising = nullptr;

  uint8_t noOfService = 0;

  uint8_t noOfCharacteristic = 0;

  bool hasBLEInit = false;

  uint8_t serviceCount = 0;

  uint8_t* characteristicCount = nullptr;

  const char** serviceUUIDs = nullptr;

  //For BLE Client
  BLEAdvertisedDevice* connectedDevice = nullptr;

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

public:

  BLEControl();

  err_t init(const char* deviceName, uint8_t _noOfService, uint8_t _noOfCharacteristic);

  ~BLEControl();

  static int getStaticClsID() {
    return CLS_BLE;
  }

  err_t request();

  err_t release();

  void update(ulong_t currentMillis) override;

  //For BLE Server

  err_t createServer();

  err_t createService(uint8_t serviceIndex, const char* serviceUUID);

  err_t createCharacteristic(uint8_t serviceIndex, const char* characteristicUUID, uint8_t _properties[], uint8_t sizeOfProperties);

  err_t setValue(const char* value, uint8_t serviceIndex, uint8_t characteristicIndex);

  err_t setValue(int32_t value, uint8_t serviceIndex, uint8_t characteristicIndex);

  err_t startService(uint8_t serviceIndex);

  err_t startAdvertise();

  err_t addServiceToAdvertise(uint8_t serviceIndex);

  //For BLE Client
  err_t connectToServer();

  err_t scanDevice();

  friend class PinManager;
};


#endif