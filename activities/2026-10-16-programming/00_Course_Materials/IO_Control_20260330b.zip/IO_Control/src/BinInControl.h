#ifndef BININCONTROL_H
#define BININCONTROL_H

#include "Control.h"
#include "Debug.h"

class PinManager;

struct ISR_Data {
  uint32_t eventTime;  //  time when interrupt occurred
  bool triggered;
  int state;  //  state of GPIO as read from the ISR

  uint32_t pulseStartTime;
  uint32_t pulseEndTime;
  bool isPulseRead;
};

class BinInControl : public Control {
protected:
  bool isInterruptEnabled = false;
  volatile ISR_Data* isrData;  //  use by ISR
  ISR_Data isrDataCopy;        //  copy of isrData in update(), use in getInterruptTime() and getInterruptState()
  double lastPulseDuration;

  // bool setTriggered(bool _triggered);
  // bool getTriggered();

  //  err_t setPinMode(int _pinMode); //  Tony: useful?

  int8_t pinIndex = -1;  //  -1 if not initialized
  uint8_t mode;          //  input mode of the pin

  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

  friend PinManager;

public:
  static const unsigned long DEBOUNCE_INTERVAL = 8000;

  BinInControl();
  //BinInControl(int _pinIndex, int _mode);

  static int getStaticClsID() {
    return CLS_BININ;
  }

  err_t init(uint8_t _pinIndex, uint8_t _pinMode, bool _permitScheduler = true);
  //  valid _pinMode: INPUT, INPUT_PULLUP

  bool isBinInTriggered() {
    return status & BinInControlEventHandler_BinInTriggered;
  }

  int8_t read();
  //  read value of pinIndex

  double readPulseDuration();

  //int enableInterrupt(ulong_t _startTime, ulong_t _interval, int mode, ControlEventHandler _handler); // Tony: may not need this, as interrupt can be enabled without ControlEventHandler
  err_t enableInterrupt(uint8_t _intrMode);
  //  valid _intrMode: LOW, HIGHT, CHANGE, FALLING, RISING
  err_t disableInterrupt();

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  bool copyIfTriggered();
  //  if ISR has been triggered, return true and copy ISR data to a local copy
  //  otherwise, return false, and local copy is untouched
  int32_t getInterruptTime();  //  get time of last interrupt; should be used in handler when status&BinInControlEventHandler_BinInTriggered is true
  int8_t getInterruptState();  //  get state when last ISR was invoked; should be used in handler when status&BinInControlEventHandler_BinInTriggered is true

  //  volatile ISR_Data* getISRData();  //  Tony: useful?

  bool isInit();  //  refer to comments on Control::init()

  err_t request();

  err_t release();

#ifdef CONFIG_IDF_TARGET_ESP32C3
  static void ICACHE_RAM_ATTR isr_0();
  static void ICACHE_RAM_ATTR isr_1();
  static void ICACHE_RAM_ATTR isr_2();
  static void ICACHE_RAM_ATTR isr_3();
  static void ICACHE_RAM_ATTR isr_4();
  static void ICACHE_RAM_ATTR isr_5();
  static void ICACHE_RAM_ATTR isr_6();
  static void ICACHE_RAM_ATTR isr_7();
  static void ICACHE_RAM_ATTR isr_8();
  static void ICACHE_RAM_ATTR isr_9();
  static void ICACHE_RAM_ATTR isr_10();
  static void ICACHE_RAM_ATTR isr_12();
  static void ICACHE_RAM_ATTR isr_13();
  static void ICACHE_RAM_ATTR isr_18();
  static void ICACHE_RAM_ATTR isr_19();
  static void ICACHE_RAM_ATTR isr_20();
  static void ICACHE_RAM_ATTR isr_21();

  static volatile unsigned long lastInterruptTime_0;
  static volatile unsigned long lastInterruptTime_1;
  static volatile unsigned long lastInterruptTime_2;
  static volatile unsigned long lastInterruptTime_3;
  static volatile unsigned long lastInterruptTime_4;
  static volatile unsigned long lastInterruptTime_5;
  static volatile unsigned long lastInterruptTime_6;
  static volatile unsigned long lastInterruptTime_7;
  static volatile unsigned long lastInterruptTime_8;
  static volatile unsigned long lastInterruptTime_9;
  static volatile unsigned long lastInterruptTime_10;
  static volatile unsigned long lastInterruptTime_12;
  static volatile unsigned long lastInterruptTime_13;
  static volatile unsigned long lastInterruptTime_18;
  static volatile unsigned long lastInterruptTime_19;
  static volatile unsigned long lastInterruptTime_20;
  static volatile unsigned long lastInterruptTime_21;

#elif defined(CONFIG_IDF_TARGET_ESP32S3)
  static void ICACHE_RAM_ATTR isr_1();
  static void ICACHE_RAM_ATTR isr_2();
  static void ICACHE_RAM_ATTR isr_4();
  static void ICACHE_RAM_ATTR isr_5();
  static void ICACHE_RAM_ATTR isr_6();
  static void ICACHE_RAM_ATTR isr_7();
  static void ICACHE_RAM_ATTR isr_8();
  static void ICACHE_RAM_ATTR isr_9();
  static void ICACHE_RAM_ATTR isr_10();
  static void ICACHE_RAM_ATTR isr_11();
  static void ICACHE_RAM_ATTR isr_12();
  static void ICACHE_RAM_ATTR isr_13();
  static void ICACHE_RAM_ATTR isr_14();
  static void ICACHE_RAM_ATTR isr_15();
  static void ICACHE_RAM_ATTR isr_16();
  static void ICACHE_RAM_ATTR isr_17();
  static void ICACHE_RAM_ATTR isr_18();
  static void ICACHE_RAM_ATTR isr_19();
  static void ICACHE_RAM_ATTR isr_20();
  static void ICACHE_RAM_ATTR isr_21();
  static void ICACHE_RAM_ATTR isr_35();
  static void ICACHE_RAM_ATTR isr_36();
  static void ICACHE_RAM_ATTR isr_37();
  static void ICACHE_RAM_ATTR isr_38();
  static void ICACHE_RAM_ATTR isr_39();
  static void ICACHE_RAM_ATTR isr_40();
  static void ICACHE_RAM_ATTR isr_41();
  static void ICACHE_RAM_ATTR isr_42();
  static void ICACHE_RAM_ATTR isr_47();
  static void ICACHE_RAM_ATTR isr_48();

  static volatile unsigned long lastInterruptTime_1;
  static volatile unsigned long lastInterruptTime_2;
  static volatile unsigned long lastInterruptTime_4;
  static volatile unsigned long lastInterruptTime_5;
  static volatile unsigned long lastInterruptTime_6;
  static volatile unsigned long lastInterruptTime_7;
  static volatile unsigned long lastInterruptTime_8;
  static volatile unsigned long lastInterruptTime_9;
  static volatile unsigned long lastInterruptTime_10;
  static volatile unsigned long lastInterruptTime_11;
  static volatile unsigned long lastInterruptTime_12;
  static volatile unsigned long lastInterruptTime_13;
  static volatile unsigned long lastInterruptTime_14;
  static volatile unsigned long lastInterruptTime_15;
  static volatile unsigned long lastInterruptTime_16;
  static volatile unsigned long lastInterruptTime_17;
  static volatile unsigned long lastInterruptTime_18;
  static volatile unsigned long lastInterruptTime_19;
  static volatile unsigned long lastInterruptTime_20;
  static volatile unsigned long lastInterruptTime_21;
  static volatile unsigned long lastInterruptTime_35;
  static volatile unsigned long lastInterruptTime_36;
  static volatile unsigned long lastInterruptTime_37;
  static volatile unsigned long lastInterruptTime_38;
  static volatile unsigned long lastInterruptTime_39;
  static volatile unsigned long lastInterruptTime_40;
  static volatile unsigned long lastInterruptTime_41;
  static volatile unsigned long lastInterruptTime_42;
  static volatile unsigned long lastInterruptTime_47;
  static volatile unsigned long lastInterruptTime_48;
#endif
};

#endif