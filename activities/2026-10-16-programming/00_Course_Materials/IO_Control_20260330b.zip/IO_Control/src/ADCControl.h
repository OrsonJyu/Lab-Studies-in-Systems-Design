#ifndef ADCCONTROL_H
#define ADCCONTROL_H

#include "Control.h"
//#include <driver/adc.h>	//	deprecated 
#include <esp_adc/adc_oneshot.h>
#include <soc/adc_channel.h>
#include "Debug.h"

class PinManager;

enum ADCControlAttenuation { ADCControl_DB_0 = 0,    //  0 to 0.75V, default value for attenuation
                             ADCControl_DB_2_5 = 1,  //  0 to 1.05V
                             ADCControl_DB_6 = 2,    //  0 to 1.3V
                             //ADCControl_DB_11 = 3    //  0 to 2.5V
							 ADCControl_DB_12 = 3 
};

const adc_atten_t DefaultADCAttenuation= ADC_ATTEN_DB_12;
const adc_bitwidth_t DefaultADCBitWidth=ADC_BITWIDTH_DEFAULT;
const adc_channel_t DefaultADCChannel = ADC_CHANNEL_0;
const int DefaultADCControlBitWidth = 12;
const ADCControlAttenuation DefaultADCControlAttenuation= ADCControl_DB_12;
//const ADCControlAttenuation DefaultADCAttenuation = ADCControl_DB_11;
//const int DefaultADCBitWidth = 12;


class _ADCControlHandles
{
public:
	//	handle for adc units and their usage count
	
#ifdef CONFIG_IDF_TARGET_ESP32C3
	//	only support use of ADC1 in ESP32C3
	adc_oneshot_unit_handle_t adc1_handle;
	int adc1_oneshot_handle_count;
#endif
	
#ifdef CONFIG_IDF_TARGET_ESP32S3
	adc_oneshot_unit_handle_t adc1_handle;
	int adc1_oneshot_handle_count;
	adc_oneshot_unit_handle_t adc2_handle;
	int adc2_oneshot_handle_count;
#endif

	_ADCControlHandles();
	
	err_t	requestHandle(uint8_t adc_index,adc_oneshot_unit_handle_t& _handle);
		//	
		//	request for one adc unit, with unit no = adc_index
		//	for ESP32C3 and ESP32S3, adc_index = 1 or 2	
		//
	err_t releaseHandle(uint8_t adc_index);
		//	
		//	release for one adc unit, with unit no = adc_index
		//	for ESP32C3 and ESP32S3, adc_index = 1 or 2	
		//
};


class ADCControl : public Control {
protected:

	static _ADCControlHandles adcHandleMgr;

  //adc_bits_width_t adc2BitWidth;
  adc_oneshot_unit_handle_t	adc_handle;
  adc_oneshot_chan_cfg_t adc_channel_config;
  adc_channel_t adc_channel;
  //adc1_channel_t adc1_channel;
  //adc2_channel_t adc2_channel;

  uint8_t adcIndex;    
	//  for ESP32C3, only = 1
	//	for ESP32S3, only = 1 or 2
  uint8_t adcChannel;  
	//  for ESP32C3, adcChannel in [0,4]
	//	for ESP32S3, adcChannel is in [0,9] for both adcIndex=1 and 2
  int adcPinIndex;  //  corresponding pin of the ADC
  //int adcBitWidth;
  //ADCControlAttenuation adcAtten;

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

  err_t applyBitWidth();
  err_t applyChannelAttenuation();

  std::vector<uint16_t> thres;  //	thresholds for determining index of adc value
  int lastValue;
  int lastIndex;
  ulong_t lastChangeTime;

  friend PinManager;

public:
  ADCControl();

  static int getStaticClsID() {
    return CLS_ADC;
  }

  err_t init(uint8_t _adcIndex, uint8_t _adcChannel, bool _permitScheduler = true);
  //	initialize and enable this Control object
  
  err_t setBitWidth(uint8_t bitWidth);
  //  set bit width; failed if this is not active
  //  return error code
  err_t setChannelAttenuation(ADCControlAttenuation attenuation);
  //  set channel attenuation; failed if this is not active
  //  return error code
  int16_t read();
  //  return value >=0 means no error
  //  otherwise, return error code; failed if this is not active
  uint16_t getMaxValue();
  //	return maximum value from ADCControl::read()

  err_t setThreshold(std::vector<uint16_t> _thres);
  //	failed if this is not active
  //	return error code

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  bool isIndexChanged() {
    return status & ADCControlEventHandler_IndexChanged;
  }

  uint8_t getChannel(){
    return adcChannel;
  }

  uint8_t getUnit(){
    return adcIndex;
  }

  uint32_t getLastChangeTime() {
    return lastChangeTime;
  }
  uint32_t getLastValue() {
    return lastValue;
  }
  uint8_t getLastIndex() {
    return lastIndex;
  }
  
  err_t request();

  err_t release();
};

#endif