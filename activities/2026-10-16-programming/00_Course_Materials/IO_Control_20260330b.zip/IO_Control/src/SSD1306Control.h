#ifndef SSD1306CONTROL_H
#define SSD1306CONTROL_H

#include "Control.h"
#include "Debug.h"
#include "I2CControl.h"
#include <Adafruit_SSD1306.h>

class SSD1306Control : public Control {
protected:

  Adafruit_SSD1306* display;

  I2CMasterControl* i2c = 0;
  int i2cAddr = -1;

  uint16_t screenWidth = 0;
  uint16_t screenHeight = 0;
  int8_t oledReset = -1;

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

public:

  SSD1306Control();

  err_t init(I2CMasterControl& _i2c, int _i2cAddr, uint16_t _screenWidth, uint16_t _screenHeight, int8_t _oledReset);

  Adafruit_SSD1306& getDisplay();

  ~SSD1306Control();

  static int getStaticClsID() {
    return CLS_SSD1306;
  }

  err_t request();

  err_t release();

  friend class PinManager;
};


#endif