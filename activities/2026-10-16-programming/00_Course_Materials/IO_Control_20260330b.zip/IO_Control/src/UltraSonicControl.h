#ifndef ULTRASONICCONTROL_H
#define ULTRASONICCONTROL_H

#include "Control.h"
#include "BinOutControl.h"
#include "BinInControl.h"
#include "Debug.h"

class PinManager;

class UltraSonicControl : public Control {
protected:

  int trigPinIndex = -1;

  int echoPinIndex = -1;

  bool isMeasureStarted = false;

  double distance = 0;

  bool isInit();

  err_t startControl();

  err_t stopControl();

public:
  UltraSonicControl();

  err_t request();

  err_t release();

  BinOutControl* binOutCtrl = nullptr;

  BinInControl* binInCtrl = nullptr;

  err_t init(int _trigPinIndex, int _echoPinIndex, bool _permitScheduler = true);

  static int getStaticClsID() {
    return CLS_UltraSonic;
  }

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  err_t startMeasure();

  err_t stopMeasure();

  double getDistance();

  friend class PinManager;
};

#endif
