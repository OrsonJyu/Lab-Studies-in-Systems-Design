#ifndef RINGBUFFER_H
#define RINGBUFFER_H

#include <Arduino.h>

class RingBuffer {
private:
    byte* buffer;           // Pointer to the ring buffer
    size_t bufferSize;      // Total size of the buffer    
    size_t readIndex; 		// Index for reading data, head of the RingBuffer, and position to read the first byte
    size_t writeIndex;      // Index for writing data, end of the RingBuffer, and position to write the first byte
    size_t dataCount;       // Number of bytes currently stored in the buffer

public:
	//
	//	@brief	Construct RingBuffer with no of bytes = _size; if failed to allocate enough memory, capacity() will return 0
	//	@param _size 	No of bytes in RingBuffer
	//
    RingBuffer(size_t _size);
	
	//
	//	@brief	Destructor of RingBuffer
	//
    ~RingBuffer();

	//
	//	@brief	Get capacity of RingBuffer, ie, maximum no of bytes which can be stored in this RingBuffer
	//	@return	Maximum no of bytes which can be stored in this RingBuffer
	//
    size_t capacity() const;    //  no of bytes allocated for this RingBuffer
	
	//
	//	@brief	Clear the RingBuffer
	//	@return	None
	//
	void clear(); 

	//
	//	@brief	Get the read pointer of the RingBuffer, ie, position of the first byte where data can be read
	//	@return	Read pointer
	//
    size_t getReadIndex();
	
	//
	//	@brief	Get the write pointer of the RingBuffer, ie, position of the first byte where data can be written
	//	@return	Write pointer
	//
    size_t getWriteIndex();

	//
	//	@brief	Get pointer to internal buffer of the RingBuffer
	//	@return	Pointer to internal buffer
	//	
	byte* getInternalBuffer();

	//
	//	@brief	Advance write index by a given amount
	//	@return	Pointer to internal buffer
	//
    bool advanceWriteIndex(size_t bytesRead);

    //
	//	@brief	Check if RingBuffer is empty
	//	@return	true if empty, false otherwise
	//
    bool isEmpty() const;
	
	//
	//	@brief	Check if RingBuffer is full
	//	@return	true if full, false otherwise
	//
    bool isFull() const;
	
	//
	//	@brief	Get no of bytes available to read in RingBuffer
	//	@return	no of bytes available to read
	//
    size_t available() const;
	
	//
	//	@brief	Get no of bytes available for write in RingBuffer
	//	@return	no of bytes available for write
	//
    size_t availableForWrite() const;
	
	//
	//	@brief	Get no of bytes available for write continuously in RingBuffer, meaning that a continous block of data can be directly copied to RingBuffer without break
	//	@return	no of bytes available for write continuously
	//
    size_t availableForWriteContinuous() const;
	
	//
	//	@brief	Get no of bytes available for read continuously in RingBuffer, meaning that a continous block of data can be directly copied from RingBuffer without break
	//	@return	no of bytes available for read continuously
	//
    size_t availableForReadContinuous() const;
	
	//
	//	@brief	Write one byte to end of RingBuffer
	//	@param _data Data to be written
	//	@return	true if success, false if fail and no data is added to RingBuffer
	//
    bool write(byte _data);
	
	//
	//	@brief 	Write a number of bytes to end of RingBuffer
	//	@param _data Pointer to byte array with data to be written to RingBuffer
	//	@param _len No of bytes in _data to be written
	//	@return	true if success, false if fail and no data is added to RingBuffer
	//	
    bool write(const byte* _data, size_t _len);
	
	//
	//	@brief	Read one byte from head of RingBuffer
	//	@param _data Pointer to byte to store read data
	//	@return	true if success, false if fail and no data is removed from RingBuffer
	//		
    bool read(byte& data);
	
	//
	//	@brief	Read at most _len bytes from head of RingBuffer
	//	@param _data Pointer to byte to store read data
	//	@param _len Maximum no of bytes to read from RingBuffer
	//	@return	No of bytes actually read from RingBuffer
	//	
    size_t read(byte* _data, size_t _len);  

	//
	//	@brief	Find first occurance of a null-terminated string in RingBuffer from head, and return distance from head
	//	@param _target	Null-terminated string to be found
	//	@return Number of bytes from current readIndex where _target is found
	//
    int find(const char* target);

	//
	//	@brief	Read data from RingBuffer till 1st occurance of _target (data read includes _target)
	//	@param _data Buffer to hold the read data if _target is found
	//	@param _dataSize Size of _data
	//	@param _target	Null-terminated string to be found
	//	@return 0 if not found
	//			no of bytes removed if found
	//			-<lenght> if found but _dataSize < <length>, where <length>=no of bytes to be removed; note that nothing is removed from RingBuffer in this case
	//
    int readUntil(byte* _data, size_t _dataSize, const char* _target);

	//
	//	@brief	Skip data in RingBuffer until _target is found
	//	@param _target	Null-terminated string to be found
	//	@return	No of bytes being removed (including _target) if found 
	//			-1 if not found
	//
    int skipUntil(const char* _target);

    //	int getLengthToTarget(const char* target);
};

#endif
