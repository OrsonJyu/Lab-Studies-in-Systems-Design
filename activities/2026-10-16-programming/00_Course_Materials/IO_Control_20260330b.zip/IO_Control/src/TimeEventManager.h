#ifndef TIME_EVENT_MANAGER
#define TIME_EVENT_MANAGER

#include "Control.h"
//#include <Arduino.h>
//#include <TaskSchedulerDeclarations.h>
#include <vector>

#ifdef CONFIG_IDF_TARGET_ESP32S3
  #define CORE_TO_PIN 1
#elif defined(CONFIG_IDF_TARGET_ESP32C3)
  #define CORE_TO_PIN 0
#endif


class TimeEventManager {
public:

  //static Scheduler scheduler;

  //static Task* task;
  
  static TaskHandle_t taskHandle;

  static std::vector<Control*> timerTargets;

  static void schedulerStartNow();

  static void schedulerExecute();

  static void timerCallback(void *parameter);

  static uint32_t loopCount;

  static err_t addTimeEvent(Control* _ctrl);
    //  return 0 if no error, otherwise error code
    //  Note: the return value of TimeEventManager_ControlAlreadyAdded is more like a warning than error 

  static err_t removeTimeEvent(Control* target);
    //  return 0 if no error, otherwise error code
    //  Note: the return value of TimeEventManager_ControlNotFound is more like a warning than error

  static ulong_t getCurrentTime();
};

#endif
