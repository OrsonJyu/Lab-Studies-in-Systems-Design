#ifndef SERVOCONTROL_H
#define SERVOCONTROL_H

#include "LedcControl.h"

class ServoControl;

struct Servo_command {
  uint8_t mode;  //0 for SetAngle, 1 for MoveFromToAngle
};

struct Servo_command_setAngle : public Servo_command {
  double endPos;
  uint32_t duration;
};

struct Servo_command_moveFromToAngle : public Servo_command {
  double startPos;
  double endPos;
  uint32_t duration;
};

class ServoSequence {
public:
  std::vector<Servo_command*> sequence;
  err_t addSetAngle(uint32_t duration, double _endPos, ServoControl& _ctrl);
  err_t addMoveFromToAngle(uint32_t _duration, double _startPos, double _endPos, ServoControl& _ctrl);
  err_t clearCommand();
};

class ServoControl : public LedcControl {
protected:
  double minAngle = 0;
  double maxAngle = 180;
  uint32_t minUS = 410;   // 0.5ms
  uint32_t maxUS = 2048;  // 2.5ms

  double degPerMS = 60 / 100.0;  //	maximum speed of this servo = 60deg per 100ms

  double currentAngle = 0;

  //bool isInit();         //  refer to comments on Control::init()
  //err_t startControl();  //  refer to comments on Control::startControl()
  //err_t stopControl();   //  refer to comments on Control::stopControl()

  ServoSequence localSeq;

  uint32_t seqTargetRelStartTime;

  int seqRepeatCount = 0;  // -1 for infinite loop
  uint8_t commandPointer = 0;

  bool isCurrentCommandStarted = false;
  uint32_t currentCmdStartTime;


public:
  //    Note:
  //      no public method for changing frequency and duty resolution, as they are fixed (50Hz, and 14-bit respectively)
  //      all ServoControl share the same timer
  ServoControl();
  //ServoControl(int _pinIndex);
  //ServoControl(int _pinIndex, double _minAngle, double _maxAngle, uint32_t _minUS, uint32_t _maxUS);

  err_t init(uint8_t _pinIndex, bool _permitScheduler = true);
  //void init(int _pinIndex, double _minAngle, double _maxAngle, uint32_t _minUS, uint32_t _maxUS);
  //void init(int _pinIndex, unsigned long _startTime, int _interval, ControlEventHandler _handler);

  //void update(uint32_t currentMillis) override;
  void _preHandler() override;

  ~ServoControl();

  static int getStaticClsID() {
    return CLS_SERVO;
  }

  err_t setAngleRange(double _minAngle, double _maxAngle);
  double getMinAngle() {
    return minAngle;
  }
  double getMaxAngle() {
    return maxAngle;
  }
  err_t setDurationRange(uint32_t _minUS, uint32_t _maxUS);
  uint32_t getMinUS() {
    return minUS;
  }
  uint32_t getMaxUS() {
    return maxUS;
  }

  err_t setDegPerMS(double _degPerMS);  //	set maximum speed of the servo motor
  double getDegPerMS() {
    return degPerMS;
  }

  err_t setAngle(double angle);  //  set angle of the servo; map [minAngle,maxAngle] to [minUS,maxUS]
  double getAngle();             //	get value in last call to setAngle()

  err_t playRelTime(ServoSequence& seq, uint32_t _seqRelStartTime, int32_t _seqRepeatCount);  //not yet implemented
                                                                                         //bool isPlaying();                               //not yet implemented
                                                                                         //int playStop();                                 //not yet implemented

  err_t playAbsTime(ServoSequence& _seq, uint32_t _seqAbsStartTime, int32_t _seqRepeatCount);

  bool shouldPause = false;

  err_t pauseBeforeNextCommand();

  err_t resume();

  int32_t getSeqExecutedCount();

  int32_t getCurrentCommandIndex();

  bool isAngleOutOfBound() {
    return status & ServoControlEventHandler_AngleOutOfBound;
  }

  err_t request();

  err_t release();

  friend class PinManager;
};


#endif