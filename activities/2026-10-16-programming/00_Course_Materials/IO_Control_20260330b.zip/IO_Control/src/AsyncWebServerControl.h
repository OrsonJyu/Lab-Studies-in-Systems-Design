#ifndef ASYNCWEBSERVER_CONTROL_H
#define ASYNCWEBSERVER_CONTROL_H

#include <ArduinoJson.h>
#include "Control.h"
#include <ESPAsyncWebServer.h>
#include "WiFiControl.h"
#include "HTTPClientControl.h"

typedef void (*AsyncHTTPServerRequestHandler)(AsyncWebServerRequest* req);
typedef void (*AsyncWSServerEventHandler)(AsyncWebSocket* server,
                                          AsyncWebSocketClient* client,
                                          AwsEventType type,
                                          void* arg, uint8_t* data, size_t len);


class AsyncWebServerControl : public Control {
private:
  bool _isInit = false;
  bool checkAPIValid(String api);
protected:
  AsyncWebServer* _server;

  AsyncWebSocket* _ws;

  String httpBasePath = "";

  String wsBasePath = "";

  void _preHandler();
  void _postHandler();


public:
  AsyncWebServerControl();
  err_t init(WiFiControl& _wifiCtrl);
  err_t setHTTPBasePath(String _httpBase);  //   cannot be changed after "begin()"
  err_t setWSBasePath(String _wsBase);      //  cannot be changed after "begin()"

  err_t begin();
  err_t beginWithWS(String _wsPath);
  err_t beginWithWS(String _wsPath, AsyncWSServerEventHandler _wsHandler);
  err_t onHTTP(const String& _pathRel, HTTPClientControl_HTTPMethod_t _method, AsyncHTTPServerRequestHandler _handler);
  //  return ID if >=0, error code if <0
  //  _pathRel relative to HTTPBasePath
  err_t onHTTPNotFound(AsyncHTTPServerRequestHandler _handler);

  err_t serveStaticFile(const String& _pathRel, fs::FS &fs, const String& filePath);

  err_t onWS(AsyncWSServerEventHandler _wsHandler);
  //  return ID if >=0, error code if <0
  err_t onWSJSON(String& _cmd, JsonDocument& _json);
  //    return ID if >=0, error code if <0

  size_t getWSClientCount();

  err_t broadcastWS(String msg);

  err_t sendWS(AsyncWebSocketClient* client, String msg);

  err_t removeHandler(uint16_t _id);

  AsyncWebServer& getServer();

  bool isInit();

  err_t startControl();

  err_t stopControl();

  err_t request();

  err_t release();
};

#endif