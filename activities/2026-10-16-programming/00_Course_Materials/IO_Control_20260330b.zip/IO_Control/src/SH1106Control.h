#ifndef SH1106CONTROL_H
#define SH1106CONTROL_H

#include "Control.h"
#include "Debug.h"
#include "I2CControl.h"
#include <Adafruit_SH110X.h>

class SH1106Control : public Control {
protected:

  Adafruit_SH1106G* display;

  I2CMasterControl* i2c = 0;
  int i2cAddr = -1;

  uint16_t screenWidth = 0;
  uint16_t screenHeight = 0;
  int8_t oledReset = -1;

  bool isInit();         //  refer to comments on Control::init()
  err_t startControl();  //  refer to comments on Control::startControl()
  err_t stopControl();   //  refer to comments on Control::stopControl()

public:

  SH1106Control();

  err_t init(I2CMasterControl& _i2c, int _i2cAddr, uint16_t _screenWidth, uint16_t _screenHeight, int8_t _oledReset);

  Adafruit_SH1106G& getDisplay();

  ~SH1106Control();

  static int getStaticClsID() {
    return CLS_SH1106;
  }

  err_t request();

  err_t release();

  friend class PinManager;
};


#endif