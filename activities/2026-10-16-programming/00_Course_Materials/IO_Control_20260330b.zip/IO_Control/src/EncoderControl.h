#ifndef ENCODERCONTROL_H
#define ENCODERCONTROL_H

#include "Control.h"
#include "Debug.h"

class PinManager;

struct ISR_Data_Encoder {
  ulong_t eventTime;  //  time when interrupt occurred
  bool triggered;
  int state;  //  state of GPIO as read from the ISR
};

class EncoderControl : public Control {
protected:

  int inputMode;

  static int intrMode;

  bool isInterruptEnabled = false;

  volatile ISR_Data_Encoder* isrData;  //  use by ISR

  ISR_Data_Encoder isrDataCopy;  //  copy of isrData in update(), use in getInterruptTime() and getInterruptState()

  int pinAIndex = -1;

  int pinBIndex = -1;

  int32_t maxCount = 0;

  int32_t minCount = 0;

  uint32_t countRange = 0;

  bool isInit();

  err_t startControl();

  err_t stopControl();

  friend PinManager;

public:

  EncoderControl();

  static int getStaticClsID() {
    return CLS_ENCODER;
  }

  err_t init(int _pinAIndex, int _pinBIndex, int _inputMode = INPUT, int _intrMode = RISING, bool _permitScheduler = true);

  bool isEncoderTriggered() {
    return status & EncoderControlEventHandler_EncoderTriggered;
  }

  err_t enableInterrupt(int _intrMode);
  //  valid _intrMode: LOW, HIGHT, CHANGE, FALLING, RISING
  err_t disableInterrupt();

  //void update(ulong_t currentMillis) override;
  void _preHandler() override;

  err_t request();

  err_t release();

  bool copyIfTriggered();
  //  if ISR has been triggered, return true and copy ISR data to a local copy
  //  otherwise, return false, and local copy is untouched
  ulong_t getInterruptTime();  //  get time of last interrupt; should be used in handler when status&BinInControlEventHandler_BinInTriggered is true

  int getInterruptState();  //  get state when last ISR was invoked; should be used in handler when status&BinInControlEventHandler_BinInTriggered is true

  err_t setCurrentCount(int32_t _count);

  int32_t getCurrentCount();

  void setMaxCount(int32_t _maxCount);

  int32_t getMaxCount();

  void setMinCount(int32_t _minCount);

  int32_t getMinCount();

  void setRange(uint32_t _range);

  uint32_t getRange();

  // Add debounce interval (in microsecond)
  static const unsigned long DEBOUNCE_INTERVAL = 1000;

#ifdef CONFIG_IDF_TARGET_ESP32C3

  static int pinBIndex_whenPinAIs0;
  static int pinBIndex_whenPinAIs1;
  static int pinBIndex_whenPinAIs2;
  static int pinBIndex_whenPinAIs3;
  static int pinBIndex_whenPinAIs4;
  static int pinBIndex_whenPinAIs5;
  static int pinBIndex_whenPinAIs6;
  static int pinBIndex_whenPinAIs7;
  static int pinBIndex_whenPinAIs8;
  static int pinBIndex_whenPinAIs9;
  static int pinBIndex_whenPinAIs10;
  static int pinBIndex_whenPinAIs12;
  static int pinBIndex_whenPinAIs13;
  static int pinBIndex_whenPinAIs18;
  static int pinBIndex_whenPinAIs19;
  static int pinBIndex_whenPinAIs20;
  static int pinBIndex_whenPinAIs21;

  volatile static int32_t currentCount_whenPinAIs0;
  volatile static int32_t currentCount_whenPinAIs1;
  volatile static int32_t currentCount_whenPinAIs2;
  volatile static int32_t currentCount_whenPinAIs3;
  volatile static int32_t currentCount_whenPinAIs4;
  volatile static int32_t currentCount_whenPinAIs5;
  volatile static int32_t currentCount_whenPinAIs6;
  volatile static int32_t currentCount_whenPinAIs7;
  volatile static int32_t currentCount_whenPinAIs8;
  volatile static int32_t currentCount_whenPinAIs9;
  volatile static int32_t currentCount_whenPinAIs10;
  volatile static int32_t currentCount_whenPinAIs12;
  volatile static int32_t currentCount_whenPinAIs13;
  volatile static int32_t currentCount_whenPinAIs18;
  volatile static int32_t currentCount_whenPinAIs19;
  volatile static int32_t currentCount_whenPinAIs20;
  volatile static int32_t currentCount_whenPinAIs21;


  static void ICACHE_RAM_ATTR isr_0();
  static void ICACHE_RAM_ATTR isr_1();
  static void ICACHE_RAM_ATTR isr_2();
  static void ICACHE_RAM_ATTR isr_3();
  static void ICACHE_RAM_ATTR isr_4();
  static void ICACHE_RAM_ATTR isr_5();
  static void ICACHE_RAM_ATTR isr_6();
  static void ICACHE_RAM_ATTR isr_7();
  static void ICACHE_RAM_ATTR isr_8();
  static void ICACHE_RAM_ATTR isr_9();
  static void ICACHE_RAM_ATTR isr_10();
  static void ICACHE_RAM_ATTR isr_12();
  static void ICACHE_RAM_ATTR isr_13();
  static void ICACHE_RAM_ATTR isr_18();
  static void ICACHE_RAM_ATTR isr_19();
  static void ICACHE_RAM_ATTR isr_20();
  static void ICACHE_RAM_ATTR isr_21();

  // Add last interrupt time for each pin
  static volatile unsigned long lastInterruptTime_whenPinAIs0;
  static volatile unsigned long lastInterruptTime_whenPinAIs1;
  static volatile unsigned long lastInterruptTime_whenPinAIs2;
  static volatile unsigned long lastInterruptTime_whenPinAIs3;
  static volatile unsigned long lastInterruptTime_whenPinAIs4;
  static volatile unsigned long lastInterruptTime_whenPinAIs5;
  static volatile unsigned long lastInterruptTime_whenPinAIs6;
  static volatile unsigned long lastInterruptTime_whenPinAIs7;
  static volatile unsigned long lastInterruptTime_whenPinAIs8;
  static volatile unsigned long lastInterruptTime_whenPinAIs9;
  static volatile unsigned long lastInterruptTime_whenPinAIs10;
  static volatile unsigned long lastInterruptTime_whenPinAIs12;
  static volatile unsigned long lastInterruptTime_whenPinAIs13;
  static volatile unsigned long lastInterruptTime_whenPinAIs18;
  static volatile unsigned long lastInterruptTime_whenPinAIs19;
  static volatile unsigned long lastInterruptTime_whenPinAIs20;
  static volatile unsigned long lastInterruptTime_whenPinAIs21;

#elif defined(CONFIG_IDF_TARGET_ESP32S3)
  static int pinBIndex_whenPinAIs1;
  static int pinBIndex_whenPinAIs2;
  static int pinBIndex_whenPinAIs4;
  static int pinBIndex_whenPinAIs5;
  static int pinBIndex_whenPinAIs6;
  static int pinBIndex_whenPinAIs7;
  static int pinBIndex_whenPinAIs8;
  static int pinBIndex_whenPinAIs9;
  static int pinBIndex_whenPinAIs10;
  static int pinBIndex_whenPinAIs11;
  static int pinBIndex_whenPinAIs12;
  static int pinBIndex_whenPinAIs13;
  static int pinBIndex_whenPinAIs14;
  static int pinBIndex_whenPinAIs15;
  static int pinBIndex_whenPinAIs16;
  static int pinBIndex_whenPinAIs17;
  static int pinBIndex_whenPinAIs18;
  static int pinBIndex_whenPinAIs19;
  static int pinBIndex_whenPinAIs20;
  static int pinBIndex_whenPinAIs21;
  static int pinBIndex_whenPinAIs35;
  static int pinBIndex_whenPinAIs36;
  static int pinBIndex_whenPinAIs37;
  static int pinBIndex_whenPinAIs38;
  static int pinBIndex_whenPinAIs39;
  static int pinBIndex_whenPinAIs40;
  static int pinBIndex_whenPinAIs41;
  static int pinBIndex_whenPinAIs42;
  static int pinBIndex_whenPinAIs47;
  static int pinBIndex_whenPinAIs48;

  volatile static int32_t currentCount_whenPinAIs1;
  volatile static int32_t currentCount_whenPinAIs2;
  volatile static int32_t currentCount_whenPinAIs4;
  volatile static int32_t currentCount_whenPinAIs5;
  volatile static int32_t currentCount_whenPinAIs6;
  volatile static int32_t currentCount_whenPinAIs7;
  volatile static int32_t currentCount_whenPinAIs8;
  volatile static int32_t currentCount_whenPinAIs9;
  volatile static int32_t currentCount_whenPinAIs10;
  volatile static int32_t currentCount_whenPinAIs11;
  volatile static int32_t currentCount_whenPinAIs12;
  volatile static int32_t currentCount_whenPinAIs13;
  volatile static int32_t currentCount_whenPinAIs14;
  volatile static int32_t currentCount_whenPinAIs15;
  volatile static int32_t currentCount_whenPinAIs16;
  volatile static int32_t currentCount_whenPinAIs17;
  volatile static int32_t currentCount_whenPinAIs18;
  volatile static int32_t currentCount_whenPinAIs19;
  volatile static int32_t currentCount_whenPinAIs20;
  volatile static int32_t currentCount_whenPinAIs21;
  volatile static int32_t currentCount_whenPinAIs35;
  volatile static int32_t currentCount_whenPinAIs36;
  volatile static int32_t currentCount_whenPinAIs37;
  volatile static int32_t currentCount_whenPinAIs38;
  volatile static int32_t currentCount_whenPinAIs39;
  volatile static int32_t currentCount_whenPinAIs40;
  volatile static int32_t currentCount_whenPinAIs41;
  volatile static int32_t currentCount_whenPinAIs42;
  volatile static int32_t currentCount_whenPinAIs47;
  volatile static int32_t currentCount_whenPinAIs48;


  static void ICACHE_RAM_ATTR isr_1();
  static void ICACHE_RAM_ATTR isr_2();
  static void ICACHE_RAM_ATTR isr_4();
  static void ICACHE_RAM_ATTR isr_5();
  static void ICACHE_RAM_ATTR isr_6();
  static void ICACHE_RAM_ATTR isr_7();
  static void ICACHE_RAM_ATTR isr_8();
  static void ICACHE_RAM_ATTR isr_9();
  static void ICACHE_RAM_ATTR isr_10();
  static void ICACHE_RAM_ATTR isr_11();
  static void ICACHE_RAM_ATTR isr_12();
  static void ICACHE_RAM_ATTR isr_13();
  static void ICACHE_RAM_ATTR isr_14();
  static void ICACHE_RAM_ATTR isr_15();
  static void ICACHE_RAM_ATTR isr_16();
  static void ICACHE_RAM_ATTR isr_17();
  static void ICACHE_RAM_ATTR isr_18();
  static void ICACHE_RAM_ATTR isr_19();
  static void ICACHE_RAM_ATTR isr_20();
  static void ICACHE_RAM_ATTR isr_21();
  static void ICACHE_RAM_ATTR isr_35();
  static void ICACHE_RAM_ATTR isr_36();
  static void ICACHE_RAM_ATTR isr_37();
  static void ICACHE_RAM_ATTR isr_38();
  static void ICACHE_RAM_ATTR isr_39();
  static void ICACHE_RAM_ATTR isr_40();
  static void ICACHE_RAM_ATTR isr_41();
  static void ICACHE_RAM_ATTR isr_42();
  static void ICACHE_RAM_ATTR isr_47();
  static void ICACHE_RAM_ATTR isr_48();

  // Add last interrupt time for each pin
  static volatile unsigned long lastInterruptTime_whenPinAIs1;
  static volatile unsigned long lastInterruptTime_whenPinAIs2;
  static volatile unsigned long lastInterruptTime_whenPinAIs4;
  static volatile unsigned long lastInterruptTime_whenPinAIs5;
  static volatile unsigned long lastInterruptTime_whenPinAIs6;
  static volatile unsigned long lastInterruptTime_whenPinAIs7;
  static volatile unsigned long lastInterruptTime_whenPinAIs8;
  static volatile unsigned long lastInterruptTime_whenPinAIs9;
  static volatile unsigned long lastInterruptTime_whenPinAIs10;
  static volatile unsigned long lastInterruptTime_whenPinAIs11;
  static volatile unsigned long lastInterruptTime_whenPinAIs12;
  static volatile unsigned long lastInterruptTime_whenPinAIs13;
  static volatile unsigned long lastInterruptTime_whenPinAIs14;
  static volatile unsigned long lastInterruptTime_whenPinAIs15;
  static volatile unsigned long lastInterruptTime_whenPinAIs16;
  static volatile unsigned long lastInterruptTime_whenPinAIs17;
  static volatile unsigned long lastInterruptTime_whenPinAIs18;
  static volatile unsigned long lastInterruptTime_whenPinAIs19;
  static volatile unsigned long lastInterruptTime_whenPinAIs20;
  static volatile unsigned long lastInterruptTime_whenPinAIs21;
  static volatile unsigned long lastInterruptTime_whenPinAIs35;
  static volatile unsigned long lastInterruptTime_whenPinAIs36;
  static volatile unsigned long lastInterruptTime_whenPinAIs37;
  static volatile unsigned long lastInterruptTime_whenPinAIs38;
  static volatile unsigned long lastInterruptTime_whenPinAIs39;
  static volatile unsigned long lastInterruptTime_whenPinAIs40;
  static volatile unsigned long lastInterruptTime_whenPinAIs41;
  static volatile unsigned long lastInterruptTime_whenPinAIs42;
  static volatile unsigned long lastInterruptTime_whenPinAIs47;
  static volatile unsigned long lastInterruptTime_whenPinAIs48;

#endif
};

#endif