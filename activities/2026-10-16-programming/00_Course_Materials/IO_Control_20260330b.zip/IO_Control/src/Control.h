#ifndef CONTROL_H
#define CONTROL_H

//#include <Wire.h>
//#include <vector>
#include <Arduino.h>
#include "Debug.h"
//using namespace std;

#ifndef err_t
typedef s8_t err_t;  //  type of error code returned from a function; already defined
#endif
//  typedef s8_t err_t;     //  type of error code returned from a function; already defined
//  typedef byte uint8_t;   //  already defined
//  typedef unsigned int uint32_t;  //  already defined
typedef unsigned long ulong_t;

#define DownCastControl(_var, _cls, _ctrl) \
  if (_ctrl.getClsID() != _cls::getStaticClsID()) { \
    _ctrl.status = ControlEventHandler_ControlClsError; \
    return; \
  } \
  _cls& _var = static_cast<_cls&>(_ctrl);

/*
    if (_ctrlobj.isTimeoutSet == 1) { \
      if (_ctrlobj.timeoutCount > 0) { \
        _ctrlobj.timeoutCount--; \
        if (_ctrlobj.timeoutCount == 0) { \
          _ctrlobj.TimeoutEventHandler(_ctrlobj); \
          _ctrlobj.isTimeoutSet = 0; \
        } \
      } \
    } else if (_ctrlobj.isTimeoutSet == 2) { \
      if (_ctrlobj.handlerCurrentMillis - _ctrlobj.setTimeoutTriggeredTime >= _ctrlobj.timeoutRelTime) { \
        _ctrlobj.TimeoutEventHandler(_ctrlobj); \
        _ctrlobj.isTimeoutSet = 0; \
      } \
    } else if (_ctrlobj.isTimeoutSet == 3) { \
      if (_ctrlobj.handlerCurrentMillis >= _ctrlobj.timeoutAbsTime) { \
        _ctrlobj.TimeoutEventHandler(_ctrlobj); \
        _ctrlobj.isTimeoutSet = 0; \
      } \
    } \
*/

#define ESC(...) __VA_ARGS__
    //  for use in macro when input is a brace-enclosed iist
    //  from https://stackoverflow.com/questions/24481810/how-to-remove-the-enclosing-parentheses-with-macro

//    _code(_ctrlobj); \

// #define DeclareHandler(_handler, _ctrlobj, _ctrlcls, ...) \
  // void _handler(Control& ___ctrl___) { \
    // DownCastControl(_ctrlobj, _ctrlcls, ___ctrl___); \
	// _ctrlobj.nestedCount++;	\
	// if (_ctrlobj.nestedCount==1)	\
		// _ctrlobj.handleTimeout(); \ 
		// __VA_ARGS__	\
	// _ctrlobj.nestedCount--;	\
  // }
#define DeclareHandler(_handler, _ctrlobj, _ctrlcls, ...) \
  void _handler(Control& ___ctrl___) { \
    DownCastControl(_ctrlobj, _ctrlcls, ___ctrl___); \
		__VA_ARGS__	\
  }
/*#define DeclareHandlerEnd(_handler, _ctrlcls, _ctrlobj) \
  }*/

#ifndef _BV
#define _BV(bit) (1 << (bit))
#endif
/*_ctrlobj.timeoutCount = -1; \*/
class PinManager;
class Control;

typedef void (*ControlEventHandler)(Control& ctrl);

typedef void (*TimeoutEventHandler)(Control& ctrl);

enum {
  CLS_SERVO,
  CLS_PWM,
  CLS_TONE,
  CLS_ADDRLED,
  CLS_ADC,
  CLS_BININ,
  CLS_I2C,
  CLS_I2C_SLAVE,
  CLS_MPR121,
  CLS_BINOUT,
  CLS_SSD1306,
  CLS_SH1106,
  CLS_IOCONTROL,
  CLS_WIFI,
  CLS_DFPlayerMP3,
  CLS_SoftwarePlayerMP3,
  CLS_Motor,
  CLS_UltraSonic,
  CLS_MAX7219,
  CLS_UART,
  CLS_SPI,
  CLS_ENCODER,
  CLS_DHT,
  CLS_OneWire,
  CLS_N20,
  CLS_WEBSERVER,
  CLS_VL53L0X,
  CLS_BLE,
  CLS_INMP441,
  CLS_HWCDC,
  CLS_HTTPCLIENT,
  CLS_MENU
};

enum ControlEventHandler_StatusType {
  ControlEventHandler_ControlClsError = 1,
  ControlEventHandler_SchedulerTimeEvent = 1 << 1,

  MPR121ControlEventHandler_TouchReleaseEvent = 1 << 8,

  BinInControlEventHandler_BinInTriggered = 1 << 8,

  EncoderControlEventHandler_EncoderTriggered = 1 << 8,

  ADCControlEventHandler_IndexChanged = 1 << 8,

  BinOutControlEventHandler_AllSeqStarted = 1 << 8,
  BinOutControlEventHandler_AllSeqEnded = 1 << 9,
  BinOutControlEventHandler_OneSeqStarted = 1 << 10,
  BinOutControlEventHandler_OneSeqNewCmdStarted = 1 << 11,
  BinOutControlEventHandler_OneSeqPaused = 1 << 12,
  BinOutControlEventHandler_OneSeqEnded = 1 << 13,

  LedcControlEventHandler_AllSeqStarted = 1 << 8,
  LedcControlEventHandler_AllSeqEnded = 1 << 9,
  LedcControlEventHandler_OneSeqStarted = 1 << 10,
  LedcControlEventHandler_OneSeqNewCmdStarted = 1 << 11,
  LedcControlEventHandler_OneSeqPaused = 1 << 12,
  LedcControlEventHandler_OneSeqEnded = 1 << 13,

  //	PWMControlEventHandler_AllSeqStarted = 1 << 8,	//	replace by LedcControlEventHandler_AllSeqStarted
  //	PWMControlEventHandler_AllSeqEnded = 1 << 9,	//	replace by LedcControlEventHandler_AllSeqEnded
  //	PWMControlEventHandler_OneSeqStarted = 1 << 10,	//	replace by LedcControlEventHandler_OneSeqStarted
  //	PWMControlEventHandler_OneSeqNewCmdStarted = 1 << 11,	// replace by LedcControlEventHandler_OneSeqNewCmdStarted
  //	PWMControlEventHandler_OneSeqPaused = 1 << 12,	//	replace by LedcControlEventHandler_OneSeqPaused
  //	PWMControlEventHandler_OneSeqEnded = 1 << 13,	//	replace by LedcControlEventHandler_OneSeqEnded

  //	ToneControlEventHandler_AllSeqStarted = 1 << 8,	//	replace by LedcControlEventHandler_AllSeqStarted
  //	ToneControlEventHandler_AllSeqEnded = 1 << 9,	//	replace by LedcControlEventHandler_AllSeqEnded
  //	ToneControlEventHandler_OneSeqStarted = 1 << 10,	//	replace by LedcControlEventHandler_OneSeqStarted
  //	ToneControlEventHandler_OneSeqNewCmdStarted = 1 << 11,	// replace by LedcControlEventHandler_OneSeqNewCmdStarted
  //	ToneControlEventHandler_OneSeqPaused = 1 << 12,	//	replace by LedcControlEventHandler_OneSeqPaused
  //	ToneControlEventHandler_OneSeqEnded = 1 << 13,	//	replace by LedcControlEventHandler_OneSeqEnded

  //	ServoControlEventHandler_AllSeqStarted = 1 << 8,	//	replace by LedcControlEventHandler_AllSeqStarted
  //	ServoControlEventHandler_AllSeqEnded = 1 << 9,		//	replace by LedcControlEventHandler_AllSeqEnded
  //	ServoControlEventHandler_OneSeqStarted = 1 << 10,	//	replace by LedcControlEventHandler_OneSeqStarted
  //	ServoControlEventHandler_OneSeqNewCmdStarted = 1 << 11,	// replace by LedcControlEventHandler_OneSeqNewCmdStarted
  //	ServoControlEventHandler_OneSeqPaused = 1 << 12,	//	replace by LedcControlEventHandler_OneSeqPaused
  //	ServoControlEventHandler_OneSeqEnded = 1 << 13,		//	replace by LedcControlEventHandler_OneSeqEnded
  ServoControlEventHandler_AngleOutOfBound = 1 << 14,

  UARTControlEventHandler_DataReceived = 1 << 8,

  I2CMasterControlEventHandler_DataReceived = 1 << 8,

  I2CSlaveControlEventHandler_DataReceived = 1 << 8,
  I2CSlaveControlEventHandler_DataRequested = 1 << 9,

  AddrLEDControlEventHandler_AllSeqStarted = 1 << 8,
  AddrLEDControlEventHandler_AllSeqEnded = 1 << 9,
  AddrLEDControlEventHandler_OneSeqStarted = 1 << 10,
  AddrLEDControlEventHandler_OneSeqNewCmdStarted = 1 << 11,
  AddrLEDControlEventHandler_OneSeqPaused = 1 << 12,
  AddrLEDControlEventHandler_OneSeqEnded = 1 << 13,

  MAX7219ControlEventHandler_AllSeqStarted = 1 << 8,
  MAX7219ControlEventHandler_AllSeqEnded = 1 << 9,
  MAX7219ControlEventHandler_OneSeqStarted = 1 << 10,
  MAX7219ControlEventHandler_OneSeqNewCmdStarted = 1 << 11,
  MAX7219ControlEventHandler_OneSeqPaused = 1 << 12,
  MAX7219ControlEventHandler_OneSeqEnded = 1 << 13,

  N20ControlEventHandler_AllSeqStarted = 1 << 8,
  N20ControlEventHandler_AllSeqEnded = 1 << 9,
  N20ControlEventHandler_OneSeqStarted = 1 << 10,
  N20ControlEventHandler_OneSeqNewCmdStarted = 1 << 11,
  N20ControlEventHandler_OneSeqPaused = 1 << 12,
  N20ControlEventHandler_OneSeqEnded = 1 << 13,
  N20ControlEventHandler_IsStallingA = 1 << 14,
  N20ControlEventHandler_IsStallingB = 1 << 15,

  MP3EventHandler_AllSeqStarted = 1 << 8,
  MP3EventHandler_AllSeqEnded = 1 << 9,
  MP3EventHandler_OneSeqStarted = 1 << 10,
  MP3EventHandler_OneSeqNewCmdStarted = 1 << 11,
  MP3EventHandler_OneSeqPaused = 1 << 12,
  MP3EventHandler_OneSeqEnded = 1 << 13,
  MP3EventHandler_IsStallingA = 1 << 14,
  MP3EventHandler_IsStallingB = 1 << 15,
  MP3EventHandler_FinishedPlaying = 1 << 16
};

enum ControlErrorType { Control_OK = 0,
                        Control_NotInit = -1,
                        Control_NotActive = -2,
                        Control_InvalidPin = -3,
                        Control_PinNotAvailable = -4,
                        Control_NullEventHandler = -5,
                        Control_NoScheduler = -6,
                        Control_ActiveAlready = -7,
                        Control_MemAllocError = -8,
                        Control_SchedulerNotPermitted = -9,
                        Control_InvalidCapability = -10,
						Control_TimeoutAlreadyActive = -11,
						Control_TimeoutLE0=1,			//	warning; time for timeout event handler to be triggered is already passed
						Control_TimeoutNoActive = -12,
						Control_TimeoutInvalidID= -13,

                        IOControl_UnknownError = -30,

                        LedcControl_InvalidResolution = -30,
                        LedcControl_InvalidPinIndex = -31,
                        LedcControl_InternalError = -33,
                        LedcControl_SetDutyInvalidArg = -34,
                        LedcControl_UpdateDutyInvalidArg = -35,
                        LedcControl_SetFreqInvalidArg = -36,


                        TimeEventManager_ControlAlreadyAdded = -15,
                        TimeEventManager_ControlNotFound = -16,


                        ADCControl_InvalidBitWidth = -30,
                        ADCControl_InvalidChannelAttenuation = -31,
                        ADCControl_InvalidChannel = -32,
                        ADCControl_InvalidADC = -33,
                        //ADCControl_NotInit = -34,
                        //ADCControl_ADC1GetRawError = -35,
                        //ADCControl_ADC2TimeOutError = -36,
						ADCControl_ADCGetRawError = -35,
                        ADCControl_ADC2InvalidStateError = -37,
                        ADCControl_ThresholdOutOfBound = -38,
                        ADCControl_ThresholdError = -39,
                        ADCControl_UnknownError = -40,
						ADCControl_ADC1InitError = -41,
						ADCControl_ADC2InitError = -42,
						ADCControl_ADC1ReleaseError = -43,
						ADCControl_ADC2ReleaseError = -44,
						ADCControl_ADCConfigError=-45,	


                        BinInControl_InvalidPinMode = -30,
                        BinInControl_InvalidPinIndex = -31,
                        BinInControl_InterruptNotEnabled = -32,

                        EncoderControl_InvalidPinIndex = -31,
                        EncoderControl_InterruptNotEnabled = -32,


                        BinOutControl_InvalidPinIndex = -31,
                        BinOutControl_EmptyPlaySeq = -32,
                        BinOutControl_NotPlayingSequence = -33,
                        BinOutControl_IsNotPaused = -34,


                        AddrLEDControl_InvalidPinIndex = -31,
                        AddrLEDControl_EmptyPlaySeq = -32,
                        AddrLEDControl_ValueOutOfBound = -33,
                        AddrLEDControl_TargetOutOfBound = -34,
                        AddrLEDControl_TargetNotAvailable = -35,
                        AddrLEDControl_InvalidHSV = -36,
                        //AddrLEDControl_SeqObjIsNull = -37,
						AddrLEDControl_PlayIDNotActive = -37,	//	playID of the current playback action is not active/valid anymore
                        AddrLEDControl_NotPlayingSequence = -38,
						AddrLEDControl_FailToSetNewRepeatCount=-39,
						//AddrLEDControl_InvalidSeqObjID=-40,
						AddrLEDControl_InvalidPlayID=-40,


                        MAX7219Control_InvalidPinIndex = -31,
                        MAX7219Control_EmptyPlaySeq = -32,
                        MAX7219Control_ValueOutOfBound = -33,
                        MAX7219Control_TargetOutOfBound = -34,
                        MAX7219Control_TargetNotAvailable = -35,
                        MAX7219Control_InvalidHSV = -36,
                        MAX7219Control_SeqObjIsNull = -37,


                        ServoControl_InvalidPinIndex = -31,  //	replaced by LEDCControl_InvalidPinIndex
                        ServoControl_EmptyPlaySeq = -32,
                        ServoControl_InvalidMinMaxAngles = -33,
                        ServoControl_InvalidMinMaxDurations = -34,
                        ServoControl_AngleOutOfBound = -35,
                        ServoControl_SetAngleInternalError = -36,
                        ServoControl_DurationNotAchievable = -37,
                        ServoControl_NotPlayingSequence = -38,
                        ServoControl_IsNotPaused = -39,
                        ServoControl_FailInLEDC = -40,
                        ServoControl_InvalidDegPerMS = -41,


                        PWMControl_InvalidPinIndex = -31,  //	replaced by LEDCControl_InvalidPinIndex
                        PWMControl_EmptyPlaySeq = -32,
                        PWMControl_NotPlayingSequence = -33,
                        PWMControl_IsNotPaused = -34,
                        PWMControl_FailInLEDC = -35,


                        ToneControl_InvalidPinIndex = -31,  //	replaced by LEDCControl_InvalidPinIndex
                        ToneControl_EmptyPlaySeq = -32,
                        ToneControl_InvalidFreq = -33,
                        ToneControl_NotPlayingSequence = -34,
                        ToneControl_IsNotPaused = -35,
                        ToneControl_FailInLEDC = -36,


                        I2CMasterControl_InvalidI2CIndex = -30,
                        I2CMasterControl_InvalidSCL = -31,
                        I2CMasterControl_InvalidSDA = -32,
                        I2CMasterControl_InvalidClkFreq = -33,
                        I2CMasterControl_TwoWireBeginErr = -34,
                        I2CMasterControl_EndTrans_DataTooLong = -35,    //	refer to TowWire::endTransmission error code
                        I2CMasterControl_EndTrans_NACKOnAddress = -36,  //	refer to TowWire::endTransmission error code
                        I2CMasterControl_EndTrans_NACKOnData = -37,     //	refer to TowWire::endTransmission error code
                        I2CMasterControl_EndTrans_OtherError = -38,     //	refer to TowWire::endTransmission error code
                        I2CMasterControl_EndTrans_TimeOut = -39,        //	refer to TowWire::endTransmission error code
                        I2CMasterControl_EndTrans_UnknownError = -40,

                        I2CSlaveControl_InvalidI2CIndex = -30,
                        I2CSlaveControl_InvalidSCL = -31,
                        I2CSlaveControl_InvalidSDA = -32,
                        I2CSlaveControl_InvalidClkFreq = -33,
                        I2CSlaveControl_TwoWireBeginErr = -34,
                        I2CSlaveControl_InternalError = -35,
                        I2CSlaveControl_InsufficientRequestBuffer = -36,
                        I2CSlaveControl_TwoWireSetPinsErr = -37,

                        UARTControl_InvalidRXPinIndex = -30,
                        UARTControl_InvalidTXPinIndex = -31,
                        UARTControl_InvalidRTSPinIndex = -32,
                        UARTControl_InvalidCTSPinIndex = -33,
                        UARTControl_NoRXTX = -34,
                        UARTControl_FlowControlNotSupported = -35,
                        UARTControl_HWSerialError = -36,
                        UARTControl_InternalError = -37,
                        UARTControl_InvalidConfig = -38,

                        MPR121Control_I2CNotActive = -30,
                        MPR121Control_I2CAddrError = -31,
                        MPR121Control_IRQInvalid = -32,
                        MPR121Control_IRQError = -33,
                        MPR121Control_I2CSlaveInitError = -34,
                        MPR121Control_InvalidThresholdValue = -35,


                        SSD1306Control_I2CNotActive = -30,
                        SSD1306Control_I2CAddrError = -31,
                        SSD1306Control_I2CSlaveInitError = -34,


                        SH1106Control_I2CNotActive = -30,
                        SH1106Control_I2CAddrError = -31,
                        SH1106Control_I2CSlaveInitError = -34,

                        VL53L0XControl_I2CNotActive = -30,
                        VL53L0XControl_I2CAddrError = -31,
                        VL53L0XControl_I2CSlaveInitError = -34,

                        WiFiControl_ConnectionFailed = -30,
                        WiFiControl_NoEnoughSpace = 31,	//	not enough space in LittleFS for download file
                        WiFiControl_HTTPRequestFail = -32,
                        WiFiControl_LittleFSFail = -33,
                        WiFiControl_InvalidMode = -34,
                        WiFiControl_ConfigFailed = -35,
                        WiFiControl_SetDNSFailed = -36,
                        WiFiControl_SetSTABandwidthFailed = -37,
                        WiFiControl_ReconnectionFailed = -38,
                        WiFiControl_DisconnectionFailed = -39,
                        WiFiControl_EraseAPFailed = -40,
                        WiFiControl_SetAutoReconnectFailed = -41,
                        WiFiControl_STAModeNotStart = -42,
                        WiFiControl_CreateAPFailed = -43,
                        WiFiControl_ConfigAPFailed = -44,
                        WiFiControl_DisconnectAPFailed = -45,
                        WiFiControl_SetAPBandwidthFailed = -46,
                        WiFiControl_GetAPStationNumFailed = -47,
                        WiFiControl_APModeNotStart = -48,
                        WiFiControl_ScanFailed = -49,
                        WiFiControl_ScanRunning = -50,
                        WiFiControl_GetNetworkInfoFailed = -51,
						WiFiControl_NotEnoughMem=-52,	//	not enough memory for ringbuffer
						WiFiControl_CreateMutexFailed=-53,
						WiFiControl_SmartConfigStartFailed=-54,
						WiFiControl_SmartConfigStopFailed=-55,
            WiFiControl_NotConnected = -56,

                        WebServerControl_FileNotFound = -30,
                        WebServerControl_LittleFSFail = -33,

                        SoftwarePlayerMP3Control_WiFiNotInit = -30,
                        SoftwarePlayerMP3Control_LittleFSFailure = -32,
                        SoftwarePlayerMP3Control_SDFailure = -33,

                        MotorControl_InvalidDuty = -30,

                        OneWireControl_SlaveNotFound = -40,
                        OneWireControl_SlaveNotValid = -41,

                        N20Control_EmptyPlaySeq = -32,
                        N20Control_NotPlayingSequence = -38,
                        N20Control_IsNotPaused = -39,
                        N20Control_IsNotInitialized = -40,
                        N20Control_IsFineTuning = -41,
                        N20Control_UnidentifiedDirection = -42,
                        N20Control_IsAlreadyPlaying = -43,
                        N20Control_IsStalling = -44,

                        BLEControl_ServerNotExist = -32,
                        BLEControl_ServerHasBeenCreated = -33,
                        BLEControl_CharacteristicNotExist = -34,
                        BLEControl_IndexOutOfBound = -35,
                        BLEControl_IndexNotAvailable = -36,
                        BLEControl_ReachMaxNum = -37,

                        INMP441Control_NotRecording = -34,
                        INMP441Control_OpenFileFailed = -35,
                        INMP441Control_FileIsNull = -36,
                        INMP441Control_LittleFSFail = -37,

                        HTTPClientControl_WiFiControlNotInit = -32,
                        HTTPClientControl_NetworkClientSecureIsNull = -33,
                        HTTPClientControl_ConnectionFailed = -34,
                        HTTPClientControl_BufferIsFull = -35,
                        HTTPClientControl_NotConnected = -36,
                        HTTPClientControl_BufferIsEmpty = -37,
                        HTTPClientControl_IsSendingRequest = -38,
                        HTTPClientControl_IsReceivingResponse = -39,

                        DFPlayerMP3Control_PlayerFailedToBegin = -35,
                        DFPlayerMP3Control_InvalidPinIndex = -31,
                        DFPlayerMP3Control_EmptyPlaySeq = -32,
                        DFPlayerMP3Control_NotPlayingSequence = -33,
                        DFPlayerMP3Control_IsNotPaused = -34,
                        DFPlayerMP3Control_UartNotInit = -36,
                        DFPlayerMP3Control_ControlNotInit = -37,
                        DFPlayerMP3Control_NotEnoughMem = -38,
                        DFPlayerMP3Control_CreateMutexFailed = -39,
                        DFPlayerMP3Control_EVENT_NONE = -40,
                        DFPlayerMP3Control_TakeMutexFailed = -41,
                        DFPlayerMP3Control_PreviousCommandNotYetAck = -42,
						
						AsyncWebServerControl_WiFiNotInit = -32,
						AsyncWebServerControl_apiInvalid = -33,
						AsyncWebServerControl_fileNotExist = -34,
						AsyncWebServerControl_wsClientIsNull = -35,
						
						MenuControl_CmdError = -32,
						MenuControl_CmdNotMatch = -33,
						MenuControl_MenuItemNotExist = -34,
						MenuControl_NoMenuItemProcessor=-40,
						MenuControl_NoMenuProcessor = -35,
						MenuControl_ConsoleHandlerEnd = -36,
						MenuControl_ConsoleHandlerRunning = -37,
						MenuControl_EmptyInput=-38,
						MenuControl_NoMenuControl= -39,
};

// enum AddCommandError {
// AddCommand_OK = 0,

// ServoControl_DurationNotAchievable = -1
// };

//
//  Control class
//
//  Notes on usages:
//  1.  Control::init(...)
//      initialize Control object and check for validity of inputs
//      Will not allocate any resources in MCU for processing functions of Control
//      must invoke "setPermitScheduler" if want to use scheduler
//  2.  Control::request()
//		request resources for Control object in MCU for complete functioning of Control
//		most likely invoke PinManager::request(Control&) first
//	3.	PinManager::request(Control&)
//		for allocation of GPIO pins and other system resources (e.g initialization of controllers)
//      invoke Control::startControl()
//      refer to PinManager::request(Control&)
//	4.	Control::startControl()
//		
//	4.	Control::release()
//		release requested resources for this control
//		most likely invoke PinManager::release(Control&)
//  5.  PinManager::release(Control&)
//      release resources previously allocated for proper functioning of Control object in MCU
//      invoke Control::stopControl()
//      refer to PinManager::release(Control&)
//  6.  should only have default constructor, and no constructor with input parameters; call Control::init(...) for initialization
//

struct OneTimeoutEvent
{ TimeoutEventHandler timeoutEvtHdlr;
  enum {	NoTimeout=0,		//	no timeout event is active
			//TimeoutByCount, //	timeout event by acount is active; may be removed in future 
			TimeoutByRelTime,	//	timeout event by relative time is active
			TimeoutByAbsTime	//	timeout event by absolute time is active
  }	timeoutMode=NoTimeout;
  //uint8_t isTimeoutSet = 0;  //0 means not set, 1 means by count, 2 means by relative time, 3 means by absolute time

  //ulong_t setTimeoutTriggeredTime = 0;	//	time when the timeout event is activated
  //uint32_t timeoutCount = 0;	//	timeout in number of counts
  ulong_t timeoutRelTime = 0;	//	timeout in relative time
  ulong_t timeoutAbsTime = 0;	//	timeout in absolute time
  
  void init()
  {	timeoutEvtHdlr=nullptr;
	timeoutMode=NoTimeout;
	//setTimeoutTriggeredTime=0;
	timeoutRelTime=0;
	timeoutAbsTime=0;
  }
  
};

#define handlerCurrentMillis getUpdateTime()

class Control {
protected:
	bool active = false;
	bool schedulerEnabled = false;
	bool permitScheduler = true;  //  if false, enableScheduler will fail

	ControlEventHandler handler = nullptr;
  
	virtual void update(ulong_t currentMillis);
	virtual void _preHandler();
	virtual void _postHandler();
  
	ulong_t _updateTime;		//	time when update() is invoked, in MS
	ulong_t _startTime = 0;	//	time when the next update() and hence handler will be invoked
	ulong_t _interval = 0;	//	interval between invoking successive handler, in MS

	//ulong_t handlerCurrentMillis = 0;
  
  	void setActive(bool state);
	
	//
	//	@brief	Set whether this control permits running a scheduler or not; should only be invoked by init(...)
	//	@param permit	 true if enable, false if not and enableScheduler(...) will fail when invoked
	//	
	void setPermitScheduler(bool permit);

	//
	//	@brief	Determine whether Control has been properly initialized
	//	@return true if Control::init(...) has been successfully executed and returned no error
	//
	virtual bool isInit() = 0;
	
	//  return true if Control has been properly initialized
  //  at least Control::init(...) has been successfully executed
  virtual err_t startControl() = 0;
  //  allocate all necessary resources, and start this Control
  //  will execute "setActive(true)" on success
  //  pin(s) must have been checked for availability by PinManager before invoking this
  //  to be invoked by PinManager::request(Control&)
  virtual err_t stopControl() = 0;
  //  stop this Control, and free up all necessary resources
  //  should be restored to state which Control::startControl() can be executed properly
  //  will execute "setActive(false)" on success
  //  PinManager is responsible for marking pins available after successful return of this method
  //  to be invoked by PinManager::release(Control&)
  int clsID = -1;
  
  //
  //	for timeout event handling
  //
  OneTimeoutEvent* timeoutEvts=0;
  uint8_t maxTimeoutEvt=0;			//	maximum no of timeout event can be handled simultaneously
  uint8_t currTimeoutEvtIndex=0;	
  void _handleTimeout();			//	must be in public, as has to be accessible publicly due to use in DeclareHandler


public:
  // int errorCode;  //  error code from init(...); only use when object is created with non-default constructor
  //int nestedCount=0;
  int status = 0;	//	status to inform handler on what have been processed

	//
	//	@brief	Check if this Control is active, that is whether it has been allocated all necessary resources to operate, including GPIO(s)
	//	@return	true if active, false otherwise
  bool isActive();


  Control();

  // Control(ulong_t _startTime, ulong_t _interval, ControlEventHandler _handler);

  int getClsID();

  virtual err_t request();

  virtual err_t release();

	//
	//	@brief	Start a scheduler to invoke a handler periodically
	//	@param _startTime	Time (in ms) to start the scheduler; if 0, starts as soon as possible
	//	@param _interval	Interval (in ms); if 0, run as often as possible when available
	//	@param _handler		Handler to be invoked by scheduler, declared with DeclareHandler(...)
	//	@param _maxTimeoutEvent	Maximum no of timeout event which can be active simultaneously
	//	@return Control_OK (==0) if no error, error code if <0
	//						Note that TimeEventManager_ControlAlreadyAdded is more like a warning rather than error
	//						
  err_t enableScheduler(ulong_t _startTime, ulong_t _interval, ControlEventHandler _handler, uint8_t _maxTimeoutEvent=1);

	//
	//	@brief	Disable scheduler 
	//	@return Control_OK (==0) if no error, error code if <0
	//						Note that TimeEventManager_ControlNotFound is more like a warning rather than error
	//	
  err_t disableScheduler();

	//
	//	@brief	Check whether scheduler is enabled
	//	@return true if enabled, false otherwise
	//	
  bool isSchedulerEnabled();

  //err_t enableSequence(ulong_t _interval);


	//
	//	@brief	Get the time (in ms) when the update(...) method is invoked; note that update(..) will invoke _preHandler, handler, and _postHandler
	//	@return Time in ms
	//
	ulong_t getUpdateTime()
	{	return _updateTime;
	}
	//
	//	@brief	Get the expected time of the next call to update(...) 
	//	@return Time in ms
	//
	ulong_t getNextUpdateTime()
	{	return _startTime;
	}
	//
	//	@brief	Get the time interval between successive call to update(...)
	//	@return Time in ms
	//
	ulong_t getUpdateInterval()
	{	return _interval;
	}

	//
	//	Methods valid only invoked inside handler
	//
	
	//
	//	@brief	Check whether time event from scheduler triggered invocation of this handler
	//	@return true if time event from scheduler triggered this handler, false otherwise
	bool isSchedulerTimeEvent() {
		return status & ControlEventHandler_SchedulerTimeEvent;
	}

	//
	//	Timeout event related
	//	
  
	//
	//	@brief	Set maximum no of timeout event; after successfully set, all previous active timeout event will be cleared
	//	@param _maxEvtNum	maximum numebr of timeout event which can be active simultaneously
	//	@return Control_OK (==0): successfully set the new maximum number of timeout event	
	//	
	err_t setMaxTimeoutEvent(uint8_t _maxEvtNum);
  
	//
	//	@brief	Get the maximum no of timeout event which can be active simultaneously
	//	@return Maximun no of timeout event
	//	
	uint8_t getMaxTimeoutEvent();
  
	//
	//	@brief	Set handler for the timeout event with ID = _evtID by number of count of interval
	//	@param _evtID	Timeout event ID; must be from 0 to getMaxTimeoutEvent()-1
	//	@param _timeoutEvtHdlr	Timeout event handler, declare using DeclareHandler
	//	@param _timeoutCount	Number of count of intervals for timeout
	//	@param _InvokeIfLE0	In case when _timeoutCount*getUpdateInterval() ==0, _timeoutEvtHdlr will be invoked when true, and _timeoutEvtHdlr will not be invoked when false
	//	@return Control_OK (==0): no currently active TimeoutEventHandler for timeout event with ID = _evtID when this method is called, and set successfully
	//			Control_TimeoutLE0 (>0): duration for timeout <=0, hence _timeoutEvtHdlr will be called back in next available timeslot if _InvokeIfLE0==true
	//			Control_TimeoutAlreadyActive (<0): an active TimeoutEventHandler is currently running for timeout event with ID = _evtID and hence this method failed
	//
	err_t setTimeoutByCount(uint8_t _evtID,TimeoutEventHandler _timeoutEvtHdlr, uint32_t _timeoutCount, bool _InvokeIfLE0=false);

	//
	//	@brief	Set handler for a timeout event by relative time (in ms)
	//	@param _evtID	Timeout event ID; must be from 0 to getMaxTimeoutEvent()-1
	//	@param _timeoutEvtHdlr	Timeout event handler, declare using DeclareHandler
	//	@param _relTime	Amount of timeout relative to current time, in ms
	//	@param _InvokeIfLE0	In case when _relTime ==0, _timeoutEvtHdlr will be invoked when true, and _timeoutEvtHdlr will not be invoked when false
	//	@return Control_OK (==0): no currently active TimeoutEventHandler for timeout event with ID = _evtID when this method is called, and set successfully
	//			Control_TimeoutLE0 (>0): duration for timeout <=0, hence _timeoutEvtHdlr will be called back in next available timeslot if _InvokeIfLE0==true
	//			Control_TimeoutAlreadyActive (<0): an active TimeoutEventHandler is currently running for timeout event with ID = _evtID and hence this method failed
	//
	err_t setTimeoutByRelTime(uint8_t _evtID,TimeoutEventHandler _timeoutEvtHdlr, ulong_t _relTime, bool _InvokeIfLE0=false);

	//
	//	@brief	Set handler for a timeout event by absolute time (in ms)
	//	@param _evtID	Timeout event ID; must be from 0 to getMaxTimeoutEvent()-1
	//	@param _timeoutEvtHdlr	Timeout event handler, declare using DeclareHandler
	//	@param _absTime	Absolute time for timeout, in ms
	//	@param _InvokeIfLE0	In case when _absTime < current time, _timeoutEvtHdlr will be invoked when true, and _timeoutEvtHdlr will not be invoked when false
	//	@return Control_OK (==0): no currently active TimeoutEventHandler for timeout event with ID = _evtID when this method is called, and set successfully
	//			Control_TimeoutLE0 (>0): _absTime < current time, hence _timeoutEvtHdlr will be called back in next available timeslot if _InvokeIfLE0==true
	//			Control_TimeoutAlreadyActive (<0): an active TimeoutEventHandler is currently running for timeout event with ID = _evtID and hence this method failed
	//
	err_t setTimeoutByAbsTime(uint8_t _evtID,TimeoutEventHandler _timeoutEvtHdlr, ulong_t _absTime, bool _InvokeIfLE0=false);

	//
	//	@brief	Stop an active timeout event
	//	@param _evtID	Timeout event ID; must be from 0 to getMaxTimeoutEvent()-1
	//	@return Control_OK if successful
	//			Control_TimeoutNoActive if no active timeout event
	//
	err_t stopTimeout(uint8_t _evtID);
  
	//
	//	@brief	Check whether a timeout event is active
	//	@param _evtID	Timeout event ID; must be from 0 to getMaxTimeoutEvent()-1
	//	@return true if a timeout event is currently active AND _evtID is valid; false if no
	//
	bool isTimeoutActive(uint8_t _evtID);
  

	friend class PinManager;

	friend class TimeEventManager;
};


#endif