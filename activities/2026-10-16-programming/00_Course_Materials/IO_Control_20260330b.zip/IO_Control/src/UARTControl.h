#ifndef UARTCONTROL_H
#define UARTCONTROL_H

#include "Control.h"
#include "Debug.h"
#include "SoftwareSerial.h"

#ifndef UART_BUFFER_SIZE
#define UART_BUFFER_SIZE 200
#endif

class PinManager;

	enum UARTControl_Config
	{	UART_5N1,
		UART_6N1,
		UART_7N1,
		UART_8N1,
		UART_5N2,
		UART_6N2,
		UART_7N2,
		UART_8N2,
		UART_5E1,
		UART_6E1,
		UART_7E1,
		UART_8E1,
		UART_5E2,
		UART_6E2,
		UART_7E2,
		UART_8E2,
		UART_5O1,
		UART_6O1,
		UART_7O1,
		UART_8O1,
		UART_5O2,
		UART_6O2,
		UART_7O2,
		UART_8O2,
		UART_5M1,	//	not support in HardwareSerial from onwards
		UART_6M1,
		UART_7M1,
		UART_8M1,
		UART_5M2,
		UART_6M2,
		UART_7M2,
		UART_8M2,
		UART_5S1,
		UART_6S1,
		UART_7S1,
		UART_8S1,
		UART_5S2,
		UART_6S2,
		UART_7S2,
		UART_8S2,
	};

class UARTControl : public Control {
public:

#ifdef CONFIG_IDF_TARGET_ESP32C3
  //  for ESP32 C3
  static const uint8_t pinUART0RX = 20;
  static const uint8_t pinUART0TX = 21;
#endif

#ifdef CONFIG_IDF_TARGET_ESP32S3
	//  for ESP32 S3
  static const uint8_t pinUART0RX = 44;
  static const uint8_t pinUART0TX = 43;
#endif
	
protected:

  HardwareSerial* hwSerial = nullptr;
  SoftwareSerial* swSerial = nullptr;

  uint8_t serialType = 0;
    //  0 for uninitialized
    //  1 for hardware serial
    //  2 for software serial

  int8_t uartIndex; //  uart num of the hardware serial
                    //  -1 if software serial

  ulong_t baudRate;
  UARTControl_Config config;
  SerialConfig hw_config;	//  refer to https://github.com/espressif/arduino-esp32/blob/master/cores/esp32/HardwareSerial.h, enum SerialConfig
  EspSoftwareSerial::Config sw_config;	//	refer to https://github.com/plerup/espsoftwareserial/blob/main/src/SoftwareSerial.h; enum Config
  ulong_t timeout_ms;
  bool  invert;

  int pinNum_RX = -1;
  int pinNum_TX = -1;
  int pinNum_RTS = -1;
  int pinNum_CTS = -1;

  uint16_t _receivedByteNum;

  err_t startControl();

  err_t stopControl();
  
  err_t setHWConfig(UARTControl_Config config);
  err_t setSWConfig(UARTControl_Config config);
  

public:

  UARTControl();

  err_t init(int8_t _uartIndex, int _pinNum_RX, int _pinNum_TX, 
						int _pinNum_CTS, int _pinNum_RTS, 
						ulong_t _baudRate, UARTControl_Config _config=UART_8N1, bool invert=false, ulong_t timeout_ms=20000UL);

  static int getStaticClsID() {
    return CLS_UART;
  }

  bool isInit();

  //void update(ulong_t currentMillis) override; //if(Serial.available()){Serial.readBytes(readBuffer, 200);}  Then handle the message in handler function
  void _preHandler() override;

  err_t request();

  err_t release();

  //  err_t setBaudRate(uint32_t baudRate);
    //  removed, as HardwareSerial::updateBaudRate(ulong_t) returns void, and not sure if baud rate can be set successfully

  // err_t setFlowControlMode(uint8_t mode, uint8_t threshold); //mode: UART_HW_FLOWCTRL_DISABLE, UART_HW_FLOWCTRL_RTS, UART_HW_FLOWCTRL_CTS, UART_HW_FLOWCTRL_CTS_RTS, UART_HW_FLOWCTRL_MAX


  char receiveBuffer[UART_BUFFER_SIZE];  //  buffer for holding received data
  
  bool isDataReceived()       { return status & UARTControlEventHandler_DataReceived; }
  uint16_t receivedByteNum()  { return _receivedByteNum; }

  uint16_t availableForWrite();  
  int write(uint8_t val);
  int write(const uint8_t* buf,int len);
  int write(const char* msg);

  //err_t writeBytes(const char* msg);
  //HardwareSerial& getHardwareSerial();
  HardwareSerial* getHardwareSerial();	//	return null if not using HardwareSerial
  SoftwareSerial* getSoftwareSerial();	//	return null if not using SoftwareSerial
  uint8_t getSerialType();
  err_t updateBaudRate(ulong_t _baudRate);



  friend class PinManager;
};

#endif
