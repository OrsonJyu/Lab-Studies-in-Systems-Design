#include <IO_Control.h>

BinOutControl binOutCtrl0;

int startRel=-1;
int onDurationMS=1000;
int offDurationMS=2000;
int noOfTimes;

ulong_t startTime=0;
int repeatCount=10;

DeclareHandler(iocontrolHandler,_ctrl,IOControl,{ 
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //     Serial.println("IOControl - SchedulerTimerEvent");   

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.print("input command:");
    Serial.println(input);

    Serial.print("current time=");
    Serial.println(_ctrl.getUpdateTime());

    int pos1=input.indexOf(',');
    int pos2=input.indexOf(',',pos1+1);
    if ((pos1==-1) || (pos2==-1))
    { //  no comma, hence error 
      Serial.println("Error: should have at least three numbers");
      return;
    }

    int pos3=input.indexOf(',',pos2+1);

    if (pos3==-1)
    { //  only three numbers: <on duration>,<off duration>,<no of times>
      onDurationMS = input.substring(0,pos1).toInt();
      offDurationMS = input.substring(pos1+1,pos2).toInt();
      noOfTimes = input.substring(pos2+1).toInt();
      Serial.print("on duration=");
      Serial.println(onDurationMS);
      Serial.print("off duration=");
      Serial.println(offDurationMS);
      Serial.print("no_of_times=");
      Serial.println(noOfTimes);

      //
      //  the following is to restart blinking, using onDurationMS, offDurationMS and noOfTimes
      //
      repeatCount = noOfTimes;
      startTime = _ctrl.getUpdateTime()+3000;
      Serial.print("blink will start at t=");
      Serial.print(startTime);
      Serial.print(" for ");
      Serial.print(repeatCount);
      Serial.println(" times");
    } else
    { int pos4=input.indexOf(',',pos3+1);
      if (pos4!=-1)
      { Serial.println("Error: should not be more than 4 numbers");
        return;
      }
      startRel = input.substring(0,pos1).toInt();
      onDurationMS = input.substring(pos1+1,pos2).toInt();
      offDurationMS = input.substring(pos2+1,pos3).toInt();
      noOfTimes = input.substring(pos3+1).toInt();
      Serial.print("start rel time=");
      Serial.println(startRel);
      Serial.print("on duration=");
      Serial.println(onDurationMS);
      Serial.print("off duration=");
      Serial.println(offDurationMS);
      Serial.print("no_of_times=");
      Serial.println(noOfTimes);

      //
      //  the following is to restart blinking, using onDurationMS, offDurationMS, noOfTimes and startRel
      //
      repeatCount = noOfTimes;
      startTime = _ctrl.getUpdateTime()+startRel;
      Serial.print("blink will start at t=");
      Serial.print(startTime);
      Serial.print(" for ");
      Serial.print(repeatCount);
      Serial.println(" times");
    }

  }
});

/* 
DeclareHandler(printBinOutState,_ctrl,BinOutControl,{
  Serial.print("current state=");
  Serial.print(_ctrl.read());
  Serial.print(" at t=");
  Serial.println(_ctrl.getUpdateTime());
  _ctrl.setTimeoutByRelTime(1,printBinOutState,500,true);
});
*/

DeclareHandler(changeBinOutState,_ctrl,BinOutControl,{
  if (_ctrl.read()==HIGH)
  { _ctrl.write(LOW);

    //  finished one cycle of blinking (from low->high)
    //  determine whether to repeat
    repeatCount--;
    if (repeatCount>0)
      _ctrl.setTimeoutByRelTime(0,changeBinOutState,offDurationMS,true);
    else
      Serial.println("stop blinking");
  } else
  { _ctrl.write(HIGH);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState,onDurationMS,true);
  }
});

DeclareHandler(binOutHandler,_ctrl,BinOutControl,{ //  declare a handler for scheduler
  //  binOutHandler - name of the handler function
  //  _ctrl - BinOutControl object
  //  BinOutControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("BinOutControl - SchedulerTimerEvent"); 
  if (!_ctrl.isTimeoutActive(0))
  { if (_ctrl.getUpdateTime()>startTime)
    { startTime = -1; //  changeBinOutState will not be restarted until startTime is set to a smaller value later
      Serial.println("start blinking");
      _ctrl.setTimeoutByRelTime(0,changeBinOutState,0,true);
    }
  }
  
  /*
  if (!_ctrl.isTimeoutActive(1))
    _ctrl.setTimeoutByRelTime(1,printBinOutState,0,true);
  */

});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0,100,iocontrolHandler);

  err_t err = binOutCtrl0.init(12,LOW);
  if (err!=Control_OK)
  { Serial.print("Error in line 131 (");
    Serial.print(err);
    Serial.print(") cannot proceed!!");
    return;
  }
  binOutCtrl0.enableScheduler(0, 1, binOutHandler,2);
}

void loop() {
  // put your main code here, to run repeatedly:
}
