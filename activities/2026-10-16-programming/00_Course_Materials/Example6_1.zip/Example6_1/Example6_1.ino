#include <IO_Control.h>

DeclareHandler(hdlr,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent(_status))
  //     Serial..println("IOControl - SchedulerTimerEvent");     
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.println(input);

    //  assuming "input" has two commas
    int pos1=input.indexOf(",");
    int pos2=input.indexOf(",",pos1+1);
    Serial.print("pos1=");
    Serial.println(pos1);
    Serial.print("pos2=");
    Serial.println(pos2);

    Serial.print("first=");
    Serial.println(input.substring(0,pos1));  //  print part of string before first comma
    Serial.print("second=");
    Serial.println(input.substring(pos1+1,pos2)); //  print part of string between first and second comma
    Serial.print("third=");
    Serial.println(input.substring(pos2+1));  //  print part of string after second comma
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0, 10, hdlr);
}

void loop() {
  // put your main code here, to run repeatedly:
  IO_Control.execute();
}