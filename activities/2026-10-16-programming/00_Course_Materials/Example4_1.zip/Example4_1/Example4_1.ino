//
//  for demonstrating use of Serial Monitor input through handler function of IOControl
//    circuit:  Luatos ESP32C3 board
//
#include <IO_Control.h>

DeclareHandler(hdlr,_ctrl,IOControl,{
  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("IOControl - SchedulerTimerEvent");     
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.println(input);

    int len = input.length();
    Serial.print("no of characters read =");
    Serial.println(len);

    int index = input.charAt('a');
    Serial.print("character \'a\' is at index =");
    Serial.println(index);
  }
});

void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  IO_Control.enableScheduler(0, 10, hdlr);
}

void loop() {
  // put your main code here, to run repeatedly:
}