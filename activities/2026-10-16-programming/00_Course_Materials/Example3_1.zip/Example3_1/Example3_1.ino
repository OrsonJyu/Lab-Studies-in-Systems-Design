bool var1 = true;   //  either "true" or "false"
byte var4 = 255;    //  from 0 to 255
char var5 = 'A';    //  a single character, hence use single quote
int var2 = 10;      //  an integer, and hence no decimal point  
int var11 = -10;     //  can be negative integer as well
uint16_t var13 = 400000000; //  value too large
uint32_t var12 = -10; //  cannot store negative value
double var3 = 25.3;  //  value with decimal point
String var6 = "Hello, World\n"; //  a string, and use double quotes to enclose

void setup()
{ Serial.begin(115200);
  Serial.println(var1);
  Serial.println(var4);
  Serial.println(var5);
  Serial.println(var2);
  Serial.println(var11);
  Serial.println(var13);
  Serial.println(var12);
  Serial.println(var3);
  Serial.println(var6);
  Serial.println("end of test");
}

void loop()
{
}
