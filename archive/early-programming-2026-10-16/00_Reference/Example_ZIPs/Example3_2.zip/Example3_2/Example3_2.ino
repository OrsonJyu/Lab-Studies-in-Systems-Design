void setup() {
  // put your setup code here, to run once:

  int a=10, b=20, c;
  double d, e=10.0, f=20.0;

  c = a + b;  //  =30
  c = a * b;  //  =200
  c = a % b;  //  =10
  c = a / b;  //  =0
  d = double(a) / b ; //  = 0.5 (double)
  d = a / double(b) ; //  = 0.5 (double)
  d = e % f;  // compile time error

}

void loop() {
  // put your main code here, to run repeatedly:

}
