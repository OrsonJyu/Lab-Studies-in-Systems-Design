//
//  for demonstrating use of timeout function in BinOutControl to generate changes in GPIO output
//    logic for controlling FSM is similar to that in iocontrol\iocontrol_fsm_setTimeout_serialin.ino
//    board:
//      Luatos ESP32C3 board
//    circuit
//      LED at IO12, build-in for Luatos ESP32C3 board 
//

#include <IO_Control.h>

BinOutControl binOutCtrl0;  //  for IO12
BinOutControl binOutCtrl1;  //  for IO13
ulong_t onDurationMS_0 = 500;   //  for IO12
ulong_t offDurationMS_0 = 3000;
ulong_t onDurationMS_1 = 600;   //  for IO13
ulong_t offDurationMS_1 = 3100;

DeclareHandler(binOutHandler0,_ctrl,BinOutControl,{ //  declare a handler for scheduler
  //  binOutHandler - name of the handler function
  //  _ctrl - BinOutControl object
  //  BinOutControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("BinOutControl - SchedulerTimerEvent"); 
  if (!_ctrl.isTimeoutActive(0))
    _ctrl.setTimeoutByRelTime(0,changeBinOutState0,0,true);
  if (!_ctrl.isTimeoutActive(1))
    _ctrl.setTimeoutByRelTime(1,printBinOutState,0,true);

});

DeclareHandler(changeBinOutState0,_ctrl,BinOutControl,{
  if (_ctrl.read()==HIGH)
  { _ctrl.write(LOW);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState0,offDurationMS_0,true);
  } else
  { _ctrl.write(HIGH);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState0,onDurationMS_0,true);
  }
});


DeclareHandler(printBinOutState,_ctrl,BinOutControl,{
  Serial.print("current state=");
  Serial.print(_ctrl.read());
  Serial.print(" at t=");
  Serial.println(_ctrl.getUpdateTime());
  _ctrl.setTimeoutByRelTime(1,printBinOutState,500,true);
});

DeclareHandler(binOutHandler1,_ctrl,BinOutControl,{ //  declare a handler for scheduler
  //  binOutHandler - name of the handler function
  //  _ctrl - BinOutControl object
  //  BinOutControl - class of object of this handler
  //  _ctrl.getUpdateTime() (ulong_t) - time when this handler is invoked

  // if (_ctrl.isSchedulerTimeEvent())
  //     Serial..println("BinOutControl - SchedulerTimerEvent"); 
  if (!_ctrl.isTimeoutActive(0))
    _ctrl.setTimeoutByRelTime(0,changeBinOutState1,0,true);
  if (!_ctrl.isTimeoutActive(1))
    _ctrl.setTimeoutByRelTime(1,printBinOutState,0,true);

});

DeclareHandler(changeBinOutState1,_ctrl,BinOutControl,{
  if (_ctrl.read()==HIGH)
  { _ctrl.write(LOW);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState1,offDurationMS_1,true);
  } else
  { _ctrl.write(HIGH);
    _ctrl.setTimeoutByRelTime(0,changeBinOutState1,onDurationMS_1,true);
  }
});


void setup() {
  // put your setup code here, to run once:
  IO_Control.begin(); 

  Serial.begin(115200);
  Serial.println("chip started");

  binOutCtrl0.init(12,LOW); //  IO12 for GPIO binary output
  binOutCtrl1.init(13,LOW); //  IO13 for GPIO binary output

  binOutCtrl0.enableScheduler(0, 1, binOutHandler0,2);
  binOutCtrl1.enableScheduler(0, 1, binOutHandler1,2);
}

void loop() {
  // put your main code here, to run repeatedly:
}
