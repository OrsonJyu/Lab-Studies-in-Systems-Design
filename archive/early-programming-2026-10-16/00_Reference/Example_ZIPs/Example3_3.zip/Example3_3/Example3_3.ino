String var7 = "Hello\n";  // 6 characters in this string
String var8 = "Hello\nThis\nis\na\nTest\n"; //  \n means new line
String var9 = "This is \"School of Design\""; //  \" means a double quote character
String var10 = "This is Clifford\'s cat\n";   //  \' means a signle quote character

void setup()
{ Serial.begin(115200);
  Serial.println(var7);
  Serial.println(var8);
  Serial.println(var9);
  Serial.println(var10);
  Serial.println("end of test");
}

void loop()
{ 
}
